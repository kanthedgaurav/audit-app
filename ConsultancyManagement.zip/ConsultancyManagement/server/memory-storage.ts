import { 
  type User, type InsertUser, type Client, type InsertClient, type Firm, type InsertFirm,
  type FinancialPeriod, type InsertFinancialPeriod, type ChartOfAccount, type InsertChartOfAccount,
  type TrialBalanceEntry, type InsertTrialBalanceEntry, type FinancialStatement, type InsertFinancialStatement,
  type AuditEngagement, type InsertAuditEngagement, type AuditFinding, type InsertAuditFinding,
  type Document, type InsertDocument, type ComplianceItem, type InsertComplianceItem,
  type ActivityLog, type InsertActivityLog, type ReportTemplate, type InsertReportTemplate,
  type GeneratedReport, type InsertGeneratedReport
} from "@shared/schema";
import { IStorage } from "./storage";

export class MemoryStorage implements IStorage {
  private users: User[] = [];
  private firms: Firm[] = [];
  private clients: Client[] = [];
  private financialPeriods: FinancialPeriod[] = [];
  private chartOfAccounts: ChartOfAccount[] = [];
  private trialBalanceEntries: TrialBalanceEntry[] = [];
  private financialStatements: FinancialStatement[] = [];
  private auditEngagements: AuditEngagement[] = [];
  private auditFindings: AuditFinding[] = [];
  private documents: Document[] = [];
  private complianceItems: ComplianceItem[] = [];
  private activityLogs: ActivityLog[] = [];
  private reportTemplates: ReportTemplate[] = [];
  private generatedReports: GeneratedReport[] = [];

  private nextId = 1;

  constructor() {
    this.initializeData();
    this.initializeTrialBalanceData();
  }

  private initializeData() {
    // Initialize firm
    this.firms.push({
      id: 1,
      name: "Al-Rashid Financial Consultancy",
      registrationNumber: "DED-FC-2024-001",
      address: "Sheikh Zayed Road, Dubai, UAE",
      contactEmail: "contact@alrashidfc.ae",
      contactPhone: "+971-4-123-4567",
      website: "https://alrashidfc.ae",
      status: "active",
      createdAt: new Date(),
      updatedAt: new Date()
    });

    // Initialize users
    this.users.push(
      {
        id: 1,
        email: "ahmed@alrashidfc.ae",
        firstName: "Ahmed",
        lastName: "Al-Rashid",
        role: "admin",
        firmId: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 2,
        email: "sara@alrashidfc.ae",
        firstName: "Sara",
        lastName: "Mohammed",
        role: "manager",
        firmId: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 3,
        email: "omar@alrashidfc.ae",
        firstName: "Omar",
        lastName: "Hassan",
        role: "staff",
        firmId: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    );

    // Initialize clients
    this.clients.push(
      {
        id: 1,
        name: "Emirates Trading Company",
        industry: "Trading",
        registrationNumber: "DED-12345",
        jurisdiction: "UAE",
        reportingRegime: "IFRS",
        fiscalYearEnd: new Date("2024-12-31"),
        address: "Deira, Dubai, UAE",
        contactPerson: "Khalid Al-Mansouri",
        contactEmail: "khalid@emiratestrading.ae",
        contactPhone: "+971-50-123-4567",
        status: "active",
        firmId: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 2,
        name: "Gulf Manufacturing",
        industry: "Manufacturing",
        registrationNumber: "DED-23456",
        jurisdiction: "UAE",
        reportingRegime: "IFRS",
        fiscalYearEnd: new Date("2024-12-31"),
        address: "Sharjah Industrial Area",
        contactPerson: "Fatima Al-Zahra",
        contactEmail: "fatima@gulfmfg.ae",
        contactPhone: "+971-50-234-5678",
        status: "active",
        firmId: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 3,
        name: "TechnoServe Solutions",
        industry: "Technology",
        registrationNumber: "DED-34567",
        jurisdiction: "UAE",
        reportingRegime: "IFRS",
        fiscalYearEnd: new Date("2024-12-31"),
        address: "Dubai Internet City",
        contactPerson: "Mohammed Al-Hashimi",
        contactEmail: "mohammed@technoserve.ae",
        contactPhone: "+971-50-345-6789",
        status: "active",
        firmId: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 4,
        name: "Heritage Construction",
        industry: "Construction",
        registrationNumber: "DED-45678",
        jurisdiction: "UAE",
        reportingRegime: "IFRS",
        fiscalYearEnd: new Date("2024-12-31"),
        address: "Business Bay, Dubai",
        contactPerson: "Amina Al-Kuwari",
        contactEmail: "amina@heritage-const.ae",
        contactPhone: "+971-50-456-7890",
        status: "pending",
        firmId: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    );

    // Initialize financial periods
    this.financialPeriods.push(
      {
        id: 1,
        clientId: 1,
        startDate: new Date("2024-01-01"),
        endDate: new Date("2024-12-31"),
        description: "Financial Year 2024",
        status: "active",
        createdAt: new Date()
      },
      {
        id: 2,
        clientId: 2,
        startDate: new Date("2024-01-01"),
        endDate: new Date("2024-12-31"),
        description: "Financial Year 2024",
        status: "active",
        createdAt: new Date()
      },
      {
        id: 3,
        clientId: 3,
        startDate: new Date("2024-01-01"),
        endDate: new Date("2024-12-31"),
        description: "Financial Year 2024",
        status: "active",
        createdAt: new Date()
      },
      {
        id: 4,
        clientId: 4,
        startDate: new Date("2024-01-01"),
        endDate: new Date("2024-12-31"),
        description: "Financial Year 2024",
        status: "active",
        createdAt: new Date()
      }
    );

    // Initialize Chart of Accounts (IFRS compliant)
    this.chartOfAccounts.push(
      // Assets
      { id: 1, clientId: 1, accountCode: "1000", accountName: "Current Assets", accountType: "asset", parentAccountId: null, isActive: true, createdAt: new Date() },
      { id: 2, clientId: 1, accountCode: "1100", accountName: "Cash and Cash Equivalents", accountType: "asset", parentAccountId: 1, isActive: true, createdAt: new Date() },
      { id: 3, clientId: 1, accountCode: "1200", accountName: "Trade Receivables", accountType: "asset", parentAccountId: 1, isActive: true, createdAt: new Date() },
      { id: 4, clientId: 1, accountCode: "1300", accountName: "Inventory", accountType: "asset", parentAccountId: 1, isActive: true, createdAt: new Date() },
      { id: 5, clientId: 1, accountCode: "1400", accountName: "Prepaid Expenses", accountType: "asset", parentAccountId: 1, isActive: true, createdAt: new Date() },
      { id: 6, clientId: 1, accountCode: "1500", accountName: "Non-Current Assets", accountType: "asset", parentAccountId: null, isActive: true, createdAt: new Date() },
      { id: 7, clientId: 1, accountCode: "1510", accountName: "Property, Plant & Equipment", accountType: "asset", parentAccountId: 6, isActive: true, createdAt: new Date() },
      { id: 8, clientId: 1, accountCode: "1520", accountName: "Intangible Assets", accountType: "asset", parentAccountId: 6, isActive: true, createdAt: new Date() },
      
      // Liabilities
      { id: 9, clientId: 1, accountCode: "2000", accountName: "Current Liabilities", accountType: "liability", parentAccountId: null, isActive: true, createdAt: new Date() },
      { id: 10, clientId: 1, accountCode: "2100", accountName: "Trade Payables", accountType: "liability", parentAccountId: 9, isActive: true, createdAt: new Date() },
      { id: 11, clientId: 1, accountCode: "2200", accountName: "Accrued Expenses", accountType: "liability", parentAccountId: 9, isActive: true, createdAt: new Date() },
      { id: 12, clientId: 1, accountCode: "2300", accountName: "Short-term Borrowings", accountType: "liability", parentAccountId: 9, isActive: true, createdAt: new Date() },
      { id: 13, clientId: 1, accountCode: "2400", accountName: "Non-Current Liabilities", accountType: "liability", parentAccountId: null, isActive: true, createdAt: new Date() },
      { id: 14, clientId: 1, accountCode: "2410", accountName: "Long-term Debt", accountType: "liability", parentAccountId: 13, isActive: true, createdAt: new Date() },
      { id: 15, clientId: 1, accountCode: "2420", accountName: "Provisions", accountType: "liability", parentAccountId: 13, isActive: true, createdAt: new Date() },
      
      // Equity
      { id: 16, clientId: 1, accountCode: "3000", accountName: "Equity", accountType: "equity", parentAccountId: null, isActive: true, createdAt: new Date() },
      { id: 17, clientId: 1, accountCode: "3100", accountName: "Share Capital", accountType: "equity", parentAccountId: 16, isActive: true, createdAt: new Date() },
      { id: 18, clientId: 1, accountCode: "3200", accountName: "Retained Earnings", accountType: "equity", parentAccountId: 16, isActive: true, createdAt: new Date() },
      
      // Income
      { id: 19, clientId: 1, accountCode: "4000", accountName: "Revenue", accountType: "income", parentAccountId: null, isActive: true, createdAt: new Date() },
      { id: 20, clientId: 1, accountCode: "4100", accountName: "Sales Revenue", accountType: "income", parentAccountId: 19, isActive: true, createdAt: new Date() },
      { id: 21, clientId: 1, accountCode: "4200", accountName: "Other Income", accountType: "income", parentAccountId: 19, isActive: true, createdAt: new Date() },
      
      // Expenses
      { id: 22, clientId: 1, accountCode: "5000", accountName: "Cost of Sales", accountType: "expense", parentAccountId: null, isActive: true, createdAt: new Date() },
      { id: 23, clientId: 1, accountCode: "5100", accountName: "Operating Expenses", accountType: "expense", parentAccountId: null, isActive: true, createdAt: new Date() },
      { id: 24, clientId: 1, accountCode: "5200", accountName: "Administrative Expenses", accountType: "expense", parentAccountId: null, isActive: true, createdAt: new Date() },
      { id: 25, clientId: 1, accountCode: "5300", accountName: "Financial Expenses", accountType: "expense", parentAccountId: null, isActive: true, createdAt: new Date() }
    );

    // Initialize Trial Balance Entries with sample data
    this.trialBalanceEntries.push(
      { id: 1, clientId: 1, periodId: 1, accountId: 2, debitAmount: "150000.00", creditAmount: "0.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 2, clientId: 1, periodId: 1, accountId: 3, debitAmount: "85000.00", creditAmount: "0.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 3, clientId: 1, periodId: 1, accountId: 4, debitAmount: "120000.00", creditAmount: "0.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 4, clientId: 1, periodId: 1, accountId: 7, debitAmount: "500000.00", creditAmount: "0.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 5, clientId: 1, periodId: 1, accountId: 10, debitAmount: "0.00", creditAmount: "45000.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 6, clientId: 1, periodId: 1, accountId: 11, debitAmount: "0.00", creditAmount: "25000.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 7, clientId: 1, periodId: 1, accountId: 17, debitAmount: "0.00", creditAmount: "500000.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 8, clientId: 1, periodId: 1, accountId: 18, debitAmount: "0.00", creditAmount: "285000.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 9, clientId: 1, periodId: 1, accountId: 20, debitAmount: "0.00", creditAmount: "450000.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 10, clientId: 1, periodId: 1, accountId: 22, debitAmount: "280000.00", creditAmount: "0.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 11, clientId: 1, periodId: 1, accountId: 23, debitAmount: "120000.00", creditAmount: "0.00", uploadedAt: new Date(), uploadedBy: 1 },
      { id: 12, clientId: 1, periodId: 1, accountId: 24, debitAmount: "50000.00", creditAmount: "0.00", uploadedAt: new Date(), uploadedBy: 1 }
    );

    // Initialize Financial Statements
    this.financialStatements.push(
      {
        id: 1,
        clientId: 1,
        periodId: 1,
        statementType: "balance_sheet",
        format: "vertical",
        status: "final",
        content: {
          metadata: {
            generatedAt: new Date().toISOString(),
            regime: "IFRS",
            currency: "AED",
            clientName: "Emirates Trading Company",
            period: "Year ended December 31, 2024"
          },
          sections: {
            assets: {
              current: {
                cash: 150000,
                receivables: 85000,
                inventory: 120000,
                prepaid: 0,
                total: 355000
              },
              nonCurrent: {
                property: 500000,
                equipment: 0,
                intangible: 0,
                total: 500000
              },
              totalAssets: 855000
            },
            liabilities: {
              current: {
                payables: 45000,
                accrued: 25000,
                shortTermDebt: 0,
                total: 70000
              },
              nonCurrent: {
                longTermDebt: 0,
                provisions: 0,
                total: 0
              },
              totalLiabilities: 70000
            },
            equity: {
              shareCapital: 500000,
              retainedEarnings: 285000,
              totalEquity: 785000
            },
            totalEquityLiabilities: 855000
          }
        },
        generatedAt: new Date(),
        generatedBy: 1
      },
      {
        id: 2,
        clientId: 1,
        periodId: 1,
        statementType: "income_statement",
        format: "vertical",
        status: "final",
        content: {
          metadata: {
            generatedAt: new Date().toISOString(),
            regime: "IFRS",
            currency: "AED",
            clientName: "Emirates Trading Company",
            period: "Year ended December 31, 2024"
          },
          sections: {
            revenue: {
              sales: 450000,
              otherIncome: 0,
              totalRevenue: 450000
            },
            expenses: {
              costOfSales: 280000,
              operating: 120000,
              administrative: 50000,
              financial: 0,
              totalExpenses: 450000
            },
            grossProfit: 170000,
            netIncome: 0
          }
        },
        generatedAt: new Date(),
        generatedBy: 1
      }
    );

    // Initialize audit engagements
    this.auditEngagements.push(
      {
        id: 1,
        clientId: 1,
        engagementType: "internal_audit",
        startDate: new Date("2024-03-01"),
        endDate: new Date("2024-04-15"),
        status: "completed",
        leadAuditor: 1,
        riskLevel: "medium",
        scope: "Review of accounts receivable processes",
        objectives: "Assess internal controls",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 2,
        clientId: 2,
        engagementType: "icofr",
        startDate: new Date("2024-06-01"),
        endDate: new Date("2024-06-30"),
        status: "in_progress",
        leadAuditor: 2,
        riskLevel: "high",
        scope: "Internal controls assessment",
        objectives: "Evaluate control effectiveness",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 3,
        clientId: 3,
        engagementType: "internal_audit",
        startDate: new Date("2024-08-01"),
        endDate: new Date("2024-08-31"),
        status: "planned",
        leadAuditor: 1,
        riskLevel: "low",
        scope: "IT controls assessment",
        objectives: "Review IT governance",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 4,
        clientId: 4,
        engagementType: "external_audit",
        startDate: new Date("2024-09-01"),
        endDate: new Date("2024-09-30"),
        status: "planned",
        leadAuditor: 2,
        riskLevel: "medium",
        scope: "Year-end audit support",
        objectives: "Assist external audit",
        createdAt: new Date(),
        updatedAt: new Date()
      }
    );

    // Initialize compliance items
    this.complianceItems.push(
      {
        id: 1,
        clientId: 1,
        title: "VAT Return Filing - Q1 2024",
        description: "File quarterly VAT return",
        dueDate: new Date("2024-04-28"),
        status: "completed",
        assignedTo: 3,
        priority: "high",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 2,
        clientId: 1,
        title: "Economic Substance Report",
        description: "Submit ES notification",
        dueDate: new Date("2024-06-30"),
        status: "in_progress",
        assignedTo: 1,
        priority: "high",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 3,
        clientId: 2,
        title: "AML Compliance Review",
        description: "Annual AML assessment",
        dueDate: new Date("2024-05-15"),
        status: "pending",
        assignedTo: 2,
        priority: "medium",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 4,
        clientId: 3,
        title: "Corporate Tax Registration",
        description: "Register for UAE Corporate Tax",
        dueDate: new Date("2024-04-30"),
        status: "completed",
        assignedTo: 1,
        priority: "high",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 5,
        clientId: 4,
        title: "Audit Committee Minutes",
        description: "Prepare meeting minutes",
        dueDate: new Date("2024-03-31"),
        status: "pending",
        assignedTo: 2,
        priority: "medium",
        createdAt: new Date(),
        updatedAt: new Date()
      }
    );

    // Initialize activity logs
    this.activityLogs.push(
      {
        id: 1,
        userId: 1,
        clientId: 1,
        action: "client_created",
        description: "Created new client: Emirates Trading Company",
        entityType: "client",
        entityId: 1,
        timestamp: new Date()
      },
      {
        id: 2,
        userId: 2,
        clientId: 2,
        action: "audit_engagement_created",
        description: "Created ICOFR engagement",
        entityType: "audit_engagement",
        entityId: 2,
        timestamp: new Date()
      },
      {
        id: 3,
        userId: 1,
        clientId: 3,
        action: "client_created",
        description: "Created new client: TechnoServe Solutions",
        entityType: "client",
        entityId: 3,
        timestamp: new Date()
      },
      {
        id: 4,
        userId: 2,
        clientId: 4,
        action: "client_created",
        description: "Created new client: Heritage Construction",
        entityType: "client",
        entityId: 4,
        timestamp: new Date()
      },
      {
        id: 5,
        userId: 3,
        clientId: 1,
        action: "document_uploaded",
        description: "Uploaded Trial Balance document",
        entityType: "document",
        entityId: 1,
        timestamp: new Date()
      },
      {
        id: 6,
        userId: 1,
        clientId: 2,
        action: "compliance_item_created",
        description: "Added AML compliance review",
        entityType: "compliance",
        entityId: 3,
        timestamp: new Date()
      },
      {
        id: 7,
        userId: 2,
        clientId: 1,
        action: "audit_engagement_created",
        description: "Created internal audit engagement",
        entityType: "audit_engagement",
        entityId: 1,
        timestamp: new Date()
      },
      {
        id: 8,
        userId: 3,
        clientId: 3,
        action: "compliance_item_created",
        description: "Added Corporate Tax registration",
        entityType: "compliance",
        entityId: 4,
        timestamp: new Date()
      }
    );

    this.nextId = 100;
  }

  private initializeTrialBalanceData() {
    // Add trial balance entries for all clients
    this.trialBalanceEntries.push(
      // Client 1 - Emirates Trading Company
      { id: 1, clientId: 1, periodId: 1, accountId: 2, accountCode: "1100", accountName: "Cash and Cash Equivalents", debitAmount: 150000, creditAmount: 0, uploadedAt: new Date() },
      { id: 2, clientId: 1, periodId: 1, accountId: 3, accountCode: "1200", accountName: "Trade Receivables", debitAmount: 85000, creditAmount: 0, uploadedAt: new Date() },
      { id: 3, clientId: 1, periodId: 1, accountId: 4, accountCode: "1300", accountName: "Inventory", debitAmount: 120000, creditAmount: 0, uploadedAt: new Date() },
      { id: 4, clientId: 1, periodId: 1, accountId: 5, accountCode: "1400", accountName: "Prepaid Expenses", debitAmount: 15000, creditAmount: 0, uploadedAt: new Date() },
      { id: 5, clientId: 1, periodId: 1, accountId: 7, accountCode: "1510", accountName: "Property, Plant & Equipment", debitAmount: 500000, creditAmount: 0, uploadedAt: new Date() },
      { id: 6, clientId: 1, periodId: 1, accountId: 10, accountCode: "2100", accountName: "Trade Payables", debitAmount: 0, creditAmount: 65000, uploadedAt: new Date() },
      { id: 7, clientId: 1, periodId: 1, accountId: 11, accountCode: "2200", accountName: "Accrued Expenses", debitAmount: 0, creditAmount: 25000, uploadedAt: new Date() },
      { id: 8, clientId: 1, periodId: 1, accountId: 12, accountCode: "2300", accountName: "Short-term Borrowings", debitAmount: 0, creditAmount: 50000, uploadedAt: new Date() },
      { id: 9, clientId: 1, periodId: 1, accountId: 14, accountCode: "2410", accountName: "Long-term Debt", debitAmount: 0, creditAmount: 200000, uploadedAt: new Date() },
      { id: 10, clientId: 1, periodId: 1, accountId: 16, accountCode: "3100", accountName: "Share Capital", debitAmount: 0, creditAmount: 300000, uploadedAt: new Date() },
      { id: 11, clientId: 1, periodId: 1, accountId: 17, accountCode: "3200", accountName: "Retained Earnings", debitAmount: 0, creditAmount: 80000, uploadedAt: new Date() },
      { id: 12, clientId: 1, periodId: 1, accountId: 18, accountCode: "4100", accountName: "Revenue", debitAmount: 0, creditAmount: 750000, uploadedAt: new Date() },
      { id: 13, clientId: 1, periodId: 1, accountId: 19, accountCode: "5100", accountName: "Cost of Goods Sold", debitAmount: 450000, creditAmount: 0, uploadedAt: new Date() },
      { id: 14, clientId: 1, periodId: 1, accountId: 20, accountCode: "6100", accountName: "Operating Expenses", debitAmount: 180000, creditAmount: 0, uploadedAt: new Date() },
      { id: 15, clientId: 1, periodId: 1, accountId: 21, accountCode: "7100", accountName: "Interest Expense", debitAmount: 12000, creditAmount: 0, uploadedAt: new Date() },
      
      // Client 2 - Gulf Investments Ltd
      { id: 16, clientId: 2, periodId: 2, accountId: 2, accountCode: "1100", accountName: "Cash and Cash Equivalents", debitAmount: 200000, creditAmount: 0, uploadedAt: new Date() },
      { id: 17, clientId: 2, periodId: 2, accountId: 3, accountCode: "1200", accountName: "Trade Receivables", debitAmount: 95000, creditAmount: 0, uploadedAt: new Date() },
      { id: 18, clientId: 2, periodId: 2, accountId: 4, accountCode: "1300", accountName: "Inventory", debitAmount: 160000, creditAmount: 0, uploadedAt: new Date() },
      { id: 19, clientId: 2, periodId: 2, accountId: 10, accountCode: "2100", accountName: "Trade Payables", debitAmount: 0, creditAmount: 75000, uploadedAt: new Date() },
      { id: 20, clientId: 2, periodId: 2, accountId: 16, accountCode: "3100", accountName: "Share Capital", debitAmount: 0, creditAmount: 250000, uploadedAt: new Date() },
      { id: 21, clientId: 2, periodId: 2, accountId: 18, accountCode: "4100", accountName: "Revenue", debitAmount: 0, creditAmount: 850000, uploadedAt: new Date() },
      { id: 22, clientId: 2, periodId: 2, accountId: 19, accountCode: "5100", accountName: "Cost of Goods Sold", debitAmount: 500000, creditAmount: 0, uploadedAt: new Date() },
      { id: 23, clientId: 2, periodId: 2, accountId: 20, accountCode: "6100", accountName: "Operating Expenses", debitAmount: 205000, creditAmount: 0, uploadedAt: new Date() },
      
      // Client 3 - TechnoServe Solutions
      { id: 24, clientId: 3, periodId: 3, accountId: 2, accountCode: "1100", accountName: "Cash and Cash Equivalents", debitAmount: 100000, creditAmount: 0, uploadedAt: new Date() },
      { id: 25, clientId: 3, periodId: 3, accountId: 3, accountCode: "1200", accountName: "Trade Receivables", debitAmount: 75000, creditAmount: 0, uploadedAt: new Date() },
      { id: 26, clientId: 3, periodId: 3, accountId: 7, accountCode: "1510", accountName: "Property, Plant & Equipment", debitAmount: 300000, creditAmount: 0, uploadedAt: new Date() },
      { id: 27, clientId: 3, periodId: 3, accountId: 10, accountCode: "2100", accountName: "Trade Payables", debitAmount: 0, creditAmount: 45000, uploadedAt: new Date() },
      { id: 28, clientId: 3, periodId: 3, accountId: 16, accountCode: "3100", accountName: "Share Capital", debitAmount: 0, creditAmount: 200000, uploadedAt: new Date() },
      { id: 29, clientId: 3, periodId: 3, accountId: 18, accountCode: "4100", accountName: "Revenue", debitAmount: 0, creditAmount: 600000, uploadedAt: new Date() },
      { id: 30, clientId: 3, periodId: 3, accountId: 19, accountCode: "5100", accountName: "Cost of Goods Sold", debitAmount: 350000, creditAmount: 0, uploadedAt: new Date() },
      { id: 31, clientId: 3, periodId: 3, accountId: 20, accountCode: "6100", accountName: "Operating Expenses", debitAmount: 180000, creditAmount: 0, uploadedAt: new Date() }
    );
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.find(u => u.id === id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return this.users.find(u => u.email === email);
  }

  async createUser(user: InsertUser): Promise<User> {
    const newUser: User = {
      id: this.nextId++,
      ...user,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.push(newUser);
    return newUser;
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User> {
    const index = this.users.findIndex(u => u.id === id);
    if (index === -1) throw new Error("User not found");
    
    this.users[index] = {
      ...this.users[index],
      ...user,
      updatedAt: new Date()
    };
    return this.users[index];
  }

  // Firm operations
  async getFirm(id: number): Promise<Firm | undefined> {
    return this.firms.find(f => f.id === id);
  }

  async createFirm(firm: InsertFirm): Promise<Firm> {
    const newFirm: Firm = {
      id: this.nextId++,
      ...firm,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.firms.push(newFirm);
    return newFirm;
  }

  // Client operations
  async getClients(firmId: number): Promise<Client[]> {
    return this.clients.filter(c => c.firmId === firmId);
  }

  async getClient(id: number): Promise<Client | undefined> {
    return this.clients.find(c => c.id === id);
  }

  async createClient(client: InsertClient): Promise<Client> {
    const newClient: Client = {
      id: this.nextId++,
      ...client,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.clients.push(newClient);
    return newClient;
  }

  async updateClient(id: number, client: Partial<InsertClient>): Promise<Client> {
    const index = this.clients.findIndex(c => c.id === id);
    if (index === -1) throw new Error("Client not found");
    
    this.clients[index] = {
      ...this.clients[index],
      ...client,
      updatedAt: new Date()
    };
    return this.clients[index];
  }

  // Financial period operations
  async getFinancialPeriods(clientId: number): Promise<FinancialPeriod[]> {
    return this.financialPeriods.filter(p => p.clientId === clientId);
  }

  async createFinancialPeriod(period: InsertFinancialPeriod): Promise<FinancialPeriod> {
    const newPeriod: FinancialPeriod = {
      id: this.nextId++,
      ...period,
      createdAt: new Date()
    };
    this.financialPeriods.push(newPeriod);
    return newPeriod;
  }

  // Chart of accounts operations
  async getChartOfAccounts(clientId: number): Promise<ChartOfAccount[]> {
    return this.chartOfAccounts.filter(a => a.clientId === clientId);
  }

  async createChartOfAccount(account: InsertChartOfAccount): Promise<ChartOfAccount> {
    const newAccount: ChartOfAccount = {
      id: this.nextId++,
      ...account,
      createdAt: new Date()
    };
    this.chartOfAccounts.push(newAccount);
    return newAccount;
  }

  // Trial balance operations
  async getTrialBalanceEntries(clientId: number, periodId: number): Promise<TrialBalanceEntry[]> {
    return this.trialBalanceEntries.filter(e => e.clientId === clientId && e.periodId === periodId);
  }

  async createTrialBalanceEntry(entry: InsertTrialBalanceEntry): Promise<TrialBalanceEntry> {
    const newEntry: TrialBalanceEntry = {
      id: this.nextId++,
      ...entry,
      uploadedAt: new Date()
    };
    this.trialBalanceEntries.push(newEntry);
    return newEntry;
  }

  // Financial statement operations
  async getFinancialStatements(clientId: number): Promise<FinancialStatement[]> {
    return this.financialStatements.filter(s => s.clientId === clientId);
  }

  async createFinancialStatement(statement: InsertFinancialStatement): Promise<FinancialStatement> {
    const newStatement: FinancialStatement = {
      id: this.nextId++,
      ...statement,
      generatedAt: new Date()
    };
    this.financialStatements.push(newStatement);
    return newStatement;
  }

  // Audit engagement operations
  async getAuditEngagements(clientId: number): Promise<AuditEngagement[]> {
    return this.auditEngagements.filter(e => e.clientId === clientId);
  }

  async createAuditEngagement(engagement: InsertAuditEngagement): Promise<AuditEngagement> {
    const newEngagement: AuditEngagement = {
      id: this.nextId++,
      ...engagement,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.auditEngagements.push(newEngagement);
    return newEngagement;
  }

  // Audit finding operations
  async getAuditFindings(engagementId: number): Promise<AuditFinding[]> {
    return this.auditFindings.filter(f => f.engagementId === engagementId);
  }

  async createAuditFinding(finding: InsertAuditFinding): Promise<AuditFinding> {
    const newFinding: AuditFinding = {
      id: this.nextId++,
      ...finding,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.auditFindings.push(newFinding);
    return newFinding;
  }

  // Document operations
  async getDocuments(clientId: number): Promise<Document[]> {
    return this.documents.filter(d => d.clientId === clientId && d.isActive);
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const newDocument: Document = {
      id: this.nextId++,
      ...document,
      uploadedAt: new Date(),
      isActive: true
    };
    this.documents.push(newDocument);
    return newDocument;
  }

  // Compliance operations
  async getComplianceItems(clientId: number): Promise<ComplianceItem[]> {
    return this.complianceItems.filter(i => i.clientId === clientId);
  }

  async createComplianceItem(item: InsertComplianceItem): Promise<ComplianceItem> {
    const newItem: ComplianceItem = {
      id: this.nextId++,
      ...item,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.complianceItems.push(newItem);
    return newItem;
  }

  // Activity log operations
  async getActivityLog(clientId?: number): Promise<ActivityLog[]> {
    let logs = this.activityLogs;
    if (clientId) {
      logs = logs.filter(l => l.clientId === clientId);
    }
    return logs.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const newLog: ActivityLog = {
      id: this.nextId++,
      ...log,
      timestamp: new Date()
    };
    this.activityLogs.push(newLog);
    return newLog;
  }

  // Dashboard operations
  async getDashboardMetrics(firmId: number): Promise<any> {
    const clients = await this.getClients(firmId);
    const activeClients = clients.filter(c => c.status === 'active').length;
    const totalClients = clients.length;
    
    const allEngagements = this.auditEngagements.filter(e => 
      clients.some(c => c.id === e.clientId)
    );
    const activeAudits = allEngagements.filter(e => e.status === 'in_progress').length;
    
    const allCompliance = this.complianceItems.filter(i => 
      clients.some(c => c.id === i.clientId)
    );
    const pendingCompliance = allCompliance.filter(i => i.status === 'pending').length;
    
    const allDocuments = this.documents.filter(d => 
      clients.some(c => c.id === d.clientId) && d.isActive
    );
    const totalDocuments = allDocuments.length;

    return {
      activeClients: activeClients.toString(),
      totalClients: totalClients.toString(),
      activeAudits: activeAudits.toString(),
      totalAudits: allEngagements.length.toString(),
      pendingCompliance: pendingCompliance.toString(),
      totalDocuments: totalDocuments.toString(),
      completionRate: totalClients > 0 ? Math.round((activeClients / totalClients) * 100) : 0
    };
  }

  async getRecentActivity(firmId: number): Promise<any[]> {
    const clients = await this.getClients(firmId);
    const clientIds = clients.map(c => c.id);
    
    return this.activityLogs
      .filter(log => clientIds.includes(log.clientId || 0))
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, 10);
  }

  async getUpcomingDeadlines(firmId: number): Promise<any[]> {
    const clients = await this.getClients(firmId);
    const clientIds = clients.map(c => c.id);
    
    const now = new Date();
    const upcoming = this.complianceItems
      .filter(item => 
        clientIds.includes(item.clientId) && 
        item.dueDate && 
        new Date(item.dueDate) > now &&
        item.status !== 'completed'
      )
      .sort((a, b) => new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime())
      .slice(0, 5);
    
    return upcoming;
  }

  // Report template operations
  async getReportTemplates(): Promise<ReportTemplate[]> {
    return this.reportTemplates;
  }

  async createReportTemplate(template: InsertReportTemplate): Promise<ReportTemplate> {
    const newTemplate: ReportTemplate = {
      id: this.nextId++,
      ...template,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.reportTemplates.push(newTemplate);
    return newTemplate;
  }

  // Generated report operations
  async getGeneratedReports(clientId: number): Promise<GeneratedReport[]> {
    return this.generatedReports.filter(report => report.clientId === clientId);
  }

  async getGeneratedReport(id: number): Promise<GeneratedReport | undefined> {
    return this.generatedReports.find(report => report.id === id);
  }

  async createGeneratedReport(report: InsertGeneratedReport): Promise<GeneratedReport> {
    const newReport: GeneratedReport = {
      id: this.nextId++,
      ...report,
      generatedAt: new Date(),
    };
    this.generatedReports.push(newReport);
    return newReport;
  }
}