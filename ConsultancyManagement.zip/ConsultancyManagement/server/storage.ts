import { 
  users, clients, firms, financialPeriods, chartOfAccounts, trialBalanceEntries, generalLedgerEntries,
  financialStatements, auditEngagements, auditFindings, auditProcedures, icofrAssessments, documents, complianceItems,
  activityLog, validationResults, reportTemplates, generatedReports,
  type User, type InsertUser, type Client, type InsertClient, type Firm, type InsertFirm,
  type FinancialPeriod, type InsertFinancialPeriod, type ChartOfAccount, type InsertChartOfAccount,
  type TrialBalanceEntry, type InsertTrialBalanceEntry, type GeneralLedgerEntry, type InsertGeneralLedgerEntry,
  type FinancialStatement, type InsertFinancialStatement,
  type AuditEngagement, type InsertAuditEngagement, type AuditFinding, type InsertAuditFinding,
  type AuditProcedure, type InsertAuditProcedure, type IcofrAssessment, type InsertIcofrAssessment,
  type Document, type InsertDocument, type ComplianceItem, type InsertComplianceItem,
  type ActivityLog, type InsertActivityLog, type ValidationResult, type InsertValidationResult,
  type ReportTemplate, type InsertReportTemplate, type GeneratedReport, type InsertGeneratedReport
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User>;
  
  // Firm operations
  getFirm(id: number): Promise<Firm | undefined>;
  createFirm(firm: InsertFirm): Promise<Firm>;
  
  // Client operations
  getClients(firmId: number): Promise<Client[]>;
  getClient(id: number): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, client: Partial<InsertClient>): Promise<Client>;
  
  // Financial period operations
  getFinancialPeriods(clientId: number): Promise<FinancialPeriod[]>;
  createFinancialPeriod(period: InsertFinancialPeriod): Promise<FinancialPeriod>;
  
  // Chart of accounts operations
  getChartOfAccounts(clientId: number): Promise<ChartOfAccount[]>;
  createChartOfAccount(account: InsertChartOfAccount): Promise<ChartOfAccount>;
  
  // Trial balance operations
  getTrialBalanceEntries(clientId: number, periodId: number): Promise<TrialBalanceEntry[]>;
  createTrialBalanceEntry(entry: InsertTrialBalanceEntry): Promise<TrialBalanceEntry>;
  
  // General ledger operations
  getGeneralLedgerEntries(clientId: number, periodId: number): Promise<GeneralLedgerEntry[]>;
  createGeneralLedgerEntry(entry: InsertGeneralLedgerEntry): Promise<GeneralLedgerEntry>;
  getGeneralLedgerByAccount(clientId: number, periodId: number, accountId: number): Promise<GeneralLedgerEntry[]>;
  
  // Financial statement operations
  getFinancialStatements(clientId: number): Promise<FinancialStatement[]>;
  createFinancialStatement(statement: InsertFinancialStatement): Promise<FinancialStatement>;
  
  // Audit engagement operations
  getAuditEngagements(clientId: number): Promise<AuditEngagement[]>;
  createAuditEngagement(engagement: InsertAuditEngagement): Promise<AuditEngagement>;
  
  // Audit finding operations
  getAuditFindings(engagementId: number): Promise<AuditFinding[]>;
  createAuditFinding(finding: InsertAuditFinding): Promise<AuditFinding>;
  
  // Document operations
  getDocuments(clientId: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  
  // Compliance operations
  getComplianceItems(clientId: number): Promise<ComplianceItem[]>;
  createComplianceItem(item: InsertComplianceItem): Promise<ComplianceItem>;
  
  // Activity log operations
  getActivityLog(clientId?: number): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  
  // Dashboard operations
  getDashboardMetrics(firmId: number): Promise<any>;
  getRecentActivity(firmId: number): Promise<any[]>;
  getUpcomingDeadlines(firmId: number): Promise<any[]>;
  
  // Report template operations
  getReportTemplates(): Promise<ReportTemplate[]>;
  createReportTemplate(template: InsertReportTemplate): Promise<ReportTemplate>;
  
  // Generated report operations
  getGeneratedReports(clientId: number): Promise<GeneratedReport[]>;
  getGeneratedReport(id: number): Promise<GeneratedReport | undefined>;
  createGeneratedReport(report: InsertGeneratedReport): Promise<GeneratedReport>;
  
  // Enhanced audit operations
  getAuditProcedures(engagementId: number): Promise<AuditProcedure[]>;
  createAuditProcedure(procedure: InsertAuditProcedure): Promise<AuditProcedure>;
  updateAuditProcedure(id: number, procedure: Partial<InsertAuditProcedure>): Promise<AuditProcedure>;
  
  // ICOFR operations
  getIcofrAssessments(engagementId: number): Promise<IcofrAssessment[]>;
  createIcofrAssessment(assessment: InsertIcofrAssessment): Promise<IcofrAssessment>;
  updateIcofrAssessment(id: number, assessment: Partial<InsertIcofrAssessment>): Promise<IcofrAssessment>;
  
  // Enhanced audit analytics
  getAccountRiskAnalysis(clientId: number, periodId: number): Promise<any>;
  getTrialBalanceAnomalies(clientId: number, periodId: number): Promise<any>;
  getJournalEntryTesting(clientId: number, periodId: number, sampleSize?: number): Promise<any>;
  
  // Validation results operations
  getValidationResults(clientId: number): Promise<ValidationResult[]>;
  getValidationResult(id: number): Promise<ValidationResult | undefined>;
  createValidationResult(result: InsertValidationResult): Promise<ValidationResult>;
  updateValidationResult(id: number, result: Partial<InsertValidationResult>): Promise<ValidationResult>;
  markValidationResolved(id: number, resolvedBy: number): Promise<ValidationResult>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({ ...user, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Firm operations
  async getFirm(id: number): Promise<Firm | undefined> {
    const [firm] = await db.select().from(firms).where(eq(firms.id, id));
    return firm;
  }

  async createFirm(firm: InsertFirm): Promise<Firm> {
    const [newFirm] = await db.insert(firms).values(firm).returning();
    return newFirm;
  }

  // Client operations
  async getClients(firmId: number): Promise<Client[]> {
    return await db.select().from(clients).where(eq(clients.firmId, firmId)).orderBy(asc(clients.name));
  }

  async getClient(id: number): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client;
  }

  async createClient(client: InsertClient): Promise<Client> {
    // Handle empty fiscal year end date
    const clientData = {
      ...client,
      fiscalYearEnd: client.fiscalYearEnd === "" ? null : client.fiscalYearEnd
    };
    const [newClient] = await db.insert(clients).values(clientData).returning();
    return newClient;
  }

  async updateClient(id: number, client: Partial<InsertClient>): Promise<Client> {
    // Handle empty fiscal year end date
    const clientData = {
      ...client,
      fiscalYearEnd: client.fiscalYearEnd === "" ? null : client.fiscalYearEnd,
      updatedAt: new Date()
    };
    const [updatedClient] = await db
      .update(clients)
      .set(clientData)
      .where(eq(clients.id, id))
      .returning();
    return updatedClient;
  }

  // Financial period operations
  async getFinancialPeriods(clientId: number): Promise<FinancialPeriod[]> {
    return await db
      .select()
      .from(financialPeriods)
      .where(eq(financialPeriods.clientId, clientId))
      .orderBy(desc(financialPeriods.endDate));
  }

  async createFinancialPeriod(period: InsertFinancialPeriod): Promise<FinancialPeriod> {
    const [newPeriod] = await db.insert(financialPeriods).values(period).returning();
    return newPeriod;
  }

  // Chart of accounts operations
  async getChartOfAccounts(clientId: number): Promise<ChartOfAccount[]> {
    const results = await db
      .select()
      .from(chartOfAccounts)
      .where(and(eq(chartOfAccounts.clientId, clientId), eq(chartOfAccounts.isActive, true)))
      .orderBy(asc(chartOfAccounts.accountCode));
    return results;
  }

  async createChartOfAccount(account: InsertChartOfAccount): Promise<ChartOfAccount> {
    const [newAccount] = await db.insert(chartOfAccounts).values(account).returning();
    return newAccount;
  }

  // Trial balance operations
  async getTrialBalanceEntries(clientId: number, periodId: number): Promise<TrialBalanceEntry[]> {
    return await db
      .select()
      .from(trialBalanceEntries)
      .where(and(eq(trialBalanceEntries.clientId, clientId), eq(trialBalanceEntries.periodId, periodId)))
      .orderBy(asc(trialBalanceEntries.accountId));
  }

  async createTrialBalanceEntry(entry: InsertTrialBalanceEntry): Promise<TrialBalanceEntry> {
    const [newEntry] = await db.insert(trialBalanceEntries).values(entry).returning();
    return newEntry;
  }

  // General ledger operations
  async getGeneralLedgerEntries(clientId: number, periodId: number): Promise<GeneralLedgerEntry[]> {
    return await db
      .select()
      .from(generalLedgerEntries)
      .where(and(eq(generalLedgerEntries.clientId, clientId), eq(generalLedgerEntries.periodId, periodId)))
      .orderBy(asc(generalLedgerEntries.transactionDate), asc(generalLedgerEntries.accountId));
  }

  async createGeneralLedgerEntry(entry: InsertGeneralLedgerEntry): Promise<GeneralLedgerEntry> {
    const [newEntry] = await db.insert(generalLedgerEntries).values(entry).returning();
    return newEntry;
  }

  async getGeneralLedgerByAccount(clientId: number, periodId: number, accountId: number): Promise<GeneralLedgerEntry[]> {
    return await db
      .select()
      .from(generalLedgerEntries)
      .where(and(
        eq(generalLedgerEntries.clientId, clientId), 
        eq(generalLedgerEntries.periodId, periodId),
        eq(generalLedgerEntries.accountId, accountId)
      ))
      .orderBy(asc(generalLedgerEntries.transactionDate));
  }

  // Financial statement operations
  async getFinancialStatements(clientId: number): Promise<FinancialStatement[]> {
    return await db
      .select()
      .from(financialStatements)
      .where(eq(financialStatements.clientId, clientId))
      .orderBy(desc(financialStatements.generatedAt));
  }

  async createFinancialStatement(statement: InsertFinancialStatement): Promise<FinancialStatement> {
    const [newStatement] = await db.insert(financialStatements).values(statement).returning();
    return newStatement;
  }

  // Audit engagement operations
  async getAuditEngagements(clientId: number): Promise<AuditEngagement[]> {
    return await db
      .select()
      .from(auditEngagements)
      .where(eq(auditEngagements.clientId, clientId))
      .orderBy(desc(auditEngagements.startDate));
  }

  async createAuditEngagement(engagement: InsertAuditEngagement): Promise<AuditEngagement> {
    const [newEngagement] = await db.insert(auditEngagements).values(engagement).returning();
    return newEngagement;
  }

  // Audit finding operations
  async getAuditFindings(engagementId: number): Promise<AuditFinding[]> {
    return await db
      .select()
      .from(auditFindings)
      .where(eq(auditFindings.engagementId, engagementId))
      .orderBy(desc(auditFindings.createdAt));
  }

  async createAuditFinding(finding: InsertAuditFinding): Promise<AuditFinding> {
    const [newFinding] = await db.insert(auditFindings).values(finding).returning();
    return newFinding;
  }

  // Document operations
  async getDocuments(clientId: number): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(and(eq(documents.clientId, clientId), eq(documents.isActive, true)))
      .orderBy(desc(documents.uploadedAt));
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const [newDocument] = await db.insert(documents).values(document).returning();
    return newDocument;
  }

  // Compliance operations
  async getComplianceItems(clientId: number): Promise<ComplianceItem[]> {
    return await db
      .select()
      .from(complianceItems)
      .where(eq(complianceItems.clientId, clientId))
      .orderBy(asc(complianceItems.dueDate));
  }

  async createComplianceItem(item: InsertComplianceItem): Promise<ComplianceItem> {
    const [newItem] = await db.insert(complianceItems).values(item).returning();
    return newItem;
  }

  // Activity log operations
  async getActivityLog(clientId?: number): Promise<ActivityLog[]> {
    const query = db.select().from(activityLog);
    
    if (clientId) {
      return await query.where(eq(activityLog.clientId, clientId)).orderBy(desc(activityLog.timestamp)).limit(20);
    }
    
    return await query.orderBy(desc(activityLog.timestamp)).limit(20);
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const [newLog] = await db.insert(activityLog).values(log).returning();
    return newLog;
  }

  // Dashboard operations
  async getDashboardMetrics(firmId: number): Promise<any> {
    const activeClients = await db
      .select({ count: sql<number>`count(*)` })
      .from(clients)
      .where(and(eq(clients.firmId, firmId), eq(clients.status, 'active')));

    const activeAudits = await db
      .select({ count: sql<number>`count(*)` })
      .from(auditEngagements)
      .innerJoin(clients, eq(auditEngagements.clientId, clients.id))
      .where(and(eq(clients.firmId, firmId), eq(auditEngagements.status, 'in_progress')));

    const completedReports = await db
      .select({ count: sql<number>`count(*)` })
      .from(financialStatements)
      .innerJoin(clients, eq(financialStatements.clientId, clients.id))
      .where(and(eq(clients.firmId, firmId), eq(financialStatements.status, 'final')));

    const pendingCompliance = await db
      .select({ count: sql<number>`count(*)` })
      .from(complianceItems)
      .innerJoin(clients, eq(complianceItems.clientId, clients.id))
      .where(and(eq(clients.firmId, firmId), eq(complianceItems.status, 'pending')));

    return {
      activeClients: activeClients[0]?.count || 0,
      activeAudits: activeAudits[0]?.count || 0,
      completedReports: completedReports[0]?.count || 0,
      pendingCompliance: pendingCompliance[0]?.count || 0,
    };
  }

  async getRecentActivity(firmId: number): Promise<any[]> {
    return await db
      .select({
        id: activityLog.id,
        action: activityLog.action,
        description: activityLog.description,
        timestamp: activityLog.timestamp,
        userName: sql<string>`${users.firstName} || ' ' || ${users.lastName}`,
        clientName: clients.name,
      })
      .from(activityLog)
      .innerJoin(users, eq(activityLog.userId, users.id))
      .leftJoin(clients, eq(activityLog.clientId, clients.id))
      .where(eq(users.firmId, firmId))
      .orderBy(desc(activityLog.timestamp))
      .limit(10);
  }

  async getUpcomingDeadlines(firmId: number): Promise<any[]> {
    return await db
      .select({
        id: complianceItems.id,
        title: complianceItems.title,
        dueDate: complianceItems.dueDate,
        status: complianceItems.status,
        priority: complianceItems.priority,
        clientName: clients.name,
        assignedTo: sql<string>`${users.firstName} || ' ' || ${users.lastName}`,
      })
      .from(complianceItems)
      .innerJoin(clients, eq(complianceItems.clientId, clients.id))
      .leftJoin(users, eq(complianceItems.assignedTo, users.id))
      .where(eq(clients.firmId, firmId))
      .orderBy(asc(complianceItems.dueDate))
      .limit(10);
  }

  // Enhanced audit operations
  async getAuditProcedures(engagementId: number): Promise<AuditProcedure[]> {
    return await db
      .select()
      .from(auditProcedures)
      .where(eq(auditProcedures.engagementId, engagementId))
      .orderBy(desc(auditProcedures.createdAt));
  }

  async createAuditProcedure(procedure: InsertAuditProcedure): Promise<AuditProcedure> {
    const [newProcedure] = await db.insert(auditProcedures).values(procedure).returning();
    return newProcedure;
  }

  async updateAuditProcedure(id: number, procedure: Partial<InsertAuditProcedure>): Promise<AuditProcedure> {
    const [updatedProcedure] = await db
      .update(auditProcedures)
      .set({ ...procedure, updatedAt: new Date() })
      .where(eq(auditProcedures.id, id))
      .returning();
    return updatedProcedure;
  }

  // ICOFR operations
  async getIcofrAssessments(engagementId: number): Promise<IcofrAssessment[]> {
    return await db
      .select()
      .from(icofrAssessments)
      .where(eq(icofrAssessments.engagementId, engagementId))
      .orderBy(desc(icofrAssessments.createdAt));
  }

  async createIcofrAssessment(assessment: InsertIcofrAssessment): Promise<IcofrAssessment> {
    const [newAssessment] = await db.insert(icofrAssessments).values(assessment).returning();
    return newAssessment;
  }

  async updateIcofrAssessment(id: number, assessment: Partial<InsertIcofrAssessment>): Promise<IcofrAssessment> {
    const [updatedAssessment] = await db
      .update(icofrAssessments)
      .set({ ...assessment, updatedAt: new Date() })
      .where(eq(icofrAssessments.id, id))
      .returning();
    return updatedAssessment;
  }

  // Enhanced audit analytics
  async getAccountRiskAnalysis(clientId: number, periodId: number): Promise<any> {
    // Analyze account balances for risk indicators
    const riskAnalysis = await db
      .select({
        accountCode: chartOfAccounts.accountCode,
        accountName: chartOfAccounts.accountName,
        accountType: chartOfAccounts.accountType,
        balance: sql<number>`COALESCE(SUM(CASE WHEN ${trialBalanceEntries.debitAmount} IS NOT NULL THEN ${trialBalanceEntries.debitAmount} ELSE -${trialBalanceEntries.creditAmount} END), 0)`,
        entryCount: sql<number>`COUNT(${trialBalanceEntries.id})`,
        riskScore: sql<number>`
          CASE 
            WHEN ${chartOfAccounts.accountType} = 'Asset' AND COALESCE(SUM(CASE WHEN ${trialBalanceEntries.debitAmount} IS NOT NULL THEN ${trialBalanceEntries.debitAmount} ELSE -${trialBalanceEntries.creditAmount} END), 0) > 100000 THEN 3
            WHEN ${chartOfAccounts.accountType} = 'Revenue' AND COALESCE(SUM(CASE WHEN ${trialBalanceEntries.creditAmount} IS NOT NULL THEN ${trialBalanceEntries.creditAmount} ELSE -${trialBalanceEntries.debitAmount} END), 0) > 50000 THEN 2
            ELSE 1
          END
        `
      })
      .from(chartOfAccounts)
      .leftJoin(trialBalanceEntries, and(
        eq(chartOfAccounts.id, trialBalanceEntries.accountId),
        eq(trialBalanceEntries.periodId, periodId)
      ))
      .where(eq(chartOfAccounts.clientId, clientId))
      .groupBy(chartOfAccounts.id, chartOfAccounts.accountCode, chartOfAccounts.accountName, chartOfAccounts.accountType)
      .orderBy(sql`riskScore DESC`);

    return riskAnalysis;
  }

  async getTrialBalanceAnomalies(clientId: number, periodId: number): Promise<any> {
    // Detect anomalies in trial balance entries
    const anomalies = await db
      .select({
        accountCode: chartOfAccounts.accountCode,
        accountName: chartOfAccounts.accountName,
        debitAmount: trialBalanceEntries.debitAmount,
        creditAmount: trialBalanceEntries.creditAmount,
        anomalyType: sql<string>`
          CASE 
            WHEN ${trialBalanceEntries.debitAmount} IS NOT NULL AND ${trialBalanceEntries.creditAmount} IS NOT NULL THEN 'Both debit and credit'
            WHEN ${trialBalanceEntries.debitAmount} IS NULL AND ${trialBalanceEntries.creditAmount} IS NULL THEN 'No amount'
            WHEN ${trialBalanceEntries.debitAmount} > 1000000 OR ${trialBalanceEntries.creditAmount} > 1000000 THEN 'Large amount'
            ELSE 'Normal'
          END
        `
      })
      .from(trialBalanceEntries)
      .innerJoin(chartOfAccounts, eq(trialBalanceEntries.accountId, chartOfAccounts.id))
      .where(and(
        eq(chartOfAccounts.clientId, clientId),
        eq(trialBalanceEntries.periodId, periodId),
        sql`(
          (${trialBalanceEntries.debitAmount} IS NOT NULL AND ${trialBalanceEntries.creditAmount} IS NOT NULL) OR
          (${trialBalanceEntries.debitAmount} IS NULL AND ${trialBalanceEntries.creditAmount} IS NULL) OR
          ${trialBalanceEntries.debitAmount} > 1000000 OR ${trialBalanceEntries.creditAmount} > 1000000
        )`
      ));

    return anomalies;
  }

  async getJournalEntryTesting(clientId: number, periodId: number, sampleSize: number = 10): Promise<any> {
    // Get sample journal entries for testing
    const journalEntries = await db
      .select({
        id: generalLedgerEntries.id,
        accountCode: chartOfAccounts.accountCode,
        accountName: chartOfAccounts.accountName,
        transactionDate: generalLedgerEntries.transactionDate,
        description: generalLedgerEntries.description,
        reference: generalLedgerEntries.reference,
        debitAmount: generalLedgerEntries.debitAmount,
        creditAmount: generalLedgerEntries.creditAmount,
        riskLevel: sql<string>`
          CASE 
            WHEN ${generalLedgerEntries.debitAmount} > 50000 OR ${generalLedgerEntries.creditAmount} > 50000 THEN 'High'
            WHEN ${generalLedgerEntries.debitAmount} > 10000 OR ${generalLedgerEntries.creditAmount} > 10000 THEN 'Medium'
            ELSE 'Low'
          END
        `
      })
      .from(generalLedgerEntries)
      .innerJoin(chartOfAccounts, eq(generalLedgerEntries.accountId, chartOfAccounts.id))
      .where(and(
        eq(generalLedgerEntries.clientId, clientId),
        eq(generalLedgerEntries.periodId, periodId)
      ))
      .orderBy(sql`RANDOM()`)
      .limit(sampleSize);

    return journalEntries;
  }

  // Validation results operations
  async getValidationResults(clientId: number): Promise<ValidationResult[]> {
    return await db
      .select()
      .from(validationResults)
      .where(eq(validationResults.clientId, clientId))
      .orderBy(desc(validationResults.validatedAt));
  }

  async getValidationResult(id: number): Promise<ValidationResult | undefined> {
    const [result] = await db
      .select()
      .from(validationResults)
      .where(eq(validationResults.id, id));
    return result;
  }

  async createValidationResult(result: InsertValidationResult): Promise<ValidationResult> {
    const [createdResult] = await db
      .insert(validationResults)
      .values(result)
      .returning();
    return createdResult;
  }

  async updateValidationResult(id: number, result: Partial<InsertValidationResult>): Promise<ValidationResult> {
    const [updatedResult] = await db
      .update(validationResults)
      .set(result)
      .where(eq(validationResults.id, id))
      .returning();
    return updatedResult;
  }

  async markValidationResolved(id: number, resolvedBy: number): Promise<ValidationResult> {
    const [resolvedResult] = await db
      .update(validationResults)
      .set({
        resolved: true,
        resolvedAt: new Date(),
        resolvedBy: resolvedBy
      })
      .where(eq(validationResults.id, id))
      .returning();
    return resolvedResult;
  }

  // Report template operations
  async getReportTemplates(): Promise<ReportTemplate[]> {
    return await db
      .select()
      .from(reportTemplates)
      .where(eq(reportTemplates.isActive, true))
      .orderBy(asc(reportTemplates.name));
  }

  async createReportTemplate(template: InsertReportTemplate): Promise<ReportTemplate> {
    const [newTemplate] = await db.insert(reportTemplates).values(template).returning();
    return newTemplate;
  }

  // Generated report operations
  async getGeneratedReports(clientId: number): Promise<GeneratedReport[]> {
    return await db
      .select()
      .from(generatedReports)
      .where(eq(generatedReports.clientId, clientId))
      .orderBy(desc(generatedReports.generatedAt));
  }

  async getGeneratedReport(id: number): Promise<GeneratedReport | undefined> {
    const [report] = await db
      .select()
      .from(generatedReports)
      .where(eq(generatedReports.id, id));
    return report;
  }

  async createGeneratedReport(report: InsertGeneratedReport): Promise<GeneratedReport> {
    const [newReport] = await db.insert(generatedReports).values(report).returning();
    return newReport;
  }
}

import { MemoryStorage } from "./memory-storage";

// Use DatabaseStorage for persistent data storage
export const storage = new DatabaseStorage();
