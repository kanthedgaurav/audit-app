import XLSX from 'xlsx';
import fs from 'fs';
import path from 'path';
import { storage } from './storage';
import type { InsertChartOfAccount, InsertTrialBalanceEntry, InsertGeneralLedgerEntry } from '@shared/schema';

export interface FileProcessingResult {
  success: boolean;
  processedRows: number;
  errors: string[];
  skippedRows: number;
  message: string;
}

export class FileProcessor {
  /**
   * Process Chart of Accounts file and save to database
   * Expected columns: Account Code, Account Name, Account Type, Category, Sub Category, Parent Account Code
   */
  static async processChartOfAccountsFile(
    filePath: string, 
    clientId: number, 
    uploadedBy?: number
  ): Promise<FileProcessingResult> {
    try {
      console.log(`📊 Processing Chart of Accounts file: ${filePath}`);
      
      const workbook = XLSX.readFile(filePath);
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      console.log(`📋 Found ${jsonData.length} data rows in Excel file`);
      
      // Log the first few rows to understand the structure
      if (jsonData.length > 0) {
        console.log('📄 First row structure:', Object.keys(jsonData[0]));
        console.log('📄 First row data:', jsonData[0]);
        console.log('📄 Second row data:', jsonData[1]);
        
        // Try to auto-detect columns
        const columns = Object.keys(jsonData[0]);
        console.log('🔍 Auto-detecting columns...');
        
        // Look for account code variations
        const accountCodeCol = columns.find(col => 
          col.toLowerCase().includes('account') && col.toLowerCase().includes('code') ||
          col.toLowerCase().includes('a/c') && col.toLowerCase().includes('code') ||
          col.toLowerCase().includes('ac') && col.toLowerCase().includes('code') ||
          col.toLowerCase().includes('code')
        );
        
        // Look for account name variations
        const accountNameCol = columns.find(col => 
          col.toLowerCase().includes('account') && col.toLowerCase().includes('name') ||
          col.toLowerCase().includes('a/c') && col.toLowerCase().includes('name') ||
          col.toLowerCase().includes('ac') && col.toLowerCase().includes('name') ||
          col.toLowerCase().includes('name')
        );
        
        // Look for account type variations  
        const accountTypeCol = columns.find(col => 
          col.toLowerCase().includes('account') && col.toLowerCase().includes('type') ||
          col.toLowerCase().includes('a/c') && col.toLowerCase().includes('type') ||
          col.toLowerCase().includes('ac') && col.toLowerCase().includes('type') ||
          col.toLowerCase().includes('type')
        );
        
        console.log('🔍 Auto-detected columns:', {
          accountCode: accountCodeCol,
          accountName: accountNameCol,
          accountType: accountTypeCol
        });
      }

      let processedRows = 0;
      let skippedRows = 0;
      const errors: string[] = [];

      for (let i = 0; i < jsonData.length; i++) {
        const row = jsonData[i] as any;
        
        try {
          // Map common column variations to standard names
          const accountCode = row['Account Code'] || row['AccountCode'] || row['Code'] || row['account_code'] || row['A/C Code'] || row['AC Code'] || row['Account Number'] || row['AccountNumber'];
          const accountName = row['Account Name'] || row['AccountName'] || row['Name'] || row['account_name'] || row['A/C Name'] || row['AC Name'];
          const accountType = row['Account Type'] || row['AccountType'] || row['Type'] || row['account_type'] || row['A/C Type'] || row['AC Type'];
          const category = row['Category'] || row['account_category'];
          const subCategory = row['Sub Category'] || row['SubCategory'] || row['sub_category'];
          const parentAccountCode = row['Parent Account Code'] || row['ParentAccountCode'] || row['parent_account_code'];

          console.log(`🔍 Row ${i + 1}: accountCode=${accountCode}, accountName=${accountName}, accountType=${accountType}`);

          // Validate required fields
          if (!accountCode || !accountName || !accountType) {
            console.log(`⚠️ Row ${i + 2}: Missing required fields. Available columns:`, Object.keys(row));
            errors.push(`Row ${i + 2}: Missing required fields (Account Code, Account Name, Account Type). Available columns: ${Object.keys(row).join(', ')}`);
            skippedRows++;
            continue;
          }

          // Find parent account ID if parent code is provided
          let parentAccountId: number | null = null;
          if (parentAccountCode) {
            const parentAccount = await storage.getChartOfAccounts(clientId);
            const parent = parentAccount.find(acc => acc.accountCode === parentAccountCode);
            if (parent) {
              parentAccountId = parent.id;
            }
          }

          const chartOfAccountData: InsertChartOfAccount = {
            clientId,
            accountCode: String(accountCode).trim(),
            accountName: String(accountName).trim(),
            accountType: String(accountType).trim(),
            category: category ? String(category).trim() : undefined,
            subCategory: subCategory ? String(subCategory).trim() : undefined,
            parentAccountId,
            isActive: true
          };

          await storage.createChartOfAccount(chartOfAccountData);
          processedRows++;
          console.log(`✅ Successfully processed account: ${accountCode} - ${accountName}`);

        } catch (error) {
          console.log(`❌ Error processing row ${i + 2}:`, error.message);
          errors.push(`Row ${i + 2}: ${error.message}`);
          skippedRows++;
        }
      }

      console.log(`📊 Processing complete: ${processedRows} processed, ${skippedRows} skipped`);

      return {
        success: true,
        processedRows,
        errors,
        skippedRows,
        message: `Successfully processed ${processedRows} chart of accounts entries${errors.length > 0 ? `. Errors: ${errors.join('; ')}` : ''}`
      };

    } catch (error) {
      return {
        success: false,
        processedRows: 0,
        errors: [error.message],
        skippedRows: 0,
        message: `Failed to process chart of accounts file: ${error.message}`
      };
    }
  }

  /**
   * Process Trial Balance file and save to database
   * Expected columns: Account Code, Account Name, Debit Amount, Credit Amount
   */
  static async processTrialBalanceFile(
    filePath: string, 
    clientId: number, 
    periodId: number, 
    uploadedBy?: number
  ): Promise<FileProcessingResult> {
    try {
      console.log(`📊 Processing Trial Balance file: ${filePath}`);
      
      const workbook = XLSX.readFile(filePath);
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      
      // Try different parsing approaches to handle various Excel formats
      let jsonData: any[] = [];
      let headerRowIndex = 0;
      
      // First, try to parse normally
      jsonData = XLSX.utils.sheet_to_json(worksheet);
      
      // If we get __EMPTY__ columns, try to find the actual header row
      if (jsonData.length > 0 && Object.keys(jsonData[0]).some(key => key.includes('__EMPTY'))) {
        console.log('🔍 Detected __EMPTY__ columns, trying to find header row...');
        
        // Try parsing with different header row options
        for (let headerRow = 0; headerRow < Math.min(5, jsonData.length); headerRow++) {
          try {
            const testData = XLSX.utils.sheet_to_json(worksheet, { range: headerRow });
            if (testData.length > 0) {
              const keys = Object.keys(testData[0]);
              console.log(`🔍 Testing header row ${headerRow}:`, keys);
              
              // Check if this row has reasonable column names
              const hasAccountCode = keys.some(key => 
                key && typeof key === 'string' && 
                (key.toLowerCase().includes('account') || 
                 key.toLowerCase().includes('code') ||
                 key.toLowerCase().includes('name') ||
                 !key.includes('__EMPTY'))
              );
              
              if (hasAccountCode) {
                console.log(`✅ Found proper header row at index ${headerRow}`);
                jsonData = testData;
                headerRowIndex = headerRow;
                break;
              }
            }
          } catch (e) {
            console.log(`❌ Failed to parse with header row ${headerRow}:`, (e as Error).message);
          }
        }
      }
      
      // If still no luck, try parsing as array and then convert to objects manually
      if (jsonData.length === 0 || Object.keys(jsonData[0]).every(key => key.includes('__EMPTY'))) {
        console.log('🔍 Trying array-based parsing...');
        const arrayData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        
        if (arrayData.length > 1) {
          // Find the header row by looking for row with string values
          let headerIdx = 0;
          for (let i = 0; i < Math.min(5, arrayData.length); i++) {
            const row = arrayData[i] as any[];
            if (row && row.some(cell => typeof cell === 'string' && cell.trim().length > 0)) {
              headerIdx = i;
              break;
            }
          }
          
          const headers = arrayData[headerIdx] as string[];
          console.log('🔍 Found headers:', headers);
          
          jsonData = [];
          for (let i = headerIdx + 1; i < arrayData.length; i++) {
            const row = arrayData[i] as any[];
            if (row && row.length > 0) {
              const obj: any = {};
              headers.forEach((header, idx) => {
                if (header && typeof header === 'string') {
                  obj[header.trim()] = row[idx];
                } else {
                  obj[`Column_${idx}`] = row[idx];
                }
              });
              jsonData.push(obj);
            }
          }
        }
      }

      console.log(`📋 Found ${jsonData.length} data rows in Trial Balance file`);
      
      // Log the first few rows to understand the structure
      if (jsonData.length > 0) {
        console.log('📄 Trial Balance first row structure:', Object.keys(jsonData[0]));
        console.log('📄 Trial Balance first row data:', jsonData[0]);
        if (jsonData[1]) {
          console.log('📄 Trial Balance second row data:', jsonData[1]);
        }
        
        // Log all available columns to help with debugging
        const firstRow = jsonData[0];
        console.log('🔍 Available columns in TB file:');
        Object.keys(firstRow).forEach(key => {
          console.log(`  - "${key}": ${firstRow[key]}`);
        });
      }

      const chartOfAccounts = await storage.getChartOfAccounts(clientId);
      console.log(`📋 Found ${chartOfAccounts.length} accounts in Chart of Accounts`);
      
      let processedRows = 0;
      let skippedRows = 0;
      const errors: string[] = [];

      for (let i = 0; i < jsonData.length; i++) {
        const row = jsonData[i] as any;
        
        try {
          // Enhanced column mapping with flexible matching
          const keys = Object.keys(row);
          
          // Find account code column (more flexible matching)
          const accountCodeKey = keys.find(key => 
            key && typeof key === 'string' && (
              key.toLowerCase().includes('account') && key.toLowerCase().includes('code') ||
              key.toLowerCase().includes('a/c') && key.toLowerCase().includes('code') ||
              key.toLowerCase().includes('ac') && key.toLowerCase().includes('code') ||
              key.toLowerCase().includes('acct') && key.toLowerCase().includes('code') ||
              key.toLowerCase() === 'code' ||
              key.toLowerCase() === 'account code' ||
              key.toLowerCase() === 'account number' ||
              key.toLowerCase() === 'accountcode' ||
              key.toLowerCase() === 'accountnumber' ||
              /^a\/c\s*code$/i.test(key) ||
              /^ac\s*code$/i.test(key) ||
              /column_0/i.test(key) // Sometimes first column
            )
          );
          
          // Find account name column
          const accountNameKey = keys.find(key => 
            key && typeof key === 'string' && (
              key.toLowerCase().includes('account') && key.toLowerCase().includes('name') ||
              key.toLowerCase().includes('a/c') && key.toLowerCase().includes('name') ||
              key.toLowerCase().includes('ac') && key.toLowerCase().includes('name') ||
              key.toLowerCase().includes('acct') && key.toLowerCase().includes('name') ||
              key.toLowerCase() === 'name' ||
              key.toLowerCase() === 'account name' ||
              key.toLowerCase() === 'accountname' ||
              key.toLowerCase() === 'description' ||
              /^a\/c\s*name$/i.test(key) ||
              /^ac\s*name$/i.test(key) ||
              /column_1/i.test(key) // Sometimes second column
            )
          );
          
          // Find debit amount column
          const debitKey = keys.find(key => 
            key && typeof key === 'string' && (
              key.toLowerCase().includes('debit') ||
              key.toLowerCase() === 'dr' ||
              key.toLowerCase() === 'debits' ||
              key.toLowerCase().includes('debit amount') ||
              key.toLowerCase().includes('debitamount') ||
              key.toLowerCase().includes('debits ($)') ||
              /column_2/i.test(key) || // Sometimes third column
              /column_3/i.test(key)
            )
          );
          
          // Find credit amount column
          const creditKey = keys.find(key => 
            key && typeof key === 'string' && (
              key.toLowerCase().includes('credit') ||
              key.toLowerCase() === 'cr' ||
              key.toLowerCase() === 'credits' ||
              key.toLowerCase().includes('credit amount') ||
              key.toLowerCase().includes('creditamount') ||
              key.toLowerCase().includes('credits ($)') ||
              /column_3/i.test(key) || // Sometimes fourth column
              /column_4/i.test(key)
            )
          );
          
          const accountCode = accountCodeKey ? row[accountCodeKey] : null;
          const accountName = accountNameKey ? row[accountNameKey] : null;
          const debitAmount = debitKey ? row[debitKey] : 0;
          const creditAmount = creditKey ? row[creditKey] : 0;
          
          console.log(`🔍 TB Row ${i + 1}: Found keys - accountCode: "${accountCodeKey}" (${accountCode}), accountName: "${accountNameKey}" (${accountName}), debit: "${debitKey}" (${debitAmount}), credit: "${creditKey}" (${creditAmount})`);
          
          // Skip rows with completely empty data
          if (!accountCode && !accountName && (!debitAmount || debitAmount === 0) && (!creditAmount || creditAmount === 0)) {
            console.log(`⏭️ TB Row ${i + 1}: Skipping empty row`);
            skippedRows++;
            continue;
          }

          console.log(`🔍 TB Row ${i + 1}: accountCode=${accountCode}, accountName=${accountName}, debit=${debitAmount}, credit=${creditAmount}`);

          // Validate required fields
          if (!accountCode) {
            console.log(`⚠️ TB Row ${i + 2}: Missing Account Code. Available columns:`, Object.keys(row));
            errors.push(`Row ${i + 2}: Missing Account Code. Available columns: ${Object.keys(row).join(', ')}`);
            skippedRows++;
            continue;
          }

          // Find matching account in chart of accounts or create auto account
          let matchingAccount = chartOfAccounts.find(acc => 
            acc.accountCode === String(accountCode).trim() || 
            acc.accountName.toLowerCase() === String(accountName || '').toLowerCase().trim()
          );

          // If no matching account found and we have account code/name, create one automatically
          if (!matchingAccount && accountCode && accountName) {
            console.log(`🔧 Auto-creating account: ${accountCode} - ${accountName}`);
            
            // Determine account type based on account code patterns (basic heuristics)
            let accountType = 'Asset'; // default
            const code = String(accountCode).trim();
            if (code.startsWith('1')) accountType = 'Asset';
            else if (code.startsWith('2')) accountType = 'Liability';
            else if (code.startsWith('3')) accountType = 'Equity';
            else if (code.startsWith('4')) accountType = 'Revenue';
            else if (code.startsWith('5')) accountType = 'Expense';
            
            try {
              const newAccount: InsertChartOfAccount = {
                clientId,
                accountCode: String(accountCode).trim(),
                accountName: String(accountName).trim(),
                accountType,
                isActive: true
              };
              
              matchingAccount = await storage.createChartOfAccount(newAccount);
              console.log(`✅ Auto-created account: ${matchingAccount.accountCode} - ${matchingAccount.accountName}`);
            } catch (createError) {
              console.log(`❌ Failed to auto-create account: ${(createError as Error).message}`);
              errors.push(`Row ${i + 2}: Account Code "${accountCode}" not found in Chart of Accounts and failed to auto-create`);
              skippedRows++;
              continue;
            }
          } else if (!matchingAccount) {
            errors.push(`Row ${i + 2}: Account Code "${accountCode}" not found in Chart of Accounts and insufficient data to auto-create`);
            skippedRows++;
            continue;
          }

          const trialBalanceData: InsertTrialBalanceEntry = {
            clientId,
            periodId,
            accountId: matchingAccount.id,
            debitAmount: String(parseFloat(String(debitAmount)) || 0),
            creditAmount: String(parseFloat(String(creditAmount)) || 0),
            uploadedBy
          };

          await storage.createTrialBalanceEntry(trialBalanceData);
          processedRows++;
          console.log(`✅ Successfully processed TB entry: ${accountCode} - ${accountName}`);

        } catch (error) {
          console.log(`❌ Error processing TB row ${i + 2}:`, error.message);
          errors.push(`Row ${i + 2}: ${error.message}`);
          skippedRows++;
        }
      }

      console.log(`📊 TB Processing complete: ${processedRows} processed, ${skippedRows} skipped`);

      return {
        success: true,
        processedRows,
        errors,
        skippedRows,
        message: `Successfully processed ${processedRows} trial balance entries${errors.length > 0 ? `. Errors: ${errors.join('; ')}` : ''}`
      };

    } catch (error) {
      return {
        success: false,
        processedRows: 0,
        errors: [error.message],
        skippedRows: 0,
        message: `Failed to process trial balance file: ${error.message}`
      };
    }
  }

  /**
   * Process General Ledger file and save to database
   * Expected columns: Account Code, Transaction Date, Description, Reference, Debit Amount, Credit Amount
   */
  static async processGeneralLedgerFile(
    filePath: string, 
    clientId: number, 
    periodId: number, 
    uploadedBy?: number
  ): Promise<FileProcessingResult> {
    try {
      console.log(`📊 Processing General Ledger file: ${filePath}`);
      
      const workbook = XLSX.readFile(filePath);
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      console.log(`📋 Found ${jsonData.length} data rows in General Ledger file`);
      
      // Log the first few rows to understand the structure
      if (jsonData.length > 0) {
        console.log('📄 General Ledger first row structure:', Object.keys(jsonData[0]));
        console.log('📄 General Ledger first row data:', jsonData[0]);
        if (jsonData[1]) {
          console.log('📄 General Ledger second row data:', jsonData[1]);
        }
        
        // Log all available columns to help with debugging
        const firstRow = jsonData[0];
        console.log('🔍 Available columns in GL file:');
        Object.keys(firstRow).forEach(key => {
          console.log(`  - "${key}": ${firstRow[key]}`);
        });
      }

      const chartOfAccounts = await storage.getChartOfAccounts(clientId);
      console.log(`📋 Found ${chartOfAccounts.length} accounts in Chart of Accounts`);
      
      let processedRows = 0;
      let skippedRows = 0;
      const errors: string[] = [];

      for (let i = 0; i < jsonData.length; i++) {
        const row = jsonData[i] as any;
        
        try {
          // Map common column variations to standard names
          const accountCode = row['Account Code'] || row['AccountCode'] || row['Code'] || row['account_code'] || row['Account Number'] || row['AccountNumber'];
          const transactionDate = row['Transaction Date'] || row['TransactionDate'] || row['Date'] || row['transaction_date'];
          const description = row['Description'] || row['Narration'] || row['Particulars'] || row['description'];
          const reference = row['Reference'] || row['Ref'] || row['Voucher'] || row['reference'];
          const debitAmount = row['Debit Amount'] || row['DebitAmount'] || row['Debit'] || row['debit_amount'] || row['Dr'] || row['Debits ($)'] || row['Debits'] || row['Debit ($)'] || 0;
          const creditAmount = row['Credit Amount'] || row['CreditAmount'] || row['Credit'] || row['credit_amount'] || row['Cr'] || row['Credits ($)'] || row['Credits'] || row['Credit ($)'] || 0;

          console.log(`🔍 GL Row ${i + 1}: accountCode=${accountCode}, date=${transactionDate}, desc=${description}, debit=${debitAmount}, credit=${creditAmount}`);

          // Validate required fields
          if (!accountCode || !transactionDate || !description) {
            console.log(`⚠️ GL Row ${i + 2}: Missing required fields. Available columns:`, Object.keys(row));
            errors.push(`Row ${i + 2}: Missing required fields (Account Code, Transaction Date, Description). Available columns: ${Object.keys(row).join(', ')}`);
            skippedRows++;
            continue;
          }

          // Find matching account in chart of accounts
          const matchingAccount = chartOfAccounts.find(acc => 
            acc.accountCode === String(accountCode).trim()
          );

          if (!matchingAccount) {
            errors.push(`Row ${i + 2}: Account Code "${accountCode}" not found in Chart of Accounts`);
            skippedRows++;
            continue;
          }

          // Parse date (handle Excel serial dates)
          let parsedDate: Date;
          try {
            if (typeof transactionDate === 'number') {
              // Excel serial date: days since January 1, 1900
              parsedDate = new Date((transactionDate - 25569) * 86400 * 1000);
            } else {
              parsedDate = new Date(transactionDate);
            }
            if (isNaN(parsedDate.getTime())) {
              throw new Error('Invalid date format');
            }
          } catch (dateError) {
            errors.push(`Row ${i + 2}: Invalid date format "${transactionDate}"`);
            skippedRows++;
            continue;
          }

          const generalLedgerData: InsertGeneralLedgerEntry = {
            clientId,
            periodId,
            accountId: matchingAccount.id,
            transactionDate: parsedDate.toISOString().split('T')[0], // Format as YYYY-MM-DD
            description: String(description).trim(),
            reference: reference ? String(reference).trim() : undefined,
            debitAmount: String(parseFloat(String(debitAmount)) || 0),
            creditAmount: String(parseFloat(String(creditAmount)) || 0),
            runningBalance: "0.00", // Will be calculated later
            uploadedBy
          };

          await storage.createGeneralLedgerEntry(generalLedgerData);
          processedRows++;
          console.log(`✅ Successfully processed GL entry: ${accountCode} - ${description}`);

        } catch (error) {
          console.log(`❌ Error processing GL row ${i + 2}:`, error.message);
          errors.push(`Row ${i + 2}: ${error.message}`);
          skippedRows++;
        }
      }

      console.log(`📊 GL Processing complete: ${processedRows} processed, ${skippedRows} skipped`);

      return {
        success: true,
        processedRows,
        errors,
        skippedRows,
        message: `Successfully processed ${processedRows} general ledger entries${errors.length > 0 ? `. Errors: ${errors.join('; ')}` : ''}`
      };

    } catch (error) {
      return {
        success: false,
        processedRows: 0,
        errors: [error.message],
        skippedRows: 0,
        message: `Failed to process general ledger file: ${error.message}`
      };
    }
  }

  /**
   * Detect file type based on column headers
   */
  static detectFileType(filePath: string): 'chart_of_accounts' | 'trial_balance' | 'general_ledger' | 'unknown' {
    try {
      const workbook = XLSX.readFile(filePath);
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      
      if (jsonData.length === 0) return 'unknown';
      
      const headers = (jsonData[0] as string[]).map(h => h?.toLowerCase() || '');
      
      // Check for Chart of Accounts indicators
      if (headers.some(h => h.includes('account code') || h.includes('accountcode')) &&
          headers.some(h => h.includes('account name') || h.includes('accountname')) &&
          headers.some(h => h.includes('account type') || h.includes('accounttype'))) {
        return 'chart_of_accounts';
      }
      
      // Check for General Ledger indicators
      if (headers.some(h => h.includes('transaction date') || h.includes('date')) &&
          headers.some(h => h.includes('description') || h.includes('narration')) &&
          headers.some(h => h.includes('reference') || h.includes('voucher'))) {
        return 'general_ledger';
      }
      
      // Check for Trial Balance indicators
      if (headers.some(h => h.includes('debit') || h.includes('dr')) &&
          headers.some(h => h.includes('credit') || h.includes('cr')) &&
          headers.some(h => h.includes('account'))) {
        return 'trial_balance';
      }
      
      return 'unknown';
    } catch (error) {
      return 'unknown';
    }
  }
}