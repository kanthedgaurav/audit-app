import { Client } from '@replit/object-storage';
import fs from 'fs';
import path from 'path';
import { db } from './db';
import { sql } from 'drizzle-orm';

// Initialize Replit Object Storage client
let client: Client | null = null;
let useObjectStorage = false;

// Initialize Object Storage - currently disabled due to permissions issue
// The service account 'heimdall-production@replit-user-deployments.iam.gserviceaccount.com' 
// lacks 'storage.objects.create' permission even with user-created buckets
try {
  client = new Client();
  useObjectStorage = false; // Temporarily disabled until permissions resolved
  console.log('⚠ Object Storage client ready but disabled due to permission issue');
  console.log('💡 Check that your bucket has proper write permissions for workspace service account');
} catch (error) {
  console.error('✗ Object Storage initialization failed:', error.message);
  useObjectStorage = false;
}

export interface FileUploadResult {
  success: boolean;
  filePath?: string;
  error?: string;
}

export class FileStorageService {
  /**
   * Upload a file to Replit Object Storage
   * @param file Multer file object
   * @param clientId Client ID for organizing files
   * @param category File category (trial_balance, chart_of_accounts, etc.)
   */
  async uploadFile(file: Express.Multer.File, clientId: number, category: string): Promise<FileUploadResult> {
    try {
      const timestamp = Date.now();
      const fileName = file.originalname;
      const objectPath = `client-${clientId}/${category}/${timestamp}-${fileName}`;
      
      // Read file data
      const fileData = fs.readFileSync(file.path);
      
      if (useObjectStorage && client) {
        // Try Object Storage first
        try {
          const { ok, error } = await client.uploadFromBytes(objectPath, fileData);
          
          if (ok) {
            // Clean up temporary file
            try {
              fs.unlinkSync(file.path);
            } catch (cleanupError) {
              console.warn('Failed to clean up temporary file:', cleanupError);
            }
            
            console.log('✓ File uploaded to Object Storage:', objectPath);
            return {
              success: true,
              filePath: objectPath
            };
          } else {
            console.warn('Object Storage upload failed, falling back to database:', error);
          }
        } catch (storageError) {
          console.warn('Object Storage error, falling back to database:', storageError.message);
        }
      }
      
      // Fallback to secure local filesystem storage for now
      console.log('📁 Using secure local filesystem storage for:', fileName);
      
      // Create organized directory structure 
      const storageDir = path.join(process.cwd(), 'secure-storage', `client-${clientId}`, category);
      await fs.promises.mkdir(storageDir, { recursive: true });
      
      // Create unique filename with timestamp
      const secureFileName = `${timestamp}-${fileName}`;
      const finalPath = path.join(storageDir, secureFileName);
      
      // Move file to secure storage
      await fs.promises.copyFile(file.path, finalPath);
      
      // Clean up temporary file
      try {
        fs.unlinkSync(file.path);
      } catch (cleanupError) {
        console.warn('Failed to clean up temporary file:', cleanupError);
      }
      
      return {
        success: true,
        filePath: `secure-storage/client-${clientId}/${category}/${secureFileName}`
      };
      
    } catch (error) {
      console.error('File upload error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }
  
  /**
   * Download a file from Replit Object Storage
   * @param filePath Path to file in object storage
   */
  async downloadFile(filePath: string): Promise<Buffer | null> {
    try {
      if (filePath.startsWith('secure-storage/')) {
        // Download from local secure storage
        const fullPath = path.join(process.cwd(), filePath);
        if (fs.existsSync(fullPath)) {
          return fs.readFileSync(fullPath);
        }
        return null;
      }
      
      if (useObjectStorage && client) {
        const { ok, value, error } = await client.downloadAsBytes(filePath);
        
        if (!ok || !value) {
          console.error('Object Storage download failed:', error);
          return null;
        }
        
        return Buffer.from(value);
      }
      
      console.error('No storage method available for file:', filePath);
      return null;
    } catch (error) {
      console.error('File download error:', error);
      return null;
    }
  }
  
  /**
   * Delete a file from Replit Object Storage
   * @param filePath Path to file in object storage
   */
  async deleteFile(filePath: string): Promise<boolean> {
    try {
      if (useObjectStorage && client) {
        const { ok, error } = await client.delete(filePath);
        
        if (!ok) {
          console.error('Object Storage delete failed:', error);
          return false;
        }
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('File delete error:', error);
      return false;
    }
  }
  
  /**
   * Check if a file exists in Replit Object Storage
   * @param filePath Path to file in object storage
   */
  async fileExists(filePath: string): Promise<boolean> {
    try {
      if (useObjectStorage && client) {
        const { ok } = await client.downloadAsBytes(filePath);
        return ok;
      }
      return false;
    } catch (error) {
      return false;
    }
  }
  
  /**
   * Get file URL for download (generates temporary signed URL if needed)
   * @param filePath Path to file in object storage
   */
  getFileUrl(filePath: string): string {
    // For now, return the file path - in production you might want signed URLs
    return `/api/files/download/${encodeURIComponent(filePath)}`;
  }
}

export const fileStorage = new FileStorageService();