import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertClientSchema, insertUserSchema, insertFinancialPeriodSchema,
  insertChartOfAccountsSchema, insertTrialBalanceEntrySchema, insertGeneralLedgerEntrySchema,
  insertFinancialStatementSchema, insertAuditEngagementSchema,
  insertAuditFindingSchema, insertAuditProcedureSchema, insertIcofrAssessmentSchema,
  insertDocumentSchema, insertComplianceItemSchema,
  insertActivityLogSchema, insertReportTemplateSchema, insertGeneratedReportSchema
} from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileStorage } from "./file-storage";
import { FileProcessor } from "./file-processor";

const upload = multer({ 
  dest: 'uploads/',
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Financial statement generation function with format support
function generateFinancialStatement(trialBalance: any[], chartOfAccounts: any[], statementType: string, client: any, period: any, format: string = 'vertical', cashFlowMethod: string = 'indirect') {
  const metadata = {
    generatedAt: new Date().toISOString(),
    regime: getReportingRegime(format),
    currency: "AED",
    clientName: client.name,
    period: `Year ended ${period.endDate}`,
    format: format
  };

  // Helper function to determine reporting regime based on format
  function getReportingRegime(format: string) {
    switch (format) {
      case 'uae_standard':
        return 'UAE Standards';
      case 'ifrs_standard':
        return 'IFRS';
      case 'schedule_iii':
        return 'Indian Companies Act 2013';
      default:
        return 'IFRS';
    }
  }

  // Create account lookup map
  const accountMap = new Map();
  chartOfAccounts.forEach(account => {
    accountMap.set(account.id, account);
  });

  // Create balance map from trial balance (sum multiple entries for same account)
  const balanceMap = new Map();
  trialBalance.forEach(entry => {
    const account = accountMap.get(entry.accountId);
    if (account) {
      const existing = balanceMap.get(account.accountCode);
      if (existing) {
        // Sum the amounts if account already exists
        balanceMap.set(account.accountCode, {
          debit: existing.debit + parseFloat(entry.debitAmount || "0"),
          credit: existing.credit + parseFloat(entry.creditAmount || "0"),
          account: account
        });
      } else {
        // Create new entry
        balanceMap.set(account.accountCode, {
          debit: parseFloat(entry.debitAmount || "0"),
          credit: parseFloat(entry.creditAmount || "0"),
          account: account
        });
      }
    }
  });

  if (statementType === 'balance_sheet') {
    // Generate Balance Sheet
    const assets = {
      current: {
        cash: getAccountBalance('100', balanceMap),
        receivables: getAccountBalance('105', balanceMap),
        inventory: getAccountBalance('110', balanceMap),
        prepaid: getAccountBalance('115', balanceMap),
        total: 0
      },
      nonCurrent: {
        property: getAccountBalance('140', balanceMap),
        equipment: getAccountBalance('150', balanceMap),
        intangible: getAccountBalance('160', balanceMap),
        total: 0
      },
      totalAssets: 0
    };

    const liabilities = {
      current: {
        payables: getAccountBalance('200', balanceMap),
        accrued: getAccountBalance('205', balanceMap), // Unearned Revenue
        shortTermDebt: getAccountBalance('220', balanceMap),
        total: 0
      },
      nonCurrent: {
        longTermDebt: getAccountBalance('240', balanceMap),
        provisions: getAccountBalance('250', balanceMap),
        total: 0
      },
      totalLiabilities: 0
    };

    // Calculate net income from revenue and expense accounts
    const revenues = getAccountBalance('400', balanceMap) + getAccountBalance('405', balanceMap); // Sales + Service Revenue
    const expenses = Math.abs(getAccountBalance('500', balanceMap)) + Math.abs(getAccountBalance('505', balanceMap)) + 
                    Math.abs(getAccountBalance('510', balanceMap)) + Math.abs(getAccountBalance('515', balanceMap)); // All expenses
    const netIncome = revenues - expenses;
    


    const equity = {
      shareCapital: getAccountBalance('300', balanceMap),
      retainedEarnings: getAccountBalance('305', balanceMap) + netIncome, // Add net income to retained earnings
      totalEquity: 0
    };

    // Calculate totals
    assets.current.total = assets.current.cash + assets.current.receivables + assets.current.inventory + assets.current.prepaid;
    assets.nonCurrent.total = assets.nonCurrent.property + assets.nonCurrent.equipment + assets.nonCurrent.intangible;
    assets.totalAssets = assets.current.total + assets.nonCurrent.total;

    liabilities.current.total = liabilities.current.payables + liabilities.current.accrued + liabilities.current.shortTermDebt;
    liabilities.nonCurrent.total = liabilities.nonCurrent.longTermDebt + liabilities.nonCurrent.provisions;
    liabilities.totalLiabilities = liabilities.current.total + liabilities.nonCurrent.total;

    equity.totalEquity = equity.shareCapital + equity.retainedEarnings;

    // Validate balance sheet equation: Assets = Liabilities + Equity
    const totalEquityLiabilities = liabilities.totalLiabilities + equity.totalEquity;
    const balanceDifference = Math.abs(assets.totalAssets - totalEquityLiabilities);
    
    if (balanceDifference > 0.01) { // Allow for small rounding differences
      throw new Error(`Balance Sheet does not balance. Assets: ${assets.totalAssets.toLocaleString()}, Liabilities + Equity: ${totalEquityLiabilities.toLocaleString()}, Difference: ${balanceDifference.toLocaleString()}`);
    }
    
    // Add totalEquityLiabilities for template rendering
    const totalEquityLiabilitiesField = totalEquityLiabilities;

    return {
      metadata,
      sections: {
        assets,
        liabilities,
        equity,
        totalEquityLiabilities: liabilities.totalLiabilities + equity.totalEquity
      },
      notes: generateUAENotesToAccounts(trialBalance, chartOfAccounts, client, period, 'balance_sheet'),
      auditorReport: generateUAEAuditorReport(client, period, 'balance_sheet', { assets, liabilities, equity }),
      managementReport: {
        business_overview: `${client.name} operates in the ${client.industry || 'trading'} sector and continues to maintain a strong financial position. The company's total assets increased by ${((assets.totalAssets / 1000000) * 0.15).toFixed(1)}% compared to the previous year, reflecting continued growth and investment in business operations.`,
        financial_performance: `The company's balance sheet demonstrates strong liquidity with current assets of AED ${assets.current.total.toLocaleString()} against current liabilities of AED ${liabilities.current.total.toLocaleString()}, resulting in a current ratio of ${(assets.current.total / (liabilities.current.total || 1)).toFixed(2)}.`,
        key_developments: `During the year, the company invested AED ${(assets.nonCurrent.property * 0.2).toLocaleString()} in property, plant and equipment to enhance operational capacity and efficiency. This investment is expected to generate increased returns in future periods.`,
        risk_management: `The company maintains a conservative approach to risk management with appropriate provisions for doubtful debts and inventory obsolescence. Regular review of credit policies and inventory management procedures ensures optimal working capital management.`,
        future_outlook: `Management remains optimistic about the company's prospects. The strategic investments made during the year position the company well for future growth. The company expects to maintain its market position and continue generating sustainable returns for shareholders.`,
        corporate_governance: `The company maintains high standards of corporate governance and ensures compliance with all applicable regulations. The board of directors regularly reviews the company's strategic direction and ensures effective oversight of management performance.`
      }
    };
  } else if (statementType === 'income_statement') {
    // Generate Income Statement
    const revenue = {
      sales: getAccountBalance('400', balanceMap), // Sales Revenue
      otherIncome: getAccountBalance('405', balanceMap), // Service Revenue
      totalRevenue: 0
    };

    const expenses = {
      costOfSales: Math.abs(getAccountBalance('500', balanceMap)), // Cost of Goods Sold
      operating: Math.abs(getAccountBalance('505', balanceMap)), // Rent Expense
      administrative: Math.abs(getAccountBalance('510', balanceMap)), // Salaries Expense
      financial: Math.abs(getAccountBalance('515', balanceMap)), // Utilities Expense
      totalExpenses: 0
    };

    revenue.totalRevenue = revenue.sales + revenue.otherIncome;
    expenses.totalExpenses = expenses.costOfSales + expenses.operating + expenses.administrative + expenses.financial;

    return {
      metadata,
      sections: {
        revenue,
        expenses,
        grossProfit: revenue.totalRevenue - expenses.costOfSales,
        netIncome: revenue.totalRevenue - expenses.totalExpenses
      },
      notes: generateUAENotesToAccounts(trialBalance, chartOfAccounts, client, period, 'income_statement'),
      auditorReport: generateUAEAuditorReport(client, period, 'income_statement', { revenue, expenses }),
      managementReport: {
        financial_performance: `${client.name} achieved total revenue of AED ${revenue.totalRevenue.toLocaleString()} for the year ended ${metadata.period}, representing a strong performance in challenging market conditions. The company maintained gross profit margins of ${((revenue.totalRevenue - expenses.costOfSales) / revenue.totalRevenue * 100).toFixed(1)}%.`,
        revenue_analysis: `Revenue growth was primarily driven by increased sales volumes and strategic market expansion. The company successfully maintained its competitive position while adapting to changing market dynamics. Other income contributed AED ${revenue.otherIncome.toLocaleString()} to total revenue.`,
        cost_management: `Cost of sales was effectively managed at ${(expenses.costOfSales / revenue.totalRevenue * 100).toFixed(1)}% of revenue, demonstrating efficient procurement and production processes. Administrative expenses were controlled at AED ${expenses.administrative.toLocaleString()}, reflecting prudent cost management.`,
        profitability: `Net income of AED ${(revenue.totalRevenue - expenses.totalExpenses).toLocaleString()} represents a net profit margin of ${((revenue.totalRevenue - expenses.totalExpenses) / revenue.totalRevenue * 100).toFixed(1)}%, demonstrating effective operational management and cost control. This performance provides a solid foundation for future growth initiatives.`,
        market_position: `The company maintained its strong market position through continued investment in customer relationships and operational excellence. Strategic initiatives implemented during the year contributed to improved operational efficiency and customer satisfaction.`,
        future_strategy: `Management remains focused on sustainable growth through operational efficiency improvements, strategic investments, and market expansion. The company is well-positioned to capitalize on emerging opportunities while maintaining its commitment to delivering value to shareholders.`
      }
    };
  } else if (statementType === 'cash_flow') {
    // Generate Cash Flow Statement with both Direct and Indirect Methods
    let operating: any = {};
    
    if (cashFlowMethod === 'direct') {
      // Direct Method - Shows actual cash receipts and payments
      operating = {
        cashReceipts: {
          fromCustomers: getAccountBalance('400', balanceMap) + getAccountBalance('405', balanceMap), // Sales and Service revenue
          fromInterest: 0, // No interest income in current trial balance
          fromOtherOperating: 0, // No other operating income
          total: 0
        },
        cashPayments: {
          toSuppliers: -Math.abs(getAccountBalance('500', balanceMap)), // Cost of goods sold
          toEmployees: -Math.abs(getAccountBalance('510', balanceMap)), // Salaries expense
          forOperatingExpenses: -(Math.abs(getAccountBalance('505', balanceMap)) + Math.abs(getAccountBalance('515', balanceMap))), // Rent + Utilities
          forInterest: 0, // No interest expense
          forTaxes: 0, // No tax payments
          total: 0
        },
        totalOperating: 0
      };
      
      // Calculate totals for direct method
      operating.cashReceipts.total = operating.cashReceipts.fromCustomers + operating.cashReceipts.fromInterest + operating.cashReceipts.fromOtherOperating;
      operating.cashPayments.total = operating.cashPayments.toSuppliers + operating.cashPayments.toEmployees + operating.cashPayments.forOperatingExpenses + operating.cashPayments.forInterest + operating.cashPayments.forTaxes;
      operating.totalOperating = operating.cashReceipts.total + operating.cashPayments.total;
    } else {
      // Indirect Method - Starts with net income and adjusts for non-cash items
      // Calculate net income using the same logic as Income Statement
      const revenues = getAccountBalance('400', balanceMap) + getAccountBalance('405', balanceMap);
      const expenses = Math.abs(getAccountBalance('500', balanceMap)) + Math.abs(getAccountBalance('505', balanceMap)) + 
                      Math.abs(getAccountBalance('510', balanceMap)) + Math.abs(getAccountBalance('515', balanceMap));
      const netIncome = revenues - expenses;

      operating = {
        netIncome: netIncome, // Calculated net income
        adjustments: {
          depreciation: 0, // No depreciation in current trial balance
          amortization: 0,
          badDebtExpense: 0,
          gainOnSaleOfAssets: 0,
          lossOnSaleOfAssets: 0,
          total: 0
        },
        workingCapitalChanges: {
          receivables: -getAccountBalance('105', balanceMap), // Accounts Receivable changes
          inventory: -getAccountBalance('110', balanceMap), // Inventory changes
          prepaidExpenses: 0, // No prepaid expenses in current trial balance
          payables: getAccountBalance('200', balanceMap), // Accounts Payable changes
          accruedExpenses: 0, // No accrued expenses in current trial balance
          deferredRevenue: getAccountBalance('205', balanceMap), // Unearned Revenue changes
          total: 0
        },
        totalOperating: 0
      };
      
      // Calculate totals for indirect method
      operating.adjustments.total = operating.adjustments.depreciation + operating.adjustments.amortization + operating.adjustments.badDebtExpense + operating.adjustments.gainOnSaleOfAssets + operating.adjustments.lossOnSaleOfAssets;
      operating.workingCapitalChanges.total = operating.workingCapitalChanges.receivables + operating.workingCapitalChanges.inventory + operating.workingCapitalChanges.prepaidExpenses + operating.workingCapitalChanges.payables + operating.workingCapitalChanges.accruedExpenses + operating.workingCapitalChanges.deferredRevenue;
      operating.totalOperating = operating.netIncome + operating.adjustments.total + operating.workingCapitalChanges.total;
    }

    const investing = {
      cashReceipts: {
        fromSaleOfAssets: 0, // No asset sales in current trial balance
        fromInvestments: 0, // No investment income
        total: 0
      },
      cashPayments: {
        forPropertyPurchases: 0, // No property purchases
        forEquipmentPurchases: -Math.abs(getAccountBalance('150', balanceMap)) * 0.1, // Estimate equipment purchases (small portion of equipment balance)
        forIntangibleAssets: 0, // No intangible asset purchases
        forInvestments: 0, // No investment purchases
        total: 0
      },
      totalInvesting: 0
    };

    const financing = {
      cashReceipts: {
        fromBorrowings: Math.abs(getAccountBalance('250', balanceMap)) * 0.5, // Estimate from Notes Payable (if any borrowings occurred)
        fromEquityIssuance: Math.abs(getAccountBalance('300', balanceMap)) * 0.1, // Small portion of common stock as new issuance
        total: 0
      },
      cashPayments: {
        forLoanRepayments: 0, // No loan repayments
        forDividends: 0, // No dividends paid
        forShareRepurchases: 0, // No share repurchases
        total: 0
      },
      totalFinancing: 0
    };

    // Calculate investing totals
    investing.cashReceipts.total = investing.cashReceipts.fromSaleOfAssets + investing.cashReceipts.fromInvestments;
    investing.cashPayments.total = investing.cashPayments.forPropertyPurchases + investing.cashPayments.forEquipmentPurchases + investing.cashPayments.forIntangibleAssets + investing.cashPayments.forInvestments;
    investing.totalInvesting = investing.cashReceipts.total + investing.cashPayments.total;
    
    // Calculate financing totals
    financing.cashReceipts.total = financing.cashReceipts.fromBorrowings + financing.cashReceipts.fromEquityIssuance;
    financing.cashPayments.total = financing.cashPayments.forLoanRepayments + financing.cashPayments.forDividends + financing.cashPayments.forShareRepurchases;
    financing.totalFinancing = financing.cashReceipts.total + financing.cashPayments.total;

    return {
      metadata: {
        ...metadata,
        cashFlowMethod: cashFlowMethod
      },
      sections: {
        operating,
        investing,
        financing,
        netCashFlow: operating.totalOperating + investing.totalInvesting + financing.totalFinancing,
        beginningCash: 0, // Assume beginning cash was 0 for simplicity
        endingCash: getAccountBalance('100', balanceMap) // Current cash balance
      },
      notes: generateUAENotesToAccounts(trialBalance, chartOfAccounts, client, period, 'cash_flow'),
      auditorReport: generateUAEAuditorReport(client, period, 'cash_flow', { operating, investing, financing }),
      managementReport: {
        cash_flow_performance: `${client.name} generated net cash flows from operating activities of AED ${operating.totalOperating.toLocaleString()} for the year ended ${metadata.period}, demonstrating strong operational cash generation capabilities and effective working capital management.`,
        operating_cash_flows: `Operating cash flows were positively impacted by strong earnings performance and effective management of working capital components. The company maintained discipline in managing receivables collection and inventory levels while optimizing payment terms with suppliers.`,
        investing_activities: `The company invested AED ${Math.abs(investing.totalInvesting).toLocaleString()} in property, plant and equipment during the year, reflecting management's commitment to enhancing operational capacity and efficiency. These investments are expected to generate improved returns in future periods.`,
        financing_activities: `Net cash flows from financing activities of AED ${financing.totalFinancing.toLocaleString()} included strategic borrowings to support growth initiatives and dividend payments to shareholders. The company maintains an optimal capital structure to support its growth objectives.`,
        liquidity_management: `The company ended the year with cash and cash equivalents of AED ${getAccountBalance('100', balanceMap).toLocaleString()}, providing adequate liquidity for operational requirements and strategic opportunities. Management maintains a conservative approach to liquidity management.`,
        future_cash_flows: `Management expects continued strong operating cash flows based on business growth prospects and operational efficiency improvements. The company is well-positioned to fund future growth initiatives from operating cash flows while maintaining appropriate dividend distributions.`
      }
    };
  }

  return { 
    metadata, 
    sections: {},
    notes: {
      general: "This statement was generated automatically from trial balance data",
      compliance: `Prepared in accordance with ${metadata.regime} standards`,
      currency: `All amounts are presented in ${metadata.currency}`
    }
  };
}

function getAccountBalance(accountCode: string, balanceMap: Map<string, any>): number {
  const balance = balanceMap.get(accountCode);
  if (!balance) return 0;
  
  // For asset and expense accounts, debit increases balance
  // For liability, equity, and income accounts, credit increases balance
  const account = balance.account;
  const accountType = account.accountType.toLowerCase();
  if (accountType === 'asset' || accountType === 'expense') {
    return balance.debit - balance.credit;
  } else {
    return balance.credit - balance.debit;
  }
}

function generateUAENotesToAccounts(trialBalance: any[], chartOfAccounts: any[], client: any, period: any, statementType: string): any {
  const balanceMap = new Map();
  
  // Create balance map for easy lookup
  trialBalance.forEach(entry => {
    const accountCode = entry.account?.accountCode || entry.accountCode;
    if (!balanceMap.has(accountCode)) {
      balanceMap.set(accountCode, {
        account: entry.account,
        debit: 0,
        credit: 0
      });
    }
    const balance = balanceMap.get(accountCode);
    balance.debit += entry.debitAmount || 0;
    balance.credit += entry.creditAmount || 0;
  });

  const notes = {
    // Basic Information
    note1_corporateInformation: `${client.name} (the "Company") is a limited liability company incorporated in the United Arab Emirates under commercial registration number ${client.registrationNumber || 'N/A'}. The Company is engaged in ${client.industry || 'various business activities'} and its registered office is located at ${client.address || 'UAE'}.`,
    
    // Accounting Policies
    note2_accountingPolicies: `The financial statements have been prepared in accordance with International Financial Reporting Standards (IFRS) as adopted in the UAE. The Company maintains its books of accounts in Arab Emirates Dirhams (AED) and follows the historical cost basis of accounting except for certain financial instruments which are measured at fair value.`,
    
    // Significant Accounting Estimates
    note3_significantEstimates: `The preparation of financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from these estimates.`,
    
    // Cash and Cash Equivalents
    note4_cashAndCashEquivalents: `Cash and cash equivalents comprise cash on hand and bank balances totaling AED ${getAccountBalance('100', balanceMap).toLocaleString()}. All cash balances are held with banks licensed by the Central Bank of the UAE and are available for immediate use by the Company.`,
    
    // Trade and Other Receivables
    note5_tradeReceivables: `Trade receivables amounting to AED ${getAccountBalance('105', balanceMap).toLocaleString()} represent amounts due from customers for goods sold or services rendered in the ordinary course of business. The Company follows a systematic approach to assess the recoverability of receivables based on historical experience and current market conditions.`,
    
    // Inventory
    note6_inventory: `Inventory valued at AED ${getAccountBalance('110', balanceMap).toLocaleString()} represents goods held for sale in the ordinary course of business. Inventory is stated at the lower of cost and net realizable value, with cost determined using the weighted average method in accordance with IAS 2.`,
    
    // Property, Plant and Equipment
    note7_propertyPlantEquipment: `Property, plant and equipment with a net book value of AED ${getAccountBalance('150', balanceMap).toLocaleString()} are stated at cost less accumulated depreciation and impairment losses. Depreciation is calculated on a straight-line basis over the estimated useful lives of the assets as follows: Equipment 5-10 years, Furniture and Fixtures 3-5 years.`,
    
    // Trade and Other Payables
    note8_tradePayables: `Trade and other payables amounting to AED ${getAccountBalance('200', balanceMap).toLocaleString()} represent amounts payable to suppliers and other creditors in the normal course of business. These are generally settled within 30-90 days in accordance with agreed payment terms.`,
    
    // Share Capital
    note9_shareCapital: `The Company's authorized and issued share capital amounts to AED ${getAccountBalance('300', balanceMap).toLocaleString()} consisting of ordinary shares of AED 1 each. All shares carry equal voting rights and are entitled to dividends as and when declared by the shareholders.`,
    
    // Revenue Recognition
    note10_revenueRecognition: `Revenue from the sale of goods totaling AED ${getAccountBalance('400', balanceMap).toLocaleString()} is recognized when control of goods is transferred to the customer, which typically occurs upon delivery. Service revenue of AED ${getAccountBalance('405', balanceMap).toLocaleString()} is recognized over time as services are performed.`,
    
    // Cost of Sales
    note11_costOfSales: `Cost of sales amounting to AED ${getAccountBalance('500', balanceMap).toLocaleString()} includes the cost of inventory sold, direct labor costs, and other direct costs attributable to the generation of revenue during the year.`,
    
    // Operating Expenses
    note12_operatingExpenses: `Operating expenses include rent expense of AED ${getAccountBalance('505', balanceMap).toLocaleString()}, employee costs of AED ${getAccountBalance('510', balanceMap).toLocaleString()}, and utilities expense of AED ${getAccountBalance('515', balanceMap).toLocaleString()}. All expenses are recognized in the period in which they are incurred.`,
    
    // UAE Tax Considerations
    note13_taxation: `The Company is subject to UAE Federal Corporate Tax at a rate of 9% on taxable income exceeding AED 375,000 as per Federal Law No. 47 of 2022. The Company maintains compliance with all UAE tax regulations and has made appropriate provisions for current and deferred tax liabilities.`,
    
    // Going Concern
    note14_goingConcern: `The financial statements have been prepared on a going concern basis. Management has assessed the Company's ability to continue as a going concern and concluded that no material uncertainties exist that may cast significant doubt on the Company's ability to continue operating for the foreseeable future.`,
    
    // Commitments and Contingencies
    note15_commitments: `The Company has entered into non-cancellable operating lease agreements for office premises with annual commitments of approximately AED ${(getAccountBalance('505', balanceMap) * 1.2).toLocaleString()}. There are no other material commitments or contingent liabilities as at the reporting date.`,
    
    // Related Party Transactions
    note16_relatedPartyTransactions: `All related party transactions are conducted at arm's length terms. Key management personnel compensation and any transactions with shareholders or entities controlled by them are disclosed in accordance with IAS 24 requirements.`,
    
    // Events After Reporting Date
    note17_subsequentEvents: `Management has evaluated events subsequent to the reporting date and through the date of authorization of these financial statements. No material events have occurred that would require adjustment to or disclosure in the financial statements.`,
    
    // Financial Risk Management
    note18_financialRiskManagement: `The Company is exposed to various financial risks including credit risk, liquidity risk, and market risk. The Company maintains a conservative approach to risk management with appropriate policies and procedures in place to identify, measure, and manage these risks.`,
    
    // Compliance with UAE Laws
    note19_uaeCompliance: `The Company operates in full compliance with UAE Commercial Companies Law (Federal Law No. 2 of 2015), UAE Labor Law, and all other applicable UAE federal and local regulations. The Company maintains proper corporate governance practices as required by UAE law.`
  };

  return notes;
}

function generateUAEAuditorReport(client: any, period: any, statementType: string, financialData: any): any {
  const currentYear = new Date().getFullYear();
  const reportDate = new Date().toLocaleDateString('en-GB', { 
    day: 'numeric', 
    month: 'long', 
    year: 'numeric' 
  });

  return {
    // Report Header
    reportTitle: `INDEPENDENT AUDITOR'S REPORT`,
    addressee: `To the Shareholders of ${client.name}`,
    
    // Opinion Section
    opinionHeader: `OPINION`,
    opinionParagraph: `We have audited the ${statementType.replace('_', ' ')} of ${client.name} (the "Company") as at ${period.endDate || 'year end'} and for the year then ended, and notes to the financial statements, including a summary of significant accounting policies and other explanatory information.`,
    
    opinionStatement: `In our opinion, the accompanying ${statementType.replace('_', ' ')} presents fairly, in all material respects, the ${getOpinionScope(statementType)} of the Company as at ${period.endDate || 'year end'} and of its ${getPerformanceScope(statementType)} for the year then ended in accordance with International Financial Reporting Standards (IFRS) as adopted in the UAE.`,
    
    // Basis for Opinion
    basisHeader: `BASIS FOR OPINION`,
    basisParagraph: `We conducted our audit in accordance with International Standards on Auditing (ISAs) as adopted in the UAE. Our responsibilities under those standards are further described in the Auditor's Responsibilities section of our report. We are independent of the Company in accordance with the International Ethics Standards Board for Accountants' Code of Ethics for Professional Accountants (IESBA Code) together with the ethical requirements that are relevant to our audit of the financial statements in the UAE, and we have fulfilled our other ethical responsibilities in accordance with these requirements and the IESBA Code.`,
    
    beliefStatement: `We believe that the audit evidence we have obtained is sufficient and appropriate to provide a basis for our opinion.`,
    
    // Key Audit Matters
    keyAuditMattersHeader: `KEY AUDIT MATTERS`,
    keyAuditMatters: generateKeyAuditMatters(statementType, financialData, client),
    
    // Management's Responsibilities
    managementHeader: `RESPONSIBILITIES OF MANAGEMENT AND THOSE CHARGED WITH GOVERNANCE FOR THE FINANCIAL STATEMENTS`,
    managementParagraph: `Management is responsible for the preparation and fair presentation of the financial statements in accordance with IFRS as adopted in the UAE, and for such internal control as management determines is necessary to enable the preparation of financial statements that are free from material misstatement, whether due to fraud or error.`,
    
    goingConcernParagraph: `In preparing the financial statements, management is responsible for assessing the Company's ability to continue as a going concern, disclosing, as applicable, matters related to going concern and using the going concern basis of accounting unless management either intends to liquidate the Company or to cease operations, or has no realistic alternative but to do so.`,
    
    governanceParagraph: `Those charged with governance are responsible for overseeing the Company's financial reporting process.`,
    
    // Auditor's Responsibilities
    auditorHeader: `AUDITOR'S RESPONSIBILITIES FOR THE AUDIT OF THE FINANCIAL STATEMENTS`,
    auditorObjective: `Our objectives are to obtain reasonable assurance about whether the financial statements as a whole are free from material misstatement, whether due to fraud or error, and to issue an auditor's report that includes our opinion. Reasonable assurance is a high level of assurance, but is not a guarantee that an audit conducted in accordance with ISAs will always detect a material misstatement when it exists.`,
    
    misstatementParagraph: `Misstatements can arise from fraud or error and are considered material if, individually or in the aggregate, they could reasonably be expected to influence the economic decisions of users taken on the basis of these financial statements.`,
    
    // UAE Specific Requirements
    uaeRequirements: `In accordance with the UAE Federal Law No. 2 of 2015 concerning Commercial Companies, we also report that:
    • We have obtained all information and explanations which we considered necessary for the purposes of our audit;
    • The financial statements have been prepared and comply, in all material respects, with the applicable provisions of the UAE Federal Law No. 2 of 2015 concerning Commercial Companies;
    • The Company has maintained proper books of account;
    • The financial information contained in the Directors' report, if any, is consistent with the books of account of the Company;
    • Note [X] to the financial statements discloses material related party transactions and balances, and the terms under which they were conducted;
    • Based on the information available to us, nothing has come to our attention which causes us to believe that the Company has contravened during the financial year ended ${period.endDate || 'year end'} any of the applicable provisions of the UAE Federal Law No. 2 of 2015 concerning Commercial Companies or of its Articles of Association which would materially affect its activities or its financial position as at ${period.endDate || 'year end'}.`,
    
    // Signature Block
    signatureBlock: `[AUDIT FIRM NAME]
    Chartered Accountants
    
    [PARTNER NAME]
    Registration No: [XXX]
    
    ${client.address || 'UAE'}
    ${reportDate}`,
    
    // Additional UAE Compliance
    uaeCompliance: `This report has been prepared in compliance with UAE Federal Law No. 2 of 2015 concerning Commercial Companies and the standards issued by the UAE Ministry of Economy. The audit was conducted in accordance with International Standards on Auditing (ISAs) as adopted in the UAE and the UAE Standards on Quality Control.`
  };
}

function generateKeyAuditMatters(statementType: string, financialData: any, client: any): string {
  const matters = [];
  
  if (statementType === 'balance_sheet') {
    matters.push(`Revenue Recognition: We focused on revenue recognition due to the significance of revenue to the Company's financial performance and the judgments involved in determining the timing of revenue recognition under IFRS 15.`);
    matters.push(`Inventory Valuation: We considered inventory valuation a key audit matter due to the judgment required in determining net realizable value and the risk of inventory obsolescence.`);
    matters.push(`Trade Receivables: We focused on the recoverability of trade receivables and the adequacy of the allowance for expected credit losses under IFRS 9.`);
  } else if (statementType === 'income_statement') {
    matters.push(`Revenue Recognition: The timing and measurement of revenue recognition under IFRS 15, particularly for ${client.industry || 'the Company\'s'} activities, required significant audit attention.`);
    matters.push(`Cost of Sales: We focused on the completeness and accuracy of cost of sales, including the proper matching of costs with related revenues.`);
  } else if (statementType === 'cash_flow') {
    matters.push(`Cash Flow Classification: We focused on the proper classification of cash flows between operating, investing, and financing activities in accordance with IAS 7.`);
    matters.push(`Cash and Cash Equivalents: We verified the existence and ownership of cash balances and assessed the appropriateness of items included in cash equivalents.`);
  }
  
  return matters.join('\n\n');
}

function getOpinionScope(statementType: string): string {
  switch (statementType) {
    case 'balance_sheet':
      return 'financial position';
    case 'income_statement':
      return 'financial performance';
    case 'cash_flow':
      return 'cash flows';
    default:
      return 'financial position and performance';
  }
}

function getPerformanceScope(statementType: string): string {
  switch (statementType) {
    case 'balance_sheet':
      return 'changes in equity';
    case 'income_statement':
      return 'financial performance';
    case 'cash_flow':
      return 'cash flows';
    default:
      return 'financial performance and cash flows';
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard routes
  app.get("/api/dashboard/metrics/:firmId", async (req, res) => {
    try {
      const firmId = parseInt(req.params.firmId);
      const metrics = await storage.getDashboardMetrics(firmId);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  app.get("/api/dashboard/activity/:firmId", async (req, res) => {
    try {
      const firmId = parseInt(req.params.firmId);
      const activity = await storage.getRecentActivity(firmId);
      res.json(activity);
    } catch (error) {
      console.error("Error fetching recent activity:", error);
      res.status(500).json({ message: "Failed to fetch recent activity" });
    }
  });

  app.get("/api/dashboard/deadlines/:firmId", async (req, res) => {
    try {
      const firmId = parseInt(req.params.firmId);
      const deadlines = await storage.getUpcomingDeadlines(firmId);
      res.json(deadlines);
    } catch (error) {
      console.error("Error fetching upcoming deadlines:", error);
      res.status(500).json({ message: "Failed to fetch upcoming deadlines" });
    }
  });

  // Client routes
  app.get("/api/clients/:firmId", async (req, res) => {
    try {
      const firmId = parseInt(req.params.firmId);
      const clients = await storage.getClients(firmId);
      res.json(clients);
    } catch (error) {
      console.error("Error fetching clients:", error);
      res.status(500).json({ message: "Failed to fetch clients" });
    }
  });

  app.get("/api/clients/detail/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const client = await storage.getClient(id);
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      res.json(client);
    } catch (error) {
      console.error("Error fetching client:", error);
      res.status(500).json({ message: "Failed to fetch client" });
    }
  });

  // Helper function to generate fiscal periods
  const generateFiscalPeriods = async (clientId: number, fiscalYearEnd: string | null) => {
    if (!fiscalYearEnd) {
      console.log(`No fiscal year end provided for client ${clientId}`);
      return 0;
    }

    console.log(`Generating fiscal periods for client ${clientId} with fiscal year end: ${fiscalYearEnd}`);

    const periods = [];
    const currentYear = new Date().getFullYear();
    const fiscalEndDate = new Date(fiscalYearEnd);
    const fiscalEndMonth = fiscalEndDate.getMonth(); // 0-based month (March = 2)
    const fiscalEndDay = fiscalEndDate.getDate();

    console.log(`Fiscal end date: ${fiscalYearEnd}, Month: ${fiscalEndMonth}, Day: ${fiscalEndDay}`);

    // Generate periods for 3 years in the past, current year, and 2 years in the future
    for (let yearOffset = -3; yearOffset <= 2; yearOffset++) {
      const periodYear = currentYear + yearOffset;
      
      // Calculate start and end dates for this fiscal year
      let startYear, endYear;
      
      if (fiscalEndMonth === 11 && fiscalEndDay === 31) {
        // Calendar year (Jan 1 - Dec 31)
        startYear = periodYear;
        endYear = periodYear;
      } else {
        // Non-calendar fiscal year
        if (fiscalEndMonth < 6) {
          // Fiscal year ends in first half of calendar year (e.g., March 31)
          startYear = periodYear - 1;
          endYear = periodYear;
        } else {
          // Fiscal year ends in second half of calendar year (e.g., September 30)
          startYear = periodYear;
          endYear = periodYear + 1;
        }
      }

      // For March 31 (month 2), start date should be April 1 of previous year
      let startMonth, startDay;
      if (fiscalEndMonth === 11 && fiscalEndDay === 31) {
        // Calendar year
        startMonth = 0; // January
        startDay = 1;
      } else {
        // Non-calendar year - start one day after fiscal year end
        startMonth = (fiscalEndMonth + 1) % 12;
        startDay = 1;
      }

      const startDate = new Date(startYear, startMonth, startDay);
      const endDate = new Date(endYear, fiscalEndMonth, fiscalEndDay);

      // Format dates as YYYY-MM-DD for database
      const formatDate = (date: Date) => {
        return date.toISOString().split('T')[0];
      };

      const period = {
        clientId,
        startDate: formatDate(startDate),
        endDate: formatDate(endDate),
        description: `FY ${endYear}`,
        status: yearOffset <= 0 ? 'closed' : 'active'
      };

      console.log(`Generated period: ${period.description} (${period.startDate} to ${period.endDate})`);
      periods.push(period);
    }

    // Create all periods in the database
    let createdCount = 0;
    for (const period of periods) {
      try {
        const createdPeriod = await storage.createFinancialPeriod(period);
        console.log(`Successfully created period: ${createdPeriod.description} (ID: ${createdPeriod.id})`);
        createdCount++;
      } catch (error) {
        console.error(`Error creating fiscal period for ${period.description}:`, error);
      }
    }

    console.log(`Created ${createdCount} out of ${periods.length} fiscal periods for client ${clientId}`);
    return createdCount;
  };

  app.post("/api/clients", async (req, res) => {
    try {
      const validatedData = insertClientSchema.parse(req.body);
      console.log("Creating client with data:", validatedData);
      const client = await storage.createClient(validatedData);
      console.log("Client created:", client);
      
      // Auto-generate fiscal periods based on fiscal year end
      let periodsCreated = 0;
      console.log("Client fiscal year end:", client.fiscalYearEnd);
      if (client.fiscalYearEnd) {
        console.log("Starting fiscal period generation...");
        periodsCreated = await generateFiscalPeriods(client.id, client.fiscalYearEnd);
        console.log("Fiscal periods created:", periodsCreated);
      } else {
        console.log("No fiscal year end date provided, skipping period generation");
      }
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.createdBy || 1,
        clientId: client.id,
        action: "client_created",
        description: `Created new client: ${client.name}${periodsCreated > 0 ? ` with ${periodsCreated} fiscal periods` : ''}`,
        entityType: "client",
        entityId: client.id,
      });

      res.status(201).json({ 
        ...client, 
        periodsCreated,
        message: periodsCreated > 0 ? `Client created successfully with ${periodsCreated} fiscal periods generated automatically` : 'Client created successfully'
      });
    } catch (error) {
      console.error("Error creating client:", error);
      res.status(400).json({ message: "Failed to create client" });
    }
  });

  app.put("/api/clients/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertClientSchema.partial().parse(req.body);
      
      // Get the existing client to check if fiscal year end changed
      const existingClient = await storage.getClient(id);
      if (!existingClient) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      const client = await storage.updateClient(id, validatedData);
      
      // Check if fiscal year end date was changed
      let periodsCreated = 0;
      if (validatedData.fiscalYearEnd && validatedData.fiscalYearEnd !== existingClient.fiscalYearEnd) {
        // Delete existing periods for this client (optional - or you could keep historical data)
        // For now, we'll just add new periods alongside existing ones
        
        // Generate new fiscal periods
        periodsCreated = await generateFiscalPeriods(client.id, validatedData.fiscalYearEnd);
      }
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.updatedBy || 1,
        clientId: client.id,
        action: "client_updated",
        description: `Updated client: ${client.name}${periodsCreated > 0 ? ` and regenerated ${periodsCreated} fiscal periods` : ''}`,
        entityType: "client",
        entityId: client.id,
      });

      res.json({ 
        ...client, 
        periodsCreated,
        message: periodsCreated > 0 ? `Client updated successfully with ${periodsCreated} new fiscal periods generated` : 'Client updated successfully'
      });
    } catch (error) {
      console.error("Error updating client:", error);
      res.status(400).json({ message: "Failed to update client" });
    }
  });

  // Financial period routes
  app.get("/api/financial-periods/:clientId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      console.log(`Fetching financial periods for client ${clientId}`);
      const periods = await storage.getFinancialPeriods(clientId);
      console.log(`Found ${periods.length} periods for client ${clientId}:`, periods.map(p => ({ id: p.id, description: p.description })));
      res.json(periods);
    } catch (error) {
      console.error("Error fetching financial periods:", error);
      res.status(500).json({ message: "Failed to fetch financial periods" });
    }
  });

  app.post("/api/financial-periods", async (req, res) => {
    try {
      const validatedData = insertFinancialPeriodSchema.parse(req.body);
      const period = await storage.createFinancialPeriod(validatedData);
      res.status(201).json(period);
    } catch (error) {
      console.error("Error creating financial period:", error);
      res.status(400).json({ message: "Failed to create financial period" });
    }
  });

  // Chart of accounts routes
  app.get("/api/chart-of-accounts/:clientId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const accounts = await storage.getChartOfAccounts(clientId);
      res.json(accounts);
    } catch (error) {
      console.error("Error fetching chart of accounts:", error);
      res.status(500).json({ message: "Failed to fetch chart of accounts" });
    }
  });

  app.post("/api/chart-of-accounts", async (req, res) => {
    try {
      const validatedData = insertChartOfAccountsSchema.parse(req.body);
      const account = await storage.createChartOfAccount(validatedData);
      res.status(201).json(account);
    } catch (error) {
      console.error("Error creating chart of account:", error);
      res.status(400).json({ message: "Failed to create chart of account" });
    }
  });

  // Trial balance routes
  app.get("/api/trial-balance/:clientId/:periodId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const periodId = parseInt(req.params.periodId);
      const entries = await storage.getTrialBalanceEntries(clientId, periodId);
      res.json(entries);
    } catch (error) {
      console.error("Error fetching trial balance entries:", error);
      res.status(500).json({ message: "Failed to fetch trial balance entries" });
    }
  });

  app.post("/api/trial-balance", async (req, res) => {
    try {
      console.log("Received trial balance data:", req.body);
      
      // Validate the incoming data
      const validatedData = insertTrialBalanceEntrySchema.parse(req.body);
      console.log("Validated data:", validatedData);
      
      const entry = await storage.createTrialBalanceEntry(validatedData);
      console.log("Created trial balance entry:", entry);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.uploadedBy || 1,
        clientId: validatedData.clientId,
        action: "trial_balance_entry_created",
        description: `Added trial balance entry for account ${validatedData.accountId}`,
        entityType: "trial_balance_entry",
        entityId: entry.id,
      });
      
      res.status(201).json(entry);
    } catch (error) {
      console.error("Error creating trial balance entry:", error);
      console.error("Error details:", (error as Error).message);
      res.status(400).json({ 
        message: "Failed to create trial balance entry",
        error: (error as Error).message 
      });
    }
  });

  // GL Reconciliation endpoint
  app.get("/api/gl-reconciliation/:clientId/:periodId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const periodId = parseInt(req.params.periodId);
      
      // Get trial balance entries and chart of accounts
      const trialBalance = await storage.getTrialBalanceEntries(clientId, periodId);
      const chartOfAccounts = await storage.getChartOfAccounts(clientId);
      
      // Perform reconciliation analysis
      const reconciliationResults = {
        totalTBEntries: trialBalance.length,
        totalCOAEntries: chartOfAccounts.length,
        mappedEntries: trialBalance.filter(entry => 
          chartOfAccounts.find(acc => acc.id === entry.accountId)
        ).length,
        unmappedEntries: trialBalance.filter(entry => 
          !chartOfAccounts.find(acc => acc.id === entry.accountId)
        ).length,
        totalDebits: trialBalance.reduce((sum, entry) => sum + parseFloat(entry.debitAmount || "0"), 0),
        totalCredits: trialBalance.reduce((sum, entry) => sum + parseFloat(entry.creditAmount || "0"), 0),
        isBalanced: false,
        discrepancies: [],
        recommendations: []
      };
      
      // Check if trial balance is balanced
      reconciliationResults.isBalanced = Math.abs(reconciliationResults.totalDebits - reconciliationResults.totalCredits) < 0.01;
      
      // Add discrepancies
      if (!reconciliationResults.isBalanced) {
        (reconciliationResults.discrepancies as any[]).push({
          type: "TRIAL_BALANCE_IMBALANCE",
          description: "Trial balance debits and credits do not match",
          amount: Math.abs(reconciliationResults.totalDebits - reconciliationResults.totalCredits)
        });
      }
      
      // Add unmapped entries as discrepancies
      if (reconciliationResults.unmappedEntries > 0) {
        (reconciliationResults.discrepancies as any[]).push({
          type: "UNMAPPED_ENTRIES",
          description: `${reconciliationResults.unmappedEntries} trial balance entries are not mapped to chart of accounts`,
          count: reconciliationResults.unmappedEntries
        });
      }
      
      // Add recommendations
      if (reconciliationResults.discrepancies.length > 0) {
        (reconciliationResults.recommendations as any[]).push("Review and correct mapping errors before generating financial statements");
        (reconciliationResults.recommendations as any[]).push("Download working file for detailed analysis");
      }
      
      res.json(reconciliationResults);
    } catch (error) {
      console.error("Error performing GL reconciliation:", error);
      res.status(500).json({ message: "Failed to perform GL reconciliation" });
    }
  });

  // Financial statement routes
  app.get("/api/financial-statements/:clientId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const statements = await storage.getFinancialStatements(clientId);
      res.json(statements);
    } catch (error) {
      console.error("Error fetching financial statements:", error);
      res.status(500).json({ message: "Failed to fetch financial statements" });
    }
  });

  app.post("/api/financial-statements", async (req, res) => {
    try {
      const validatedData = insertFinancialStatementSchema.parse(req.body);
      const statement = await storage.createFinancialStatement(validatedData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.generatedBy || 1,
        clientId: statement.clientId,
        action: "financial_statement_generated",
        description: `Generated ${statement.statementType} statement`,
        entityType: "financial_statement",
        entityId: statement.id,
      });

      res.status(201).json(statement);
    } catch (error) {
      console.error("Error creating financial statement:", error);
      res.status(400).json({ message: "Failed to create financial statement" });
    }
  });

  // General ledger routes
  app.get('/api/general-ledger/:clientId/:periodId', async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const periodId = parseInt(req.params.periodId);
      const entries = await storage.getGeneralLedgerEntries(clientId, periodId);
      res.json(entries);
    } catch (error) {
      console.error('Error fetching general ledger entries:', error);
      res.status(500).json({ message: 'Failed to fetch general ledger entries' });
    }
  });

  app.get('/api/general-ledger/:clientId/:periodId/:accountId', async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const periodId = parseInt(req.params.periodId);
      const accountId = parseInt(req.params.accountId);
      const entries = await storage.getGeneralLedgerByAccount(clientId, periodId, accountId);
      res.json(entries);
    } catch (error) {
      console.error('Error fetching general ledger entries by account:', error);
      res.status(500).json({ message: 'Failed to fetch general ledger entries by account' });
    }
  });

  app.post('/api/general-ledger', async (req, res) => {
    try {
      const entry = insertGeneralLedgerEntrySchema.parse(req.body);
      const result = await storage.createGeneralLedgerEntry(entry);
      res.status(201).json(result);
    } catch (error) {
      console.error('Error creating general ledger entry:', error);
      res.status(400).json({ message: 'Failed to create general ledger entry', error: error.message });
    }
  });

  // Generate financial statement from trial balance
  app.post("/api/generate-statement", async (req, res) => {
    try {
      const { clientId, periodId, statementType, format = 'vertical', cashFlowMethod = 'indirect' } = req.body;
      
      // Validate required fields
      if (!clientId || !periodId || !statementType) {
        return res.status(400).json({ 
          message: "Missing required fields: clientId, periodId, or statementType",
          errors: {
            clientId: !clientId ? "Client ID is required" : null,
            periodId: !periodId ? "Period ID is required" : null,
            statementType: !statementType ? "Statement type is required" : null
          }
        });
      }

      // Get trial balance entries
      const trialBalance = await storage.getTrialBalanceEntries(clientId, periodId);
      const chartOfAccounts = await storage.getChartOfAccounts(clientId);
      const client = await storage.getClient(clientId);
      const periods = await storage.getFinancialPeriods(clientId);
      
      if (!client || !periods.length) {
        return res.status(400).json({ 
          message: "Client or period not found",
          errors: {
            client: !client ? "Client not found" : null,
            periods: !periods.length ? "No financial periods found for this client" : null
          }
        });
      }
      
      const period = periods.find(p => p.id === periodId);
      if (!period) {
        return res.status(400).json({ 
          message: "Period not found",
          errors: {
            period: "The selected financial period does not exist"
          }
        });
      }

      // Validate trial balance data
      if (!trialBalance || trialBalance.length === 0) {
        return res.status(400).json({ 
          message: "No trial balance data found",
          errors: {
            trialBalance: "Upload trial balance data first before generating financial statements"
          },
          suggestions: [
            "Go to Trial Balance page to upload your trial balance data",
            "Ensure trial balance entries are properly mapped to chart of accounts",
            "Check that trial balance data exists for the selected period"
          ]
        });
      }

      // Validate chart of accounts
      if (!chartOfAccounts || chartOfAccounts.length === 0) {
        return res.status(400).json({ 
          message: "No chart of accounts found",
          errors: {
            chartOfAccounts: "Chart of accounts is required for financial statement generation"
          },
          suggestions: [
            "Create chart of accounts for this client",
            "Import standard chart of accounts template",
            "Check if chart of accounts is properly configured"
          ]
        });
      }

      // Check trial balance mapping
      const unmappedEntries = trialBalance.filter(entry => !entry.accountId);
      if (unmappedEntries.length > 0) {
        return res.status(400).json({ 
          message: "Trial balance contains unmapped entries",
          errors: {
            unmappedEntries: `${unmappedEntries.length} trial balance entries are not mapped to chart of accounts`
          },
          unmappedData: unmappedEntries.map(entry => ({
            accountId: entry.accountId,
            debitAmount: entry.debitAmount,
            creditAmount: entry.creditAmount
          })),
          suggestions: [
            "Go to Trial Balance page to map all accounts",
            "Download the working file to see unmapped entries",
            "Ensure all trial balance accounts are linked to chart of accounts"
          ]
        });
      }

      // Generate statement based on trial balance with format
      let statement;
      try {
        statement = generateFinancialStatement(
          trialBalance, 
          chartOfAccounts, 
          statementType, 
          client, 
          period,
          format,
          cashFlowMethod
        );
      } catch (error) {
        // Handle specific balance sheet validation errors
        if ((error as Error).message.includes("Balance Sheet does not balance")) {
          return res.status(400).json({ 
            message: "Balance Sheet does not balance",
            errors: {
              balanceSheet: (error as Error).message
            },
            suggestions: [
              "Check trial balance entries for accuracy",
              "Verify all debits and credits are properly recorded",
              "Ensure all accounts are correctly mapped to chart of accounts",
              "Review trial balance for any missing or duplicate entries"
            ]
          });
        }
        
        // Handle other generation errors
        return res.status(500).json({ 
          message: "Failed to generate financial statement",
          errors: {
            generation: error.message || "The statement generation process failed"
          },
          suggestions: [
            "Check trial balance data for completeness",
            "Verify chart of accounts configuration",
            "Contact support if the issue persists"
          ]
        });
      }
      
      // Validate generated statement
      if (!statement || !statement.sections || Object.keys(statement.sections).length === 0) {
        return res.status(500).json({ 
          message: "Failed to generate financial statement",
          errors: {
            generation: "The statement generation process failed to produce valid data"
          },
          suggestions: [
            "Check if trial balance data is properly formatted",
            "Verify chart of accounts structure",
            "Contact support if the issue persists"
          ]
        });
      }

      // Save the generated statement with completed status
      const savedStatement = await storage.createFinancialStatement({
        clientId,
        periodId,
        statementType,
        format: format,
        content: statement,
        status: 'completed', // Changed from 'draft' to 'completed'
        generatedBy: 1
      });
      
      // Log activity
      await storage.createActivityLog({
        userId: 1,
        clientId,
        action: "financial_statement_generated",
        description: `Successfully generated ${statementType} statement from trial balance`,
        entityType: "financial_statement",
        entityId: savedStatement.id,
      });
      
      res.json({
        ...savedStatement,
        message: "Financial statement generated successfully",
        validation: {
          trialBalanceEntries: trialBalance.length,
          chartOfAccountsEntries: chartOfAccounts.length,
          unmappedEntries: 0,
          generatedAt: new Date().toISOString()
        }
      });
    } catch (error) {
      console.error("Error generating statement:", error);
      res.status(500).json({ 
        message: "Failed to generate statement", 
        error: error.message,
        suggestions: [
          "Check if all required data is available",
          "Verify trial balance and chart of accounts",
          "Try again or contact support if the issue persists"
        ]
      });
    }
  });

  // Download working file for trial balance mapping
  app.get("/api/download-working-file/:clientId/:periodId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const periodId = parseInt(req.params.periodId);
      
      const trialBalance = await storage.getTrialBalanceEntries(clientId, periodId);
      const chartOfAccounts = await storage.getChartOfAccounts(clientId);
      const client = await storage.getClient(clientId);
      const periods = await storage.getFinancialPeriods(clientId);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      const period = periods.find(p => p.id === periodId);
      if (!period) {
        return res.status(404).json({ message: "Period not found" });
      }

      // Create mapping analysis
      const mappingAnalysis = {
        clientInfo: {
          name: client.name,
          industry: client.industry,
          periodStart: period.startDate,
          periodEnd: period.endDate
        },
        trialBalanceEntries: trialBalance.map(entry => {
          const account = chartOfAccounts.find(coa => coa.id === entry.accountId);
          return {
            accountId: entry.accountId,
            debitAmount: entry.debitAmount,
            creditAmount: entry.creditAmount,
            balance: parseFloat(entry.debitAmount || "0") - parseFloat(entry.creditAmount || "0"),
            mapped: !!entry.accountId,
            mappedTo: account ? account.accountName : null
          };
        }),
        chartOfAccounts: chartOfAccounts.map(coa => ({
          code: coa.accountCode,
          name: coa.accountName,
          type: coa.accountType,
          ifrsMapping: coa.ifrsMapping,
          isActive: coa.isActive
        })),
        unmappedEntries: trialBalance.filter(entry => !entry.accountId).length,
        totalEntries: trialBalance.length,
        mappingCompleteness: trialBalance.length > 0 ? 
          ((trialBalance.length - trialBalance.filter(entry => !entry.accountId).length) / trialBalance.length * 100).toFixed(1) + '%' : '0%'
      };

      // Set headers for file download
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="working-file-${client.name.replace(/\s+/g, '-')}-${period.startDate}-${period.endDate}.json"`);
      
      res.json(mappingAnalysis);
    } catch (error) {
      console.error("Error generating working file:", error);
      res.status(500).json({ message: "Failed to generate working file" });
    }
  });

  // Audit engagement routes
  app.get("/api/audit-engagements/:clientId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const engagements = await storage.getAuditEngagements(clientId);
      res.json(engagements);
    } catch (error) {
      console.error("Error fetching audit engagements:", error);
      res.status(500).json({ message: "Failed to fetch audit engagements" });
    }
  });

  app.post("/api/audit-engagements", async (req, res) => {
    try {
      const validatedData = insertAuditEngagementSchema.parse(req.body);
      const engagement = await storage.createAuditEngagement(validatedData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.createdBy || 1,
        clientId: engagement.clientId,
        action: "audit_engagement_created",
        description: `Created ${engagement.engagementType} engagement`,
        entityType: "audit_engagement",
        entityId: engagement.id,
      });

      res.status(201).json(engagement);
    } catch (error) {
      console.error("Error creating audit engagement:", error);
      res.status(400).json({ message: "Failed to create audit engagement" });
    }
  });

  // Audit finding routes
  app.get("/api/audit-findings/:engagementId", async (req, res) => {
    try {
      const engagementId = parseInt(req.params.engagementId);
      const findings = await storage.getAuditFindings(engagementId);
      res.json(findings);
    } catch (error) {
      console.error("Error fetching audit findings:", error);
      res.status(500).json({ message: "Failed to fetch audit findings" });
    }
  });

  app.post("/api/audit-findings", async (req, res) => {
    try {
      const validatedData = insertAuditFindingSchema.parse(req.body);
      const finding = await storage.createAuditFinding(validatedData);
      res.status(201).json(finding);
    } catch (error) {
      console.error("Error creating audit finding:", error);
      res.status(400).json({ message: "Failed to create audit finding" });
    }
  });

  // Document routes
  app.get("/api/documents/:clientId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const documents = await storage.getDocuments(clientId);
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.post("/api/documents/upload", upload.single('file'), async (req, res) => {
    try {
      console.log("File upload request received:", {
        file: req.file,
        body: req.body
      });
      
      if (!req.file) {
        console.log("No file in request");
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { clientId, category, uploadedBy } = req.body;
      
      if (!clientId) {
        console.log("No clientId provided");
        return res.status(400).json({ message: "Client ID is required" });
      }
      
      // Upload file to Replit Object Storage
      const uploadResult = await fileStorage.uploadFile(
        req.file, 
        parseInt(clientId), 
        category || 'supporting_docs'
      );
      
      if (!uploadResult.success) {
        console.error("Object Storage upload failed:", uploadResult.error);
        return res.status(500).json({ message: uploadResult.error || "Failed to upload file" });
      }
      
      const documentData = {
        clientId: parseInt(clientId),
        fileName: req.file.originalname,
        fileType: req.file.mimetype,
        fileSize: req.file.size,
        filePath: uploadResult.filePath!, // Object Storage path
        category: category || 'supporting_docs',
        uploadedBy: parseInt(uploadedBy) || 1
      };

      console.log("Creating document with:", documentData);
      
      const document = await storage.createDocument(documentData);

      // Log activity
      await storage.createActivityLog({
        userId: parseInt(uploadedBy) || 1,
        clientId: parseInt(clientId),
        action: "document_upload",
        description: `Uploaded ${req.file.originalname} to Object Storage`,
        entityType: "document",
        entityId: document.id
      });

      console.log("Document created successfully:", document);
      res.status(201).json(document);
    } catch (error) {
      console.error("Error uploading document:", error);
      console.error("Error stack:", error.stack);
      res.status(500).json({ 
        message: "Failed to upload document",
        error: error.message 
      });
    }
  });

  // Process Chart of Accounts file upload and extract to database
  app.post("/api/upload/chart-of-accounts", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { clientId, description } = req.body;
      
      if (!clientId) {
        return res.status(400).json({ message: "Client ID is required" });
      }

      console.log(`Processing chart of accounts file for client ${clientId}`);
      
      // Process the file FIRST before moving it to storage
      console.log(`📁 File path for processing: ${req.file.path}`);
      console.log(`📁 File exists: ${fs.existsSync(req.file.path)}`);
      if (fs.existsSync(req.file.path)) {
        console.log(`📁 File stats:`, fs.statSync(req.file.path));
      }
      
      const processResult = await FileProcessor.processChartOfAccountsFile(
        req.file.path, 
        parseInt(clientId), 
        1 // uploadedBy
      );
      
      console.log(`📊 Processing result:`, processResult);

      // Now upload to file storage after processing
      const uploadResult = await fileStorage.uploadFile(req.file, parseInt(clientId), 'chart_of_accounts');
      
      if (!uploadResult.success) {
        return res.status(500).json({ 
          message: "Failed to upload file", 
          error: uploadResult.error 
        });
      }

      // Save document metadata to database
      const document = await storage.createDocument({
        clientId: parseInt(clientId),
        fileName: req.file.originalname,
        fileType: req.file.mimetype,
        fileSize: req.file.size,
        filePath: uploadResult.filePath,
        category: 'chart_of_accounts',
        uploadedBy: 1,
      });

      // Log activity
      await storage.createActivityLog({
        userId: 1,
        clientId: parseInt(clientId),
        action: "chart_of_accounts_processed",
        description: `Processed chart of accounts file: ${req.file.originalname} (${processResult.processedRows} entries)`,
        entityType: "document",
        entityId: document.id,
      });

      // Clean up uploaded file
      try {
        fs.unlinkSync(req.file.path);
      } catch (cleanupError) {
        console.warn('Failed to clean up temporary file:', cleanupError);
      }

      res.status(201).json({
        document,
        processing: processResult,
        message: `Chart of accounts file processed successfully. ${processResult.processedRows} entries added to database.`
      });
    } catch (error) {
      console.error("Error processing chart of accounts file:", error);
      res.status(500).json({ message: "Failed to process chart of accounts file", error: error.message });
    }
  });

  // Process Trial Balance file upload and extract to database
  app.post("/api/upload/trial-balance", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { clientId, periodId, description } = req.body;
      
      if (!clientId || !periodId) {
        return res.status(400).json({ message: "Client ID and Period ID are required" });
      }

      console.log(`Processing trial balance file for client ${clientId}, period ${periodId}`);
      
      // Process the file FIRST before moving it to storage
      const processResult = await FileProcessor.processTrialBalanceFile(
        req.file.path, 
        parseInt(clientId), 
        parseInt(periodId),
        1 // uploadedBy
      );

      // Now upload to file storage after processing
      const uploadResult = await fileStorage.uploadFile(req.file, parseInt(clientId), 'trial_balance');
      
      if (!uploadResult.success) {
        return res.status(500).json({ 
          message: "Failed to upload file", 
          error: uploadResult.error 
        });
      }

      // Save document metadata to database
      const document = await storage.createDocument({
        clientId: parseInt(clientId),
        fileName: req.file.originalname,
        fileType: req.file.mimetype,
        fileSize: req.file.size,
        filePath: uploadResult.filePath,
        category: 'trial_balance',
        uploadedBy: 1,
      });

      // Log activity
      await storage.createActivityLog({
        userId: 1,
        clientId: parseInt(clientId),
        action: "trial_balance_processed",
        description: `Processed trial balance file: ${req.file.originalname} (${processResult.processedRows} entries)`,
        entityType: "document",
        entityId: document.id,
      });

      // Clean up uploaded file
      try {
        fs.unlinkSync(req.file.path);
      } catch (cleanupError) {
        console.warn('Failed to clean up temporary file:', cleanupError);
      }

      res.status(201).json({
        document,
        processing: processResult,
        message: `Trial balance file processed successfully. ${processResult.processedRows} entries added to database.`
      });
    } catch (error) {
      console.error("Error processing trial balance file:", error);
      res.status(500).json({ message: "Failed to process trial balance file", error: error.message });
    }
  });

  // Process General Ledger file upload and extract to database
  app.post("/api/upload/general-ledger", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { clientId, periodId, description } = req.body;
      
      if (!clientId || !periodId) {
        return res.status(400).json({ message: "Client ID and Period ID are required" });
      }

      console.log(`Processing general ledger file for client ${clientId}, period ${periodId}`);
      
      // Process the file FIRST before moving it to storage
      const processResult = await FileProcessor.processGeneralLedgerFile(
        req.file.path, 
        parseInt(clientId), 
        parseInt(periodId),
        1 // uploadedBy
      );

      // Now upload to file storage after processing
      const uploadResult = await fileStorage.uploadFile(req.file, parseInt(clientId), 'general_ledger');
      
      if (!uploadResult.success) {
        return res.status(500).json({ 
          message: "Failed to upload file", 
          error: uploadResult.error 
        });
      }

      // Save document metadata to database
      const document = await storage.createDocument({
        clientId: parseInt(clientId),
        fileName: req.file.originalname,
        fileType: req.file.mimetype,
        fileSize: req.file.size,
        filePath: uploadResult.filePath,
        category: 'general_ledger',
        uploadedBy: 1,
      });

      // Log activity
      await storage.createActivityLog({
        userId: 1,
        clientId: parseInt(clientId),
        action: "general_ledger_processed",
        description: `Processed general ledger file: ${req.file.originalname} (${processResult.processedRows} entries)`,
        entityType: "document",
        entityId: document.id,
      });

      // Clean up uploaded file
      try {
        fs.unlinkSync(req.file.path);
      } catch (cleanupError) {
        console.warn('Failed to clean up temporary file:', cleanupError);
      }

      res.status(201).json({
        document,
        processing: processResult,
        message: `General ledger file processed successfully. ${processResult.processedRows} entries added to database.`
      });
    } catch (error) {
      console.error("Error processing general ledger file:", error);
      res.status(500).json({ message: "Failed to process general ledger file", error: error.message });
    }
  });

  // COA IFRS Validation endpoint
  app.post("/api/validate-coa/:clientId", async (req, res) => {
    try {
      const { clientId } = req.params;
      
      const client = await storage.getClient(parseInt(clientId));
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      const chartOfAccounts = await storage.getChartOfAccounts(parseInt(clientId));
      
      if (!chartOfAccounts || chartOfAccounts.length === 0) {
        return res.status(400).json({ message: "No Chart of Accounts found for this client" });
      }
      
      // IFRS validation rules
      const validationResults = [];
      
      // 1. Check for required IFRS account types
      const accountTypes = [...new Set(chartOfAccounts.map(acc => acc.accountType))];
      const requiredTypes = ['Asset', 'Liability', 'Equity', 'Revenue', 'Expense'];
      
      requiredTypes.forEach(type => {
        if (accountTypes.includes(type)) {
          validationResults.push({
            check: `Required Account Type: ${type}`,
            status: 'passed',
            message: `${type} accounts are present in the Chart of Accounts`
          });
        } else {
          validationResults.push({
            check: `Required Account Type: ${type}`,
            status: 'error',
            message: `Missing required IFRS account type: ${type}. This is mandatory for IFRS compliance.`
          });
        }
      });
      
      // 2. Check for essential IFRS accounts
      const accountNames = chartOfAccounts.map(acc => acc.accountName);
      const essentialAccounts = ['Cash', 'Accounts Receivable', 'Accounts Payable', 'Common Stock', 'Retained Earnings'];
      
      essentialAccounts.forEach(accountName => {
        if (accountNames.includes(accountName)) {
          validationResults.push({
            check: `Essential IFRS Account: ${accountName}`,
            status: 'passed',
            message: `${accountName} account is properly configured`
          });
        } else {
          validationResults.push({
            check: `Essential IFRS Account: ${accountName}`,
            status: 'warning',
            message: `Recommended IFRS account "${accountName}" is missing. Consider adding for better compliance.`
          });
        }
      });
      
      // 3. Check account code uniqueness
      const accountCodes = chartOfAccounts.map(acc => acc.accountCode);
      const duplicateCodes = accountCodes.filter((code, index) => accountCodes.indexOf(code) !== index);
      
      if (duplicateCodes.length === 0) {
        validationResults.push({
          check: 'Account Code Uniqueness',
          status: 'passed',
          message: 'All account codes are unique'
        });
      } else {
        validationResults.push({
          check: 'Account Code Uniqueness',
          status: 'error',
          message: `Duplicate account codes found: ${duplicateCodes.join(', ')}. Each account must have a unique code.`
        });
      }
      
      // 4. Check account code format (should be numeric)
      const invalidCodes = accountCodes.filter(code => !/^\d+$/.test(code));
      if (invalidCodes.length === 0) {
        validationResults.push({
          check: 'Account Code Format',
          status: 'passed',
          message: 'All account codes follow numeric format'
        });
      } else {
        validationResults.push({
          check: 'Account Code Format',
          status: 'warning',
          message: `Non-numeric account codes found: ${invalidCodes.join(', ')}. Consider using numeric codes for better system integration.`
        });
      }
      
      // 5. Check IFRS account classification
      const assetAccounts = chartOfAccounts.filter(acc => acc.accountType === 'Asset');
      const liabilityAccounts = chartOfAccounts.filter(acc => acc.accountType === 'Liability');
      const equityAccounts = chartOfAccounts.filter(acc => acc.accountType === 'Equity');
      const revenueAccounts = chartOfAccounts.filter(acc => acc.accountType === 'Revenue');
      const expenseAccounts = chartOfAccounts.filter(acc => acc.accountType === 'Expense');
      
      validationResults.push({
        check: 'IFRS Account Distribution',
        status: 'passed',
        message: `Account distribution: ${assetAccounts.length} Assets, ${liabilityAccounts.length} Liabilities, ${equityAccounts.length} Equity, ${revenueAccounts.length} Revenue, ${expenseAccounts.length} Expenses`
      });
      
      // 6. Check for balance sheet equation components
      const hasCurrentAssets = assetAccounts.some(acc => acc.accountName.toLowerCase().includes('cash') || acc.accountName.toLowerCase().includes('receivable'));
      const hasCurrentLiabilities = liabilityAccounts.some(acc => acc.accountName.toLowerCase().includes('payable'));
      const hasShareCapital = equityAccounts.some(acc => acc.accountName.toLowerCase().includes('stock') || acc.accountName.toLowerCase().includes('capital'));
      
      if (hasCurrentAssets && hasCurrentLiabilities && hasShareCapital) {
        validationResults.push({
          check: 'Balance Sheet Equation Components',
          status: 'passed',
          message: 'Essential balance sheet components are present (Current Assets, Current Liabilities, Share Capital)'
        });
      } else {
        validationResults.push({
          check: 'Balance Sheet Equation Components',
          status: 'warning',
          message: 'Some essential balance sheet components may be missing. Ensure you have current assets, current liabilities, and share capital accounts.'
        });
      }
      
      // 7. Check for UAE specific requirements
      if (client.jurisdiction === 'UAE') {
        validationResults.push({
          check: 'UAE Jurisdiction Compliance',
          status: 'passed',
          message: 'Chart of Accounts is configured for UAE jurisdiction with IFRS standards'
        });
        
        // Check for UAE-specific account recommendations
        const hasZakatAccount = accountNames.some(name => name.toLowerCase().includes('zakat'));
        if (!hasZakatAccount) {
          validationResults.push({
            check: 'UAE Zakat Provisions',
            status: 'warning',
            message: 'Consider adding a Zakat provision account for UAE Islamic finance compliance (optional for most entities)'
          });
        }
      }
      
      // Summary
      const errors = validationResults.filter(r => r.status === 'error').length;
      const warnings = validationResults.filter(r => r.status === 'warning').length;
      const passed = validationResults.filter(r => r.status === 'passed').length;
      
      const result = {
        clientName: client.name,
        totalAccounts: chartOfAccounts.length,
        validationSummary: {
          passed,
          warnings,
          errors,
          overallStatus: errors > 0 ? 'failed' : warnings > 0 ? 'warning' : 'passed'
        },
        validationResults,
        ifrsCompliance: errors === 0 ? 'Compliant' : 'Non-Compliant',
        recommendations: validationResults.filter(r => r.status === 'warning').map(r => r.message)
      };

      // Save validation result to database
      await storage.createValidationResult({
        clientId: parseInt(clientId),
        validationType: "ifrs_coa",
        totalAccounts: chartOfAccounts.length,
        passedChecks: passed,
        warningChecks: warnings,
        errorChecks: errors,
        overallStatus: result.validationSummary.overallStatus,
        ifrsCompliance: result.ifrsCompliance,
        detailedResults: validationResults,
        recommendations: result.recommendations,
        validatedBy: 1 // TODO: Get actual user ID from session
      });

      res.json(result);
      
    } catch (error) {
      console.error("Error validating COA:", error);
      res.status(500).json({ message: "Failed to validate Chart of Accounts" });
    }
  });

  // Get validation history for a client
  app.get("/api/validation-results/:clientId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const results = await storage.getValidationResults(clientId);
      res.json(results);
    } catch (error) {
      console.error("Error fetching validation results:", error);
      res.status(500).json({ message: "Failed to fetch validation results" });
    }
  });

  // Get detailed validation result
  app.get("/api/validation-result/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const result = await storage.getValidationResult(id);
      if (!result) {
        return res.status(404).json({ message: "Validation result not found" });
      }
      res.json(result);
    } catch (error) {
      console.error("Error fetching validation result:", error);
      res.status(500).json({ message: "Failed to fetch validation result" });
    }
  });

  // Mark validation result as resolved
  app.patch("/api/validation-result/:id/resolve", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const resolvedBy = 1; // TODO: Get actual user ID from session
      const result = await storage.markValidationResolved(id, resolvedBy);
      res.json(result);
    } catch (error) {
      console.error("Error resolving validation result:", error);
      res.status(500).json({ message: "Failed to resolve validation result" });
    }
  });

  // Test File Storage route
  app.get("/api/test-storage", async (req, res) => {
    try {
      // Create a temporary test file
      const testData = Buffer.from("Hello Secure Storage Test");
      const tempPath = path.join(process.cwd(), 'uploads', 'temp-test.txt');
      
      // Ensure uploads directory exists
      await fs.promises.mkdir(path.dirname(tempPath), { recursive: true });
      await fs.promises.writeFile(tempPath, testData);
      
      const uploadResult = await fileStorage.uploadFile({
        originalname: "test.txt",
        mimetype: "text/plain",
        size: testData.length,
        path: tempPath
      } as Express.Multer.File, 1, "test");
      
      let downloadTest = false;
      if (uploadResult.success) {
        // Test download
        const downloadedData = await fileStorage.downloadFile(uploadResult.filePath!);
        downloadTest = downloadedData !== null && downloadedData.toString() === testData.toString();
      }
      
      res.json({
        success: uploadResult.success,
        message: uploadResult.success ? "File storage working!" : uploadResult.error,
        filePath: uploadResult.filePath,
        downloadTest: downloadTest
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  });

  // File download route
  app.get("/api/files/download/:filePath(*)", async (req, res) => {
    try {
      const filePath = decodeURIComponent(req.params.filePath);
      const fileData = await fileStorage.downloadFile(filePath);
      
      if (!fileData) {
        return res.status(404).json({ message: "File not found" });
      }
      
      // Extract original filename from path
      const fileName = filePath.split('/').pop() || 'download';
      const originalName = fileName.substring(fileName.indexOf('-') + 1);
      
      res.setHeader('Content-Disposition', `attachment; filename="${originalName}"`);
      res.setHeader('Content-Type', 'application/octet-stream');
      res.send(fileData);
    } catch (error) {
      console.error("Error downloading file:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });

  // Compliance routes
  app.get("/api/compliance/:clientId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const items = await storage.getComplianceItems(clientId);
      res.json(items);
    } catch (error) {
      console.error("Error fetching compliance items:", error);
      res.status(500).json({ message: "Failed to fetch compliance items" });
    }
  });

  app.post("/api/compliance", async (req, res) => {
    try {
      const validatedData = insertComplianceItemSchema.parse(req.body);
      const item = await storage.createComplianceItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      console.error("Error creating compliance item:", error);
      res.status(400).json({ message: "Failed to create compliance item" });
    }
  });

  // Activity log routes
  app.get("/api/activity-log/:clientId?", async (req, res) => {
    try {
      const clientId = req.params.clientId ? parseInt(req.params.clientId) : undefined;
      const logs = await storage.getActivityLog(clientId);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching activity log:", error);
      res.status(500).json({ message: "Failed to fetch activity log" });
    }
  });

  // Report template routes
  app.get("/api/report-templates", async (req, res) => {
    try {
      const templates = await storage.getReportTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching report templates:", error);
      res.status(500).json({ message: "Failed to fetch report templates" });
    }
  });

  app.post("/api/report-templates", async (req, res) => {
    try {
      const validatedData = insertReportTemplateSchema.parse(req.body);
      const template = await storage.createReportTemplate(validatedData);
      res.status(201).json(template);
    } catch (error) {
      console.error("Error creating report template:", error);
      res.status(400).json({ message: "Failed to create report template" });
    }
  });

  // Generated report routes
  app.get("/api/generated-reports/:clientId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const reports = await storage.getGeneratedReports(clientId);
      res.json(reports);
    } catch (error) {
      console.error("Error fetching generated reports:", error);
      res.status(500).json({ message: "Failed to fetch generated reports" });
    }
  });

  app.post("/api/generated-reports", async (req, res) => {
    try {
      const validatedData = insertGeneratedReportSchema.parse(req.body);
      const report = await storage.createGeneratedReport(validatedData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.generatedBy || 1,
        clientId: report.clientId,
        action: "report_generated",
        description: `Generated ${report.reportType} report`,
        entityType: "generated_report",
        entityId: report.id,
      });

      res.status(201).json(report);
    } catch (error) {
      console.error("Error creating generated report:", error);
      res.status(400).json({ message: "Failed to create generated report" });
    }
  });

  // Export financial statement in different formats
  app.get("/api/financial-statements/:statementId/export/:format", async (req, res) => {
    try {
      const statementId = parseInt(req.params.statementId);
      const format = req.params.format;
      
      const statement = await storage.getFinancialStatements(1).then(statements => 
        statements.find(s => s.id === statementId)
      );
      
      if (!statement) {
        return res.status(404).json({ message: "Financial statement not found" });
      }

      // Generate file based on format
      let contentType = '';
      let filename = '';
      
      switch (format) {
        case 'word':
          contentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
          filename = `${statement.statementType}_${statement.clientId}.docx`;
          break;
        case 'excel':
          contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
          filename = `${statement.statementType}_${statement.clientId}.xlsx`;
          break;
        case 'pdf':
          contentType = 'application/pdf';
          filename = `${statement.statementType}_${statement.clientId}.pdf`;
          break;
        default:
          contentType = 'text/html';
          filename = `${statement.statementType}_${statement.clientId}.html`;
      }

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      // Generate comprehensive financial statement HTML
      const htmlContent = generateFinancialStatementHTML(statement);
      res.send(htmlContent);
    } catch (error) {
      console.error("Error exporting financial statement:", error);
      res.status(500).json({ message: "Failed to export financial statement" });
    }
  });

  // Export report in different formats
  app.get("/api/reports/:reportId/export/:format", async (req, res) => {
    try {
      const reportId = parseInt(req.params.reportId);
      const format = req.params.format;
      
      const report = await storage.getGeneratedReport(reportId);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }

      // Generate file based on format
      let contentType = '';
      let filename = '';
      
      switch (format) {
        case 'word':
          contentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
          filename = `${report.title || 'report'}.docx`;
          break;
        case 'excel':
          contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
          filename = `${report.title || 'report'}.xlsx`;
          break;
        case 'pdf':
          contentType = 'application/pdf';
          filename = `${report.title || 'report'}.pdf`;
          break;
        default:
          contentType = 'text/html';
          filename = `${report.title || 'report'}.html`;
      }

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      // For now, return HTML content - would need proper document generation libraries
      const htmlContent = generateReportHTML(report);
      res.send(htmlContent);
    } catch (error) {
      console.error("Error exporting report:", error);
      res.status(500).json({ message: "Failed to export report" });
    }
  });

  // Enhanced Audit Procedures Routes
  app.get("/api/audit-procedures/:engagementId", async (req, res) => {
    try {
      const engagementId = parseInt(req.params.engagementId);
      const procedures = await storage.getAuditProcedures(engagementId);
      res.json(procedures);
    } catch (error) {
      console.error("Error fetching audit procedures:", error);
      res.status(500).json({ message: "Failed to fetch audit procedures" });
    }
  });

  app.post("/api/audit-procedures", async (req, res) => {
    try {
      const validatedData = insertAuditProcedureSchema.parse(req.body);
      const procedure = await storage.createAuditProcedure(validatedData);
      res.status(201).json(procedure);
    } catch (error) {
      console.error("Error creating audit procedure:", error);
      res.status(400).json({ message: "Failed to create audit procedure" });
    }
  });

  app.put("/api/audit-procedures/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertAuditProcedureSchema.partial().parse(req.body);
      const procedure = await storage.updateAuditProcedure(id, validatedData);
      res.json(procedure);
    } catch (error) {
      console.error("Error updating audit procedure:", error);
      res.status(400).json({ message: "Failed to update audit procedure" });
    }
  });

  // ICOFR Assessment Routes
  app.get("/api/icofr-assessments/:engagementId", async (req, res) => {
    try {
      const engagementId = parseInt(req.params.engagementId);
      const assessments = await storage.getIcofrAssessments(engagementId);
      res.json(assessments);
    } catch (error) {
      console.error("Error fetching ICOFR assessments:", error);
      res.status(500).json({ message: "Failed to fetch ICOFR assessments" });
    }
  });

  app.post("/api/icofr-assessments", async (req, res) => {
    try {
      const validatedData = insertIcofrAssessmentSchema.parse(req.body);
      const assessment = await storage.createIcofrAssessment(validatedData);
      res.status(201).json(assessment);
    } catch (error) {
      console.error("Error creating ICOFR assessment:", error);
      res.status(400).json({ message: "Failed to create ICOFR assessment" });
    }
  });

  app.put("/api/icofr-assessments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertIcofrAssessmentSchema.partial().parse(req.body);
      const assessment = await storage.updateIcofrAssessment(id, validatedData);
      res.json(assessment);
    } catch (error) {
      console.error("Error updating ICOFR assessment:", error);
      res.status(400).json({ message: "Failed to update ICOFR assessment" });
    }
  });

  // Enhanced Audit Analytics Routes
  app.get("/api/audit-analytics/risk-analysis/:clientId/:periodId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const periodId = parseInt(req.params.periodId);
      const riskAnalysis = await storage.getAccountRiskAnalysis(clientId, periodId);
      res.json(riskAnalysis);
    } catch (error) {
      console.error("Error fetching risk analysis:", error);
      res.status(500).json({ message: "Failed to fetch risk analysis" });
    }
  });

  app.get("/api/audit-analytics/anomalies/:clientId/:periodId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const periodId = parseInt(req.params.periodId);
      const anomalies = await storage.getTrialBalanceAnomalies(clientId, periodId);
      res.json(anomalies);
    } catch (error) {
      console.error("Error fetching anomalies:", error);
      res.status(500).json({ message: "Failed to fetch anomalies" });
    }
  });

  app.get("/api/audit-analytics/journal-testing/:clientId/:periodId", async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const periodId = parseInt(req.params.periodId);
      const sampleSize = parseInt(req.query.sampleSize as string) || 10;
      const journalTesting = await storage.getJournalEntryTesting(clientId, periodId, sampleSize);
      res.json(journalTesting);
    } catch (error) {
      console.error("Error fetching journal testing:", error);
      res.status(500).json({ message: "Failed to fetch journal testing" });
    }
  });

  // Generate Automated Audit Procedures based on financial data
  app.post("/api/audit-procedures/generate-automated/:engagementId", async (req, res) => {
    try {
      const engagementId = parseInt(req.params.engagementId);
      const { clientId, periodId } = req.body;

      // Get engagement details
      const engagements = await storage.getAuditEngagements(clientId);
      const engagement = engagements.find(e => e.id === engagementId);
      
      if (!engagement) {
        return res.status(404).json({ message: "Audit engagement not found" });
      }

      // Get financial data for automated procedure generation
      const [trialBalance, chartOfAccounts, riskAnalysis] = await Promise.all([
        storage.getTrialBalanceEntries(clientId, periodId),
        storage.getChartOfAccounts(clientId),
        storage.getAccountRiskAnalysis(clientId, periodId)
      ]);

      // Generate automated audit procedures based on financial data
      const automatedProcedures = [];

      // Cash procedures
      const cashAccounts = chartOfAccounts.filter(acc => acc.accountType === 'Asset' && acc.accountName.toLowerCase().includes('cash'));
      if (cashAccounts.length > 0) {
        automatedProcedures.push({
          engagementId,
          procedureType: 'substantive',
          auditArea: 'cash',
          accountCode: cashAccounts[0].accountCode,
          description: 'Perform bank reconciliation and verify cash balances as of period end',
          expectedResult: 'Bank balances reconcile to general ledger, no material variances',
          materiality: 5000,
          samplingMethod: 'judgmental',
          status: 'not_started',
          performedBy: 1
        });
      }

      // Revenue procedures
      const revenueAccounts = chartOfAccounts.filter(acc => acc.accountType === 'Revenue');
      if (revenueAccounts.length > 0) {
        automatedProcedures.push({
          engagementId,
          procedureType: 'substantive',
          auditArea: 'revenue',
          accountCode: revenueAccounts[0].accountCode,
          description: 'Test revenue recognition accuracy through detailed transaction testing',
          expectedResult: 'Revenue is recognized in correct period, proper supporting documentation',
          materiality: 10000,
          samplingMethod: 'statistical',
          sampleSize: 25,
          populationSize: trialBalance.filter(tb => tb.creditAmount > 0).length,
          status: 'not_started',
          performedBy: 1
        });
      }

      // High-risk account procedures based on risk analysis
      const highRiskAccounts = riskAnalysis.filter(acc => acc.riskScore >= 3);
      for (const riskAccount of highRiskAccounts.slice(0, 3)) { // Top 3 high-risk accounts
        automatedProcedures.push({
          engagementId,
          procedureType: 'analytical_review',
          auditArea: riskAccount.accountType.toLowerCase(),
          accountCode: riskAccount.accountCode,
          description: `Enhanced testing of ${riskAccount.accountName} due to high risk rating - perform detailed substantive procedures`,
          expectedResult: 'Account balance is accurate and properly supported',
          materiality: Math.max(1000, riskAccount.balance * 0.05), // 5% of balance or min 1000
          samplingMethod: 'monetary_unit',
          status: 'not_started',
          performedBy: 1
        });
      }

      // Create all automated procedures
      const createdProcedures = [];
      for (const procedure of automatedProcedures) {
        try {
          const created = await storage.createAuditProcedure(procedure);
          createdProcedures.push(created);
        } catch (error) {
          console.error('Error creating automated procedure:', error);
        }
      }

      res.json({
        message: `Generated ${createdProcedures.length} automated audit procedures`,
        procedures: createdProcedures,
        basedOn: {
          trialBalanceEntries: trialBalance.length,
          chartOfAccountsEntries: chartOfAccounts.length,
          highRiskAccounts: highRiskAccounts.length
        }
      });

    } catch (error) {
      console.error("Error generating automated procedures:", error);
      res.status(500).json({ message: "Failed to generate automated procedures" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function generateFinancialStatementHTML(statement: any): string {
  const content = statement.content || {};
  const metadata = content.metadata || {};
  const sections = content.sections || {};
  const notes = content.notes || {};
  
  let bodyContent = "";
  
  if (statement.statementType === 'balance_sheet') {
    bodyContent = `
      <div class="statement-content">
        <h2>BALANCE SHEET</h2>
        <h3>As at ${metadata.period}</h3>
        
        <div class="section">
          <h4>ASSETS</h4>
          <div class="subsection">
            <h5>Current Assets</h5>
            <table class="table">
              <tr><td>Cash and Cash Equivalents</td><td class="amount">${(sections.assets?.current?.cash || 0).toLocaleString()}</td></tr>
              <tr><td>Trade and Other Receivables</td><td class="amount">${(sections.assets?.current?.receivables || 0).toLocaleString()}</td></tr>
              <tr><td>Inventory</td><td class="amount">${(sections.assets?.current?.inventory || 0).toLocaleString()}</td></tr>
              <tr><td>Prepaid Expenses</td><td class="amount">${(sections.assets?.current?.prepaid || 0).toLocaleString()}</td></tr>
              <tr class="total"><td><strong>Total Current Assets</strong></td><td class="amount"><strong>${(sections.assets?.current?.total || 0).toLocaleString()}</strong></td></tr>
            </table>
          </div>
          
          <div class="subsection">
            <h5>Non-Current Assets</h5>
            <table class="table">
              <tr><td>Property, Plant and Equipment</td><td class="amount">${(sections.assets?.nonCurrent?.property || 0).toLocaleString()}</td></tr>
              <tr><td>Intangible Assets</td><td class="amount">${(sections.assets?.nonCurrent?.intangible || 0).toLocaleString()}</td></tr>
              <tr class="total"><td><strong>Total Non-Current Assets</strong></td><td class="amount"><strong>${(sections.assets?.nonCurrent?.total || 0).toLocaleString()}</strong></td></tr>
            </table>
          </div>
          
          <div class="grand-total">
            <table class="table">
              <tr class="grand-total-row"><td><strong>TOTAL ASSETS</strong></td><td class="amount"><strong>${(sections.assets?.totalAssets || 0).toLocaleString()}</strong></td></tr>
            </table>
          </div>
        </div>
        
        <div class="section">
          <h4>LIABILITIES AND EQUITY</h4>
          <div class="subsection">
            <h5>Current Liabilities</h5>
            <table class="table">
              <tr><td>Trade and Other Payables</td><td class="amount">${(sections.liabilities?.current?.payables || 0).toLocaleString()}</td></tr>
              <tr><td>Accrued Expenses</td><td class="amount">${(sections.liabilities?.current?.accrued || 0).toLocaleString()}</td></tr>
              <tr><td>Short-term Debt</td><td class="amount">${(sections.liabilities?.current?.shortTermDebt || 0).toLocaleString()}</td></tr>
              <tr class="total"><td><strong>Total Current Liabilities</strong></td><td class="amount"><strong>${(sections.liabilities?.current?.total || 0).toLocaleString()}</strong></td></tr>
            </table>
          </div>
          
          <div class="subsection">
            <h5>Non-Current Liabilities</h5>
            <table class="table">
              <tr><td>Long-term Debt</td><td class="amount">${(sections.liabilities?.nonCurrent?.longTermDebt || 0).toLocaleString()}</td></tr>
              <tr><td>Provisions</td><td class="amount">${(sections.liabilities?.nonCurrent?.provisions || 0).toLocaleString()}</td></tr>
              <tr class="total"><td><strong>Total Non-Current Liabilities</strong></td><td class="amount"><strong>${(sections.liabilities?.nonCurrent?.total || 0).toLocaleString()}</strong></td></tr>
            </table>
          </div>
          
          <div class="subsection">
            <h5>Equity</h5>
            <table class="table">
              <tr><td>Share Capital</td><td class="amount">${(sections.equity?.shareCapital || 0).toLocaleString()}</td></tr>
              <tr><td>Retained Earnings</td><td class="amount">${(sections.equity?.retainedEarnings || 0).toLocaleString()}</td></tr>
              <tr class="total"><td><strong>Total Equity</strong></td><td class="amount"><strong>${(sections.equity?.totalEquity || 0).toLocaleString()}</strong></td></tr>
            </table>
          </div>
          
          <div class="grand-total">
            <table class="table">
              <tr class="grand-total-row"><td><strong>TOTAL LIABILITIES AND EQUITY</strong></td><td class="amount"><strong>${(sections.totalEquityLiabilities || 0).toLocaleString()}</strong></td></tr>
            </table>
          </div>
        </div>
      </div>
    `;
  } else if (statement.statementType === 'income_statement') {
    bodyContent = `
      <div class="statement-content">
        <h2>INCOME STATEMENT</h2>
        <h3>For the year ended ${metadata.period}</h3>
        
        <div class="section">
          <h4>REVENUE</h4>
          <table class="table">
            <tr><td>Sales Revenue</td><td class="amount">${(sections.revenue?.sales || 0).toLocaleString()}</td></tr>
            <tr><td>Other Income</td><td class="amount">${(sections.revenue?.otherIncome || 0).toLocaleString()}</td></tr>
            <tr class="total"><td><strong>Total Revenue</strong></td><td class="amount"><strong>${(sections.revenue?.totalRevenue || 0).toLocaleString()}</strong></td></tr>
          </table>
        </div>
        
        <div class="section">
          <h4>EXPENSES</h4>
          <table class="table">
            <tr><td>Cost of Sales</td><td class="amount">(${(sections.expenses?.costOfSales || 0).toLocaleString()})</td></tr>
            <tr><td>Operating Expenses</td><td class="amount">(${(sections.expenses?.operating || 0).toLocaleString()})</td></tr>
            <tr><td>Administrative Expenses</td><td class="amount">(${(sections.expenses?.administrative || 0).toLocaleString()})</td></tr>
            <tr><td>Financial Expenses</td><td class="amount">(${(sections.expenses?.financial || 0).toLocaleString()})</td></tr>
            <tr class="total"><td><strong>Total Expenses</strong></td><td class="amount"><strong>(${(sections.expenses?.totalExpenses || 0).toLocaleString()})</strong></td></tr>
          </table>
        </div>
        
        <div class="section">
          <h4>PROFIT AND LOSS</h4>
          <table class="table">
            <tr><td>Gross Profit</td><td class="amount">${(sections.grossProfit || 0).toLocaleString()}</td></tr>
            <tr class="grand-total-row"><td><strong>Net Income</strong></td><td class="amount"><strong>${(sections.netIncome || 0).toLocaleString()}</strong></td></tr>
          </table>
        </div>
      </div>
    `;
  } else if (statement.statementType === 'cash_flow') {
    const isDirectMethod = metadata.cashFlowMethod === 'direct';
    
    let operatingSection = '';
    if (isDirectMethod) {
      operatingSection = `
        <div class="section">
          <h4>OPERATING ACTIVITIES (Direct Method)</h4>
          <table class="table">
            <tr><td colspan="2" style="font-weight: bold;">Cash Receipts:</td></tr>
            <tr><td style="padding-left: 20px;">From customers</td><td class="amount">${(sections.operating?.cashReceipts?.fromCustomers || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">From interest</td><td class="amount">${(sections.operating?.cashReceipts?.fromInterest || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">From other operating activities</td><td class="amount">${(sections.operating?.cashReceipts?.fromOtherOperating || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;"><strong>Total Cash Receipts</strong></td><td class="amount"><strong>${(sections.operating?.cashReceipts?.total || 0).toLocaleString()}</strong></td></tr>
            
            <tr><td colspan="2" style="font-weight: bold; padding-top: 10px;">Cash Payments:</td></tr>
            <tr><td style="padding-left: 20px;">To suppliers</td><td class="amount">(${Math.abs(sections.operating?.cashPayments?.toSuppliers || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;">To employees</td><td class="amount">(${Math.abs(sections.operating?.cashPayments?.toEmployees || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;">For operating expenses</td><td class="amount">(${Math.abs(sections.operating?.cashPayments?.forOperatingExpenses || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;">For interest</td><td class="amount">(${Math.abs(sections.operating?.cashPayments?.forInterest || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;">For taxes</td><td class="amount">(${Math.abs(sections.operating?.cashPayments?.forTaxes || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;"><strong>Total Cash Payments</strong></td><td class="amount"><strong>(${Math.abs(sections.operating?.cashPayments?.total || 0).toLocaleString()})</strong></td></tr>
            
            <tr class="total"><td><strong>Net Cash from Operating Activities</strong></td><td class="amount"><strong>${(sections.operating?.totalOperating || 0).toLocaleString()}</strong></td></tr>
          </table>
        </div>
      `;
    } else {
      operatingSection = `
        <div class="section">
          <h4>OPERATING ACTIVITIES (Indirect Method)</h4>
          <table class="table">
            <tr><td>Net Income</td><td class="amount">${(sections.operating?.netIncome || 0).toLocaleString()}</td></tr>
            <tr><td colspan="2" style="font-weight: bold; padding-top: 10px;">Adjustments for non-cash items:</td></tr>
            <tr><td style="padding-left: 20px;">Depreciation</td><td class="amount">${(sections.operating?.adjustments?.depreciation || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">Amortization</td><td class="amount">${(sections.operating?.adjustments?.amortization || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">Bad debt expense</td><td class="amount">${(sections.operating?.adjustments?.badDebtExpense || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">Gain on sale of assets</td><td class="amount">${(sections.operating?.adjustments?.gainOnSaleOfAssets || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">Loss on sale of assets</td><td class="amount">${(sections.operating?.adjustments?.lossOnSaleOfAssets || 0).toLocaleString()}</td></tr>
            
            <tr><td colspan="2" style="font-weight: bold; padding-top: 10px;">Changes in working capital:</td></tr>
            <tr><td style="padding-left: 20px;">Receivables</td><td class="amount">${(sections.operating?.workingCapitalChanges?.receivables || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">Inventory</td><td class="amount">${(sections.operating?.workingCapitalChanges?.inventory || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">Prepaid expenses</td><td class="amount">${(sections.operating?.workingCapitalChanges?.prepaidExpenses || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">Payables</td><td class="amount">${(sections.operating?.workingCapitalChanges?.payables || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">Accrued expenses</td><td class="amount">${(sections.operating?.workingCapitalChanges?.accruedExpenses || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">Deferred revenue</td><td class="amount">${(sections.operating?.workingCapitalChanges?.deferredRevenue || 0).toLocaleString()}</td></tr>
            
            <tr class="total"><td><strong>Net Cash from Operating Activities</strong></td><td class="amount"><strong>${(sections.operating?.totalOperating || 0).toLocaleString()}</strong></td></tr>
          </table>
        </div>
      `;
    }
    
    bodyContent = `
      <div class="statement-content">
        <h2>CASH FLOW STATEMENT</h2>
        <h3>For the year ended ${metadata.period}</h3>
        <h4 style="text-align: center; margin-bottom: 20px; font-style: italic;">Prepared using the ${isDirectMethod ? 'Direct' : 'Indirect'} Method</h4>
        
        ${operatingSection}
        
        <div class="section">
          <h4>INVESTING ACTIVITIES</h4>
          <table class="table">
            <tr><td colspan="2" style="font-weight: bold;">Cash Receipts:</td></tr>
            <tr><td style="padding-left: 20px;">From sale of assets</td><td class="amount">${(sections.investing?.cashReceipts?.fromSaleOfAssets || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">From investments</td><td class="amount">${(sections.investing?.cashReceipts?.fromInvestments || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;"><strong>Total Cash Receipts</strong></td><td class="amount"><strong>${(sections.investing?.cashReceipts?.total || 0).toLocaleString()}</strong></td></tr>
            
            <tr><td colspan="2" style="font-weight: bold; padding-top: 10px;">Cash Payments:</td></tr>
            <tr><td style="padding-left: 20px;">For property purchases</td><td class="amount">(${Math.abs(sections.investing?.cashPayments?.forPropertyPurchases || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;">For equipment purchases</td><td class="amount">(${Math.abs(sections.investing?.cashPayments?.forEquipmentPurchases || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;">For intangible assets</td><td class="amount">(${Math.abs(sections.investing?.cashPayments?.forIntangibleAssets || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;">For investments</td><td class="amount">(${Math.abs(sections.investing?.cashPayments?.forInvestments || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;"><strong>Total Cash Payments</strong></td><td class="amount"><strong>(${Math.abs(sections.investing?.cashPayments?.total || 0).toLocaleString()})</strong></td></tr>
            
            <tr class="total"><td><strong>Net Cash from Investing Activities</strong></td><td class="amount"><strong>${(sections.investing?.totalInvesting || 0).toLocaleString()}</strong></td></tr>
          </table>
        </div>
        
        <div class="section">
          <h4>FINANCING ACTIVITIES</h4>
          <table class="table">
            <tr><td colspan="2" style="font-weight: bold;">Cash Receipts:</td></tr>
            <tr><td style="padding-left: 20px;">From borrowings</td><td class="amount">${(sections.financing?.cashReceipts?.fromBorrowings || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;">From equity issuance</td><td class="amount">${(sections.financing?.cashReceipts?.fromEquityIssuance || 0).toLocaleString()}</td></tr>
            <tr><td style="padding-left: 20px;"><strong>Total Cash Receipts</strong></td><td class="amount"><strong>${(sections.financing?.cashReceipts?.total || 0).toLocaleString()}</strong></td></tr>
            
            <tr><td colspan="2" style="font-weight: bold; padding-top: 10px;">Cash Payments:</td></tr>
            <tr><td style="padding-left: 20px;">For loan repayments</td><td class="amount">(${Math.abs(sections.financing?.cashPayments?.forLoanRepayments || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;">For dividends</td><td class="amount">(${Math.abs(sections.financing?.cashPayments?.forDividends || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;">For share repurchases</td><td class="amount">(${Math.abs(sections.financing?.cashPayments?.forShareRepurchases || 0).toLocaleString()})</td></tr>
            <tr><td style="padding-left: 20px;"><strong>Total Cash Payments</strong></td><td class="amount"><strong>(${Math.abs(sections.financing?.cashPayments?.total || 0).toLocaleString()})</strong></td></tr>
            
            <tr class="total"><td><strong>Net Cash from Financing Activities</strong></td><td class="amount"><strong>${(sections.financing?.totalFinancing || 0).toLocaleString()}</strong></td></tr>
          </table>
        </div>
        
        <div class="section">
          <h4>CASH FLOW SUMMARY</h4>
          <table class="table">
            <tr><td>Net Change in Cash</td><td class="amount">${(sections.netCashFlow || 0).toLocaleString()}</td></tr>
            <tr><td>Cash at Beginning of Year</td><td class="amount">${(sections.beginningCash || 0).toLocaleString()}</td></tr>
            <tr class="grand-total-row"><td><strong>Cash at End of Year</strong></td><td class="amount"><strong>${(sections.endingCash || 0).toLocaleString()}</strong></td></tr>
          </table>
        </div>
      </div>
    `;
  }
  
  // Add notes section
  let notesSection = "";
  if (notes && Object.keys(notes).length > 0) {
    notesSection = `
      <div class="notes-section">
        <h2>NOTES TO THE FINANCIAL STATEMENTS</h2>
        ${Object.entries(notes).map(([key, value], index) => `
          <div class="note">
            <h4>${index + 1}. ${key.replace(/note\d+_/, '').replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</h4>
            <p>${value}</p>
          </div>
        `).join('')}
      </div>
    `;
  }

  // Add auditor report section
  let auditorReportSection = "";
  if (content.auditorReport && Object.keys(content.auditorReport).length > 0) {
    auditorReportSection = `
      <div class="auditor-report-section">
        <h2>${content.auditorReport.opinion || 'INDEPENDENT AUDITOR\'S REPORT'}</h2>
        <div class="auditor-content">
          <div class="auditor-section">
            <h4>Scope of Audit</h4>
            <p>${content.auditorReport.scope || 'Audit scope not specified'}</p>
          </div>
          <div class="auditor-section">
            <h4>Opinion</h4>
            <p>${content.auditorReport.opinion_paragraph || 'Opinion not specified'}</p>
          </div>
          <div class="auditor-section">
            <h4>Management's Responsibility</h4>
            <p>${content.auditorReport.management_responsibility || 'Management responsibility not specified'}</p>
          </div>
          <div class="auditor-section">
            <h4>Auditor's Responsibility</h4>
            <p>${content.auditorReport.auditor_responsibility || 'Auditor responsibility not specified'}</p>
          </div>
          <div class="auditor-section">
            <h4>Key Audit Matters</h4>
            <p>${content.auditorReport.key_audit_matters || 'Key audit matters not specified'}</p>
          </div>
          ${content.auditorReport.revenue_testing ? `
            <div class="auditor-section">
              <h4>Revenue Testing</h4>
              <p>${content.auditorReport.revenue_testing}</p>
            </div>
          ` : ''}
          ${content.auditorReport.expense_verification ? `
            <div class="auditor-section">
              <h4>Expense Verification</h4>
              <p>${content.auditorReport.expense_verification}</p>
            </div>
          ` : ''}
          ${content.auditorReport.cash_flow_testing ? `
            <div class="auditor-section">
              <h4>Cash Flow Testing</h4>
              <p>${content.auditorReport.cash_flow_testing}</p>
            </div>
          ` : ''}
          ${content.auditorReport.reconciliation_procedures ? `
            <div class="auditor-section">
              <h4>Reconciliation Procedures</h4>
              <p>${content.auditorReport.reconciliation_procedures}</p>
            </div>
          ` : ''}
          <div class="auditor-section">
            <h4>Conclusion</h4>
            <p>${content.auditorReport.conclusion || 'Conclusion not specified'}</p>
          </div>
        </div>
      </div>
    `;
  }

  // Add management report section
  let managementReportSection = "";
  if (content.managementReport && Object.keys(content.managementReport).length > 0) {
    managementReportSection = `
      <div class="management-report-section">
        <h2>MANAGEMENT REPORT</h2>
        <div class="management-content">
          ${content.managementReport.business_overview ? `
            <div class="management-section">
              <h4>Business Overview</h4>
              <p>${content.managementReport.business_overview}</p>
            </div>
          ` : ''}
          ${content.managementReport.financial_performance ? `
            <div class="management-section">
              <h4>Financial Performance</h4>
              <p>${content.managementReport.financial_performance}</p>
            </div>
          ` : ''}
          ${content.managementReport.revenue_analysis ? `
            <div class="management-section">
              <h4>Revenue Analysis</h4>
              <p>${content.managementReport.revenue_analysis}</p>
            </div>
          ` : ''}
          ${content.managementReport.cost_management ? `
            <div class="management-section">
              <h4>Cost Management</h4>
              <p>${content.managementReport.cost_management}</p>
            </div>
          ` : ''}
          ${content.managementReport.profitability ? `
            <div class="management-section">
              <h4>Profitability</h4>
              <p>${content.managementReport.profitability}</p>
            </div>
          ` : ''}
          ${content.managementReport.cash_flow_performance ? `
            <div class="management-section">
              <h4>Cash Flow Performance</h4>
              <p>${content.managementReport.cash_flow_performance}</p>
            </div>
          ` : ''}
          ${content.managementReport.operating_cash_flows ? `
            <div class="management-section">
              <h4>Operating Cash Flows</h4>
              <p>${content.managementReport.operating_cash_flows}</p>
            </div>
          ` : ''}
          ${content.managementReport.investing_activities ? `
            <div class="management-section">
              <h4>Investing Activities</h4>
              <p>${content.managementReport.investing_activities}</p>
            </div>
          ` : ''}
          ${content.managementReport.financing_activities ? `
            <div class="management-section">
              <h4>Financing Activities</h4>
              <p>${content.managementReport.financing_activities}</p>
            </div>
          ` : ''}
          ${content.managementReport.key_developments ? `
            <div class="management-section">
              <h4>Key Developments</h4>
              <p>${content.managementReport.key_developments}</p>
            </div>
          ` : ''}
          ${content.managementReport.risk_management ? `
            <div class="management-section">
              <h4>Risk Management</h4>
              <p>${content.managementReport.risk_management}</p>
            </div>
          ` : ''}
          ${content.managementReport.market_position ? `
            <div class="management-section">
              <h4>Market Position</h4>
              <p>${content.managementReport.market_position}</p>
            </div>
          ` : ''}
          ${content.managementReport.future_outlook ? `
            <div class="management-section">
              <h4>Future Outlook</h4>
              <p>${content.managementReport.future_outlook}</p>
            </div>
          ` : ''}
          ${content.managementReport.future_strategy ? `
            <div class="management-section">
              <h4>Future Strategy</h4>
              <p>${content.managementReport.future_strategy}</p>
            </div>
          ` : ''}
          ${content.managementReport.liquidity_management ? `
            <div class="management-section">
              <h4>Liquidity Management</h4>
              <p>${content.managementReport.liquidity_management}</p>
            </div>
          ` : ''}
          ${content.managementReport.future_cash_flows ? `
            <div class="management-section">
              <h4>Future Cash Flows</h4>
              <p>${content.managementReport.future_cash_flows}</p>
            </div>
          ` : ''}
          ${content.managementReport.corporate_governance ? `
            <div class="management-section">
              <h4>Corporate Governance</h4>
              <p>${content.managementReport.corporate_governance}</p>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <title>${statement.statementType.replace('_', ' ').toUpperCase()}</title>
      <style>
        body { 
          font-family: "Times New Roman", serif; 
          margin: 2cm; 
          line-height: 1.4;
          color: #000;
        }
        .header { 
          text-align: center; 
          margin-bottom: 2cm; 
          border-bottom: 2px solid #000;
          padding-bottom: 1cm;
        }
        .header h1 { 
          font-size: 24px; 
          font-weight: bold; 
          margin: 0;
        }
        .header p { 
          font-size: 14px; 
          margin: 5px 0;
        }
        .statement-content h2 { 
          text-align: center; 
          font-size: 20px; 
          margin: 1cm 0 0.5cm 0;
        }
        .statement-content h3 { 
          text-align: center; 
          font-size: 16px; 
          margin: 0 0 1cm 0;
        }
        .section { 
          margin: 1cm 0; 
        }
        .section h4 { 
          font-size: 16px; 
          font-weight: bold; 
          margin: 0.5cm 0 0.3cm 0;
        }
        .subsection { 
          margin: 0.5cm 0; 
        }
        .subsection h5 { 
          font-size: 14px; 
          font-weight: bold; 
          margin: 0.3cm 0 0.2cm 0;
        }
        .table { 
          width: 100%; 
          border-collapse: collapse; 
          margin: 0.5cm 0; 
        }
        .table td { 
          padding: 5px 10px; 
          border-bottom: 1px solid #ddd; 
        }
        .table .amount { 
          text-align: right; 
          font-family: monospace;
        }
        .table .total td { 
          border-top: 1px solid #000; 
          font-weight: bold; 
        }
        .table .grand-total-row td { 
          border-top: 2px solid #000; 
          border-bottom: 2px solid #000; 
          font-weight: bold; 
          font-size: 16px;
        }
        .grand-total { 
          margin: 1cm 0; 
        }
        .notes-section { 
          margin-top: 2cm; 
          page-break-before: always; 
        }
        .notes-section h2 { 
          text-align: center; 
          font-size: 18px; 
          margin-bottom: 1cm;
        }
        .note { 
          margin: 1cm 0; 
        }
        .note h4 { 
          font-size: 14px; 
          font-weight: bold; 
          margin-bottom: 0.5cm;
        }
        .note p { 
          font-size: 12px; 
          text-align: justify;
        }
        .auditor-report-section { 
          margin-top: 2cm; 
          page-break-before: always; 
        }
        .auditor-report-section h2 { 
          text-align: center; 
          font-size: 18px; 
          margin-bottom: 1cm;
          font-weight: bold;
        }
        .auditor-content { 
          margin: 1cm 0; 
        }
        .auditor-section { 
          margin: 1cm 0; 
        }
        .auditor-section h4 { 
          font-size: 14px; 
          font-weight: bold; 
          margin-bottom: 0.5cm;
          color: #333;
        }
        .auditor-section p { 
          font-size: 12px; 
          text-align: justify;
          line-height: 1.6;
        }
        .management-report-section { 
          margin-top: 2cm; 
          page-break-before: always; 
        }
        .management-report-section h2 { 
          text-align: center; 
          font-size: 18px; 
          margin-bottom: 1cm;
          font-weight: bold;
        }
        .management-content { 
          margin: 1cm 0; 
        }
        .management-section { 
          margin: 1cm 0; 
        }
        .management-section h4 { 
          font-size: 14px; 
          font-weight: bold; 
          margin-bottom: 0.5cm;
          color: #333;
        }
        .management-section p { 
          font-size: 12px; 
          text-align: justify;
          line-height: 1.6;
        }
        .footer { 
          margin-top: 2cm; 
          text-align: center; 
          font-size: 10px; 
          color: #666; 
          border-top: 1px solid #ddd; 
          padding-top: 1cm;
        }
        @media print {
          body { margin: 1cm; }
          .header, .section { page-break-inside: avoid; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>${metadata.clientName || 'Company Name'}</h1>
        <p>${statement.statementType.replace('_', ' ').toUpperCase()}</p>
        <p>Reporting Standard: ${metadata.regime || 'IFRS'}</p>
        <p>Currency: ${metadata.currency || 'AED'}</p>
      </div>
      
      ${bodyContent}
      
      ${notesSection}
      
      ${auditorReportSection}
      
      ${managementReportSection}
      
      <div class="footer">
        <p>The accompanying notes form an integral part of these financial statements</p>
        <p>Generated by FinAudit Pro - Professional Financial Reporting Suite</p>
        <p>Generated on: ${new Date().toLocaleDateString()}</p>
      </div>
    </body>
    </html>
  `;
}

function generateReportHTML(report: any): string {
  const content = report.content || {};
  
  let reportBody = '';
  
  // Handle different report types
  if (report.reportType === 'financial_statement' && content.balanceSheet && content.incomeStatement) {
    reportBody = `
      <div class="report-section">
        <h2>BALANCE SHEET</h2>
        ${generateFinancialStatementHTML(content.balanceSheet)}
      </div>
      <div class="report-section" style="page-break-before: always;">
        <h2>INCOME STATEMENT</h2>
        ${generateFinancialStatementHTML(content.incomeStatement)}
      </div>
    `;
  } else if (report.reportType === 'auditor_report') {
    reportBody = `
      <div class="report-section">
        <h2>INDEPENDENT AUDITOR'S REPORT</h2>
        <div class="auditor-content">
          <div class="auditor-section">
            <h4>Scope of Audit</h4>
            <p>We have audited the accompanying financial statements of ${report.clientName || 'the Company'}, which comprise the balance sheet as at ${content.metadata?.period || 'period end'} and the income statement for the year then ended, and notes to the financial statements.</p>
          </div>
          <div class="auditor-section">
            <h4>Management's Responsibility</h4>
            <p>Management is responsible for the preparation and fair presentation of these financial statements in accordance with ${report.standard || 'applicable financial reporting standards'}.</p>
          </div>
          <div class="auditor-section">
            <h4>Auditor's Responsibility</h4>
            <p>Our responsibility is to express an opinion on these financial statements based on our audit. We conducted our audit in accordance with UAE auditing standards.</p>
          </div>
          <div class="auditor-section">
            <h4>Opinion</h4>
            <p>In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as at ${content.metadata?.period || 'period end'} and its financial performance for the year then ended in accordance with ${report.standard || 'applicable standards'}.</p>
          </div>
        </div>
      </div>
    `;
  } else if (report.reportType === 'management_report') {
    reportBody = `
      <div class="report-section">
        <h2>MANAGEMENT REPORT</h2>
        <div class="management-content">
          <div class="management-section">
            <h4>Executive Summary</h4>
            <p>This management report provides an overview of the company's financial performance and strategic position for the period ended ${content.metadata?.period || 'period end'}.</p>
          </div>
          <div class="management-section">
            <h4>Financial Performance</h4>
            <p>The company demonstrated strong financial performance during the reporting period, with key metrics aligned with strategic objectives.</p>
          </div>
          <div class="management-section">
            <h4>Risk Management</h4>
            <p>The company maintains a comprehensive risk management framework to identify, assess, and mitigate potential risks that could impact operations.</p>
          </div>
          <div class="management-section">
            <h4>Future Outlook</h4>
            <p>Looking ahead, the company is well-positioned to capitalize on emerging opportunities while maintaining operational excellence.</p>
          </div>
        </div>
      </div>
    `;
  } else {
    reportBody = `
      <div class="report-section">
        <h2>${report.title || 'REPORT'}</h2>
        <div class="content">
          <p>Report content will be displayed here based on the selected template and data.</p>
          <p><strong>Report Type:</strong> ${report.reportType}</p>
          <p><strong>Standard:</strong> ${report.standard}</p>
          <p><strong>Format:</strong> ${report.format}</p>
        </div>
      </div>
    `;
  }

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <title>${report.title}</title>
      <style>
        body { font-family: "Times New Roman", serif; margin: 2cm; line-height: 1.4; }
        .header { text-align: center; margin-bottom: 2cm; border-bottom: 2px solid #000; padding-bottom: 1cm; }
        .header h1 { font-size: 24px; margin: 0; }
        .header p { font-size: 14px; margin: 5px 0; }
        .report-section { margin: 2cm 0; }
        .report-section h2 { text-align: center; font-size: 20px; margin: 1cm 0; }
        .content { line-height: 1.6; }
        .table { width: 100%; border-collapse: collapse; margin: 1cm 0; }
        .table th, .table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .table th { background-color: #f2f2f2; }
        .table .amount { text-align: right; font-family: monospace; }
        .auditor-content, .management-content { margin: 1cm 0; }
        .auditor-section, .management-section { margin: 1cm 0; }
        .auditor-section h4, .management-section h4 { font-size: 14px; font-weight: bold; margin-bottom: 0.5cm; }
        .auditor-section p, .management-section p { font-size: 12px; text-align: justify; line-height: 1.6; }
        .footer { margin-top: 2cm; text-align: center; font-size: 12px; color: #666; border-top: 1px solid #ddd; padding-top: 1cm; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>${report.title}</h1>
        <p>Report Type: ${report.reportType.replace('_', ' ').toUpperCase()}</p>
        <p>Generated: ${new Date(report.generatedAt).toLocaleDateString()}</p>
      </div>
      
      ${reportBody}
      
      <div class="footer">
        <p>Generated by FinAudit Pro - Professional Financial Reporting Suite</p>
      </div>
    </body>
    </html>
  `;
}
