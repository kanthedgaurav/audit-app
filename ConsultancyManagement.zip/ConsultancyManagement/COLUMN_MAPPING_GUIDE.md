# FinAudit Pro - Excel Column Mapping Guide

## Required Column Names for Each File Type

### 1. Chart of Accounts
**Required columns (exact names):**
- `Account Code` or `AccountCode`
- `Account Name` or `AccountName`
- `Account Type` or `AccountType`
- `Category`
- `Sub Category` or `SubCategory`
- `Parent Account Code` or `ParentAccountCode` (optional)

### 2. Trial Balance
**Required columns (exact names):**
- `Account Code` or `AccountCode` or `Account Number` or `AccountNumber`
- `Account Name` or `AccountName`
- `Debit Amount` or `DebitAmount` or `Debit` or `Dr` or `Debits ($)` or `Debit ($)`
- `Credit Amount` or `CreditAmount` or `Credit` or `Cr` or `Credits ($)` or `Credit ($)`

### 3. General Ledger
**Required columns (exact names):**
- `Account Code` or `AccountCode` or `Account Number` or `AccountNumber`
- `Transaction Date` or `TransactionDate` or `Date`
- `Description` or `Narration` or `Particulars`
- `Reference` or `Ref` or `Voucher`
- `Debit Amount` or `DebitAmount` or `Debit` or `Dr` or `Debits ($)` or `Debit ($)`
- `Credit Amount` or `CreditAmount` or `Credit` or `Cr` or `Credits ($)` or `Credit ($)`

## RECOMMENDED STANDARD COLUMN NAMES

**Use these exact column names in your Excel files to avoid any mapping issues:**

### Chart of Accounts Excel Template:
```
Account Code | Account Name | Account Type | Category | Sub Category | Parent Account Code
```

### Trial Balance Excel Template:
```
Account Code | Account Name | Debit Amount | Credit Amount
```

### General Ledger Excel Template:
```
Account Code | Transaction Date | Description | Reference | Debit Amount | Credit Amount
```

## SIMPLE COPY-PASTE HEADERS

**Chart of Accounts:**
```
Account Code    Account Name    Account Type    Category        Sub Category    Parent Account Code
```

**Trial Balance:**
```
Account Code    Account Name    Debit Amount    Credit Amount
```

**General Ledger:**
```
Account Code    Transaction Date        Description     Reference       Debit Amount    Credit Amount
```

## Important Notes

1. **Date Format**: Excel dates are automatically converted (serial dates like 45658 work fine)
2. **Amount Format**: Numbers can be with or without currency symbols ($)
3. **Case Sensitivity**: Column names are case-insensitive
4. **Spaces**: Spaces in column names are handled automatically
5. **Alternative Names**: The system recognizes multiple variations of each column name

## Current Working Examples

Your files are working with these column structures:

**Chart of Accounts**: ✅ Working
**Trial Balance**: ✅ Working  
**General Ledger**: ✅ Working with columns:
- `AccountNumber`
- `Date`
- `Description`
- `Ref`
- `Debit ($)`
- `Credit ($)` (if available)
