# FinAudit Pro - Integrated Financial Management Suite

## Overview
FinAudit Pro is a comprehensive financial management and audit platform for consultancy firms, CA firms, ACCA practitioners, chartered accountants, internal auditors, and corporate finance teams in the UAE. It provides an integrated solution for financial data management, automated statement generation, internal audit execution, and compliance reporting, aiming to be a key tool for financial professionals.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture
FinAudit Pro employs a modern, full-stack architecture. The **frontend** is built with React 18, TypeScript, Wouter for routing, TanStack Query for state management, and Radix UI with shadcn/ui for components, styled using Tailwind CSS. Vite ensures fast development. The **backend** uses Node.js with Express.js and TypeScript, connected to a PostgreSQL database via Drizzle ORM. Multer handles file uploads, and session management is built-in. Data is primarily stored in PostgreSQL (configured for Neon serverless), with local filesystem storage for files. Drizzle Kit manages schema migrations.

Key architectural components include:
- **Core Modules**: Multi-tenant client management, AI-powered financial statement generation (Balance Sheet, P&L, Cash Flow), risk-based internal audit, ICOFR implementation, compliance tracking, and version-controlled document management.
- **Database Schema**: Comprehensive schema supporting multi-role users, firms, clients, financial periods, IFRS-compliant Chart of Accounts, Trial Balance, Audit Engagements, Documents, Compliance Items, and Activity Logs.
- **UI/UX Decisions**: Emphasizes accessibility with Radix UI, a consistent design system with light/dark modes, fixed sidebar navigation, responsive layouts, and intuitive forms with Zod validation. It features a complete mobile-first responsive design across all pages, including collapsible sidebars, optimized components for smaller screens, and adaptive text labels, ensuring professional presentation across all devices.
- **Technical Implementations**: Includes automated fiscal period generation, a comprehensive enhanced audit system with financial data integration, IFRS Chart of Accounts validation, and advanced Excel processing for trial balance uploads with auto-account creation and flexible header detection. Financial statement generation supports both direct and indirect cash flow methods and includes comprehensive notes, auditor reports, and management reports, with professional export options (MS Word, Excel, PDF, HTML) and UAE-specific compliance checks.
- **Deployment Strategy**: Utilizes Vite for frontend builds and esbuild for backend. Development uses a local Vite server with Neon serverless PostgreSQL, while production deploys optimized assets and bundles, applying Drizzle migrations. File storage defaults to secure local filesystem storage, with future potential for Replit Object Storage integration.

## External Dependencies
- **Database Connectivity**: `@neondatabase/serverless`, `drizzle-orm`
- **Frontend State & Routing**: `@tanstack/react-query`, `wouter`
- **File Handling**: `multer`
- **UI Libraries & Styling**: `@radix-ui/*`, `tailwindcss`, `lucide-react`, `class-variance-authority`, `cmdk`
- **Utilities**: `date-fns`
- **Development Tools**: `vite`, `tsx`, `esbuild`, `@replit/vite-plugin-*`