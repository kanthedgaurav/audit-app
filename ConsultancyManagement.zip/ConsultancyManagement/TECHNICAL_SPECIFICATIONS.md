# FinAudit Pro - Technical Specifications

## Database Schema Design

### Core Tables

#### 1. Users Table
```sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL, -- 'admin', 'manager', 'staff', 'client'
    firm_id INTEGER REFERENCES firms(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

#### 2. Firms Table
```sql
CREATE TABLE firms (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    license_number VARCHAR(100),
    address TEXT,
    contact_email VARCHAR(255),
    phone VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW()
);
```

#### 3. Clients Table
```sql
CREATE TABLE clients (
    id SERIAL PRIMARY KEY,
    firm_id INTEGER REFERENCES firms(id),
    name VARCHAR(255) NOT NULL,
    industry VARCHAR(100),
    reporting_standard VARCHAR(50), -- 'UAE', 'IFRS', 'Indian'
    audit_standard VARCHAR(50),
    compliance_framework VARCHAR(100),
    preferred_format VARCHAR(50), -- 'vertical', 'horizontal', 'schedule_iii'
    fiscal_year_end DATE,
    created_at TIMESTAMP DEFAULT NOW()
);
```

#### 4. Financial Periods Table
```sql
CREATE TABLE financial_periods (
    id SERIAL PRIMARY KEY,
    client_id INTEGER REFERENCES clients(id),
    name VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT NOW()
);
```

#### 5. Chart of Accounts Table
```sql
CREATE TABLE chart_of_accounts (
    id SERIAL PRIMARY KEY,
    client_id INTEGER REFERENCES clients(id),
    account_code VARCHAR(20) NOT NULL,
    account_name VARCHAR(255) NOT NULL,
    account_type VARCHAR(50) NOT NULL, -- 'Asset', 'Liability', 'Equity', 'Revenue', 'Expense'
    category VARCHAR(100),
    sub_category VARCHAR(100),
    parent_account_code VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);
```

#### 6. Trial Balance Entries Table
```sql
CREATE TABLE trial_balance_entries (
    id SERIAL PRIMARY KEY,
    client_id INTEGER REFERENCES clients(id),
    period_id INTEGER REFERENCES financial_periods(id),
    account_id INTEGER REFERENCES chart_of_accounts(id),
    debit_amount DECIMAL(15,2) DEFAULT 0,
    credit_amount DECIMAL(15,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);
```

#### 7. Financial Statements Table
```sql
CREATE TABLE financial_statements (
    id SERIAL PRIMARY KEY,
    client_id INTEGER REFERENCES clients(id),
    period_id INTEGER REFERENCES financial_periods(id),
    statement_type VARCHAR(50) NOT NULL, -- 'balance_sheet', 'income_statement', 'cash_flow'
    format VARCHAR(50) NOT NULL,
    content JSONB NOT NULL,
    status VARCHAR(50) DEFAULT 'completed',
    generated_at TIMESTAMP DEFAULT NOW(),
    generated_by INTEGER REFERENCES users(id)
);
```

## API Endpoints Specification

### 1. Client Management APIs

#### GET /api/clients/:firmId
**Purpose**: Retrieve all clients for a firm
**Response**:
```json
{
  "clients": [
    {
      "id": 1,
      "name": "ABC Trading LLC",
      "industry": "Trading",
      "reporting_standard": "UAE",
      "fiscal_year_end": "2024-12-31"
    }
  ]
}
```

#### POST /api/clients
**Purpose**: Create new client
**Request**:
```json
{
  "firm_id": 1,
  "name": "XYZ Company",
  "industry": "Manufacturing",
  "reporting_standard": "IFRS",
  "fiscal_year_end": "2024-12-31"
}
```

### 2. Data Upload APIs

#### POST /api/upload/trial-balance
**Purpose**: Upload trial balance data
**Request**: Multipart form with Excel/CSV file
**Response**:
```json
{
  "success": true,
  "processed_rows": 25,
  "errors": [],
  "validation": {
    "total_debits": 125000,
    "total_credits": 125000,
    "balanced": true
  }
}
```

#### POST /api/upload/chart-of-accounts
**Purpose**: Upload chart of accounts
**Request**: Multipart form with Excel/CSV file
**Response**:
```json
{
  "success": true,
  "processed_rows": 50,
  "errors": [],
  "message": "Chart of accounts uploaded successfully"
}
```

### 3. Financial Statement APIs

#### POST /api/generate-statement
**Purpose**: Generate financial statement
**Request**:
```json
{
  "client_id": 1,
  "period_id": 1,
  "statement_type": "balance_sheet",
  "format": "vertical",
  "cash_flow_method": "indirect" // only for cash flow statements
}
```

**Response**:
```json
{
  "id": 123,
  "statement_type": "balance_sheet",
  "content": {
    "metadata": {
      "client_name": "ABC Trading LLC",
      "period": "Year ended 2024-12-31",
      "currency": "AED",
      "format": "vertical"
    },
    "sections": {
      "assets": {
        "current_assets": {
          "cash": 49800,
          "accounts_receivable": 8000,
          "inventory": 2500,
          "total": 60300
        },
        "non_current_assets": {
          "equipment": 8000,
          "total": 8000
        },
        "total_assets": 68300
      },
      "liabilities": {
        "current_liabilities": {
          "accounts_payable": 3000,
          "unearned_revenue": 1000,
          "total": 4000
        },
        "total_liabilities": 4000
      },
      "equity": {
        "common_stock": 50000,
        "retained_earnings": 9300,
        "total_equity": 59300
      }
    },
    "validation": {
      "balanced": true,
      "total_assets": 68300,
      "total_liabilities_equity": 63300
    }
  },
  "status": "completed"
}
```

## File Processing Logic

### 1. Trial Balance Processing

#### File Detection Algorithm
```javascript
function detectFileType(filePath) {
  const headers = readFileHeaders(filePath);
  
  // Check for trial balance headers
  if (headers.includes('Account Code') && 
      headers.includes('Account Name') && 
      (headers.includes('Debit Amount') || headers.includes('Credit Amount'))) {
    return 'trial_balance';
  }
  
  // Check for chart of accounts headers
  if (headers.includes('Account Code') && 
      headers.includes('Account Name') && 
      headers.includes('Account Type')) {
    return 'chart_of_accounts';
  }
  
  return 'unknown';
}
```

#### Data Validation Process
```javascript
function validateTrialBalance(data) {
  const errors = [];
  let totalDebits = 0;
  let totalCredits = 0;
  
  for (const row of data) {
    // Validate account code exists
    if (!accountExists(row.accountCode)) {
      errors.push(`Account code ${row.accountCode} not found in chart of accounts`);
    }
    
    // Validate amounts
    if (row.debitAmount && row.creditAmount) {
      errors.push(`Row ${row.index}: Cannot have both debit and credit amounts`);
    }
    
    totalDebits += parseFloat(row.debitAmount || 0);
    totalCredits += parseFloat(row.creditAmount || 0);
  }
  
  // Check if balanced
  if (Math.abs(totalDebits - totalCredits) > 0.01) {
    errors.push(`Trial balance not balanced: Debits ${totalDebits}, Credits ${totalCredits}`);
  }
  
  return {
    valid: errors.length === 0,
    errors: errors,
    totals: { debits: totalDebits, credits: totalCredits }
  };
}
```

### 2. Financial Statement Generation

#### Balance Sheet Generation Logic
```javascript
function generateBalanceSheet(trialBalance, chartOfAccounts) {
  const balanceMap = createBalanceMap(trialBalance);
  
  // Assets calculation
  const assets = {
    current: {
      cash: getAccountBalance('100', balanceMap),
      accounts_receivable: getAccountBalance('105', balanceMap),
      inventory: getAccountBalance('110', balanceMap)
    },
    non_current: {
      equipment: getAccountBalance('150', balanceMap)
    }
  };
  
  // Liabilities calculation  
  const liabilities = {
    current: {
      accounts_payable: getAccountBalance('200', balanceMap),
      unearned_revenue: getAccountBalance('205', balanceMap)
    }
  };
  
  // Equity calculation
  const equity = {
    common_stock: getAccountBalance('300', balanceMap),
    retained_earnings: calculateNetIncome(balanceMap)
  };
  
  // Validation
  const totalAssets = sumObject(assets);
  const totalLiabilitiesEquity = sumObject(liabilities) + sumObject(equity);
  
  return {
    sections: { assets, liabilities, equity },
    validation: {
      balanced: Math.abs(totalAssets - totalLiabilitiesEquity) < 0.01,
      total_assets: totalAssets,
      total_liabilities_equity: totalLiabilitiesEquity
    }
  };
}
```

#### Income Statement Generation Logic
```javascript
function generateIncomeStatement(trialBalance, chartOfAccounts) {
  const balanceMap = createBalanceMap(trialBalance);
  
  // Revenue calculation
  const revenue = {
    sales_revenue: getAccountBalance('400', balanceMap),
    service_revenue: getAccountBalance('405', balanceMap)
  };
  
  // Expenses calculation
  const expenses = {
    cost_of_goods_sold: Math.abs(getAccountBalance('500', balanceMap)),
    rent_expense: Math.abs(getAccountBalance('505', balanceMap)),
    salaries_expense: Math.abs(getAccountBalance('510', balanceMap)),
    utilities_expense: Math.abs(getAccountBalance('515', balanceMap))
  };
  
  const totalRevenue = sumObject(revenue);
  const totalExpenses = sumObject(expenses);
  const netIncome = totalRevenue - totalExpenses;
  
  return {
    sections: {
      revenue: { ...revenue, total: totalRevenue },
      expenses: { ...expenses, total: totalExpenses },
      net_income: netIncome
    },
    ratios: {
      gross_profit_margin: ((totalRevenue - expenses.cost_of_goods_sold) / totalRevenue) * 100,
      net_profit_margin: (netIncome / totalRevenue) * 100
    }
  };
}
```

#### Cash Flow Statement Generation Logic
```javascript
function generateCashFlowStatement(trialBalance, chartOfAccounts, method = 'indirect') {
  const balanceMap = createBalanceMap(trialBalance);
  const netIncome = calculateNetIncome(balanceMap);
  
  if (method === 'direct') {
    return generateDirectCashFlow(balanceMap);
  } else {
    return generateIndirectCashFlow(balanceMap, netIncome);
  }
}

function generateIndirectCashFlow(balanceMap, netIncome) {
  const operating = {
    net_income: netIncome,
    working_capital_changes: {
      accounts_receivable: -getAccountBalance('105', balanceMap),
      inventory: -getAccountBalance('110', balanceMap),
      accounts_payable: getAccountBalance('200', balanceMap),
      unearned_revenue: getAccountBalance('205', balanceMap)
    }
  };
  
  const investing = {
    equipment_purchases: -Math.abs(getAccountBalance('150', balanceMap)) * 0.1
  };
  
  const financing = {
    equity_issuance: Math.abs(getAccountBalance('300', balanceMap)) * 0.1
  };
  
  return {
    sections: { operating, investing, financing },
    net_cash_flow: sumCashFlows(operating, investing, financing)
  };
}
```

## Data Transformation Pipeline

### 1. File Upload Pipeline
```
File Upload → File Validation → Data Parsing → Schema Validation → Database Storage
```

### 2. Statement Generation Pipeline
```
Database Query → Data Aggregation → Business Logic → Formatting → Export Generation
```

### 3. Export Pipeline
```
Statement Data → Template Selection → Format Conversion → File Generation → Download
```

## Security Implementation

### 1. Authentication
- JWT tokens for API authentication
- Role-based access control (RBAC)
- Session management with secure cookies

### 2. Data Protection
- Encryption at rest for sensitive data
- HTTPS for all communications
- Input validation and sanitization

### 3. Audit Trail
- All database changes logged
- User actions tracked
- File access monitored

## Performance Optimizations

### 1. Database Optimizations
- Indexes on frequently queried columns
- Connection pooling
- Query optimization

### 2. File Processing
- Streaming file processing for large files
- Background job processing
- Progress tracking

### 3. Caching
- Redis caching for frequently accessed data
- Memoization of calculation results
- CDN for static assets

## Error Handling

### 1. Validation Errors
```javascript
class ValidationError extends Error {
  constructor(message, field, code) {
    super(message);
    this.name = 'ValidationError';
    this.field = field;
    this.code = code;
  }
}
```

### 2. Processing Errors
```javascript
class ProcessingError extends Error {
  constructor(message, step, context) {
    super(message);
    this.name = 'ProcessingError';
    this.step = step;
    this.context = context;
  }
}
```

### 3. Error Response Format
```json
{
  "error": true,
  "message": "Validation failed",
  "details": [
    {
      "field": "account_code",
      "message": "Account code 999 not found",
      "code": "ACCOUNT_NOT_FOUND"
    }
  ],
  "timestamp": "2024-07-14T18:30:00Z"
}
```

## Testing Strategy

### 1. Unit Tests
- Business logic functions
- Data validation rules
- Calculation algorithms

### 2. Integration Tests
- API endpoints
- Database operations
- File processing workflows

### 3. End-to-End Tests
- Complete user workflows
- Statement generation processes
- Export functionality

## Deployment Architecture

### 1. Application Layers
```
Frontend (React) → API Gateway → Backend Services → Database
```

### 2. Infrastructure
- Docker containers for microservices
- Load balancers for scaling
- Database clustering for high availability

### 3. Monitoring
- Application performance monitoring
- Error tracking and alerting
- Business metrics dashboards

This technical specification provides the implementation details needed for development teams to understand and maintain the FinAudit Pro system.