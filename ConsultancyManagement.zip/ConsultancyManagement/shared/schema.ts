import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb, uuid, varchar, date } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for multi-tenant access
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  profileImageUrl: varchar("profile_image_url", { length: 500 }),
  role: varchar("role", { length: 50 }).notNull().default("staff"), // admin, manager, staff, client
  firmId: integer("firm_id").references(() => firms.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Consultancy firms table
export const firms = pgTable("firms", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  licenseNumber: varchar("license_number", { length: 100 }),
  address: text("address"),
  contactEmail: varchar("contact_email", { length: 255 }),
  contactPhone: varchar("contact_phone", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Clients table
export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  industry: varchar("industry", { length: 100 }),
  registrationNumber: varchar("registration_number", { length: 100 }),
  jurisdiction: varchar("jurisdiction", { length: 100 }).default("UAE"),
  reportingRegime: varchar("reporting_regime", { length: 50 }).default("IFRS"), // IFRS, UAE, India
  auditingStandards: varchar("auditing_standards", { length: 100 }).default("ISA"), // ISA, UAE, India
  reportingRegion: varchar("reporting_region", { length: 50 }).default("UAE"), // UAE, India, International
  complianceFramework: varchar("compliance_framework", { length: 100 }).default("UAE_IFRS"),
  preferredReportFormat: varchar("preferred_report_format", { length: 50 }).default("vertical"),
  fiscalYearEnd: date("fiscal_year_end"),
  address: text("address"),
  contactPerson: varchar("contact_person", { length: 255 }),
  contactEmail: varchar("contact_email", { length: 255 }),
  contactPhone: varchar("contact_phone", { length: 50 }),
  status: varchar("status", { length: 50 }).default("active"), // active, inactive, pending
  firmId: integer("firm_id").references(() => firms.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Financial periods
export const financialPeriods = pgTable("financial_periods", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  description: varchar("description", { length: 255 }),
  status: varchar("status", { length: 50 }).default("active"), // active, closed
  createdAt: timestamp("created_at").defaultNow(),
});

// Chart of accounts
export const chartOfAccounts = pgTable("chart_of_accounts", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  accountCode: varchar("account_code", { length: 50 }).notNull(),
  accountName: varchar("account_name", { length: 255 }).notNull(),
  accountType: varchar("account_type", { length: 50 }).notNull(), // Assets, Liabilities, Equity, Revenue, Expenses
  parentAccountId: integer("parent_account_id"),
  ifrsMapping: varchar("ifrs_mapping", { length: 100 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Trial balance entries
export const trialBalanceEntries = pgTable("trial_balance_entries", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  periodId: integer("period_id").references(() => financialPeriods.id).notNull(),
  accountId: integer("account_id").references(() => chartOfAccounts.id).notNull(),
  debitAmount: decimal("debit_amount", { precision: 15, scale: 2 }).default("0.00"),
  creditAmount: decimal("credit_amount", { precision: 15, scale: 2 }).default("0.00"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  uploadedBy: integer("uploaded_by").references(() => users.id),
});

// General ledger entries
export const generalLedgerEntries = pgTable("general_ledger_entries", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  periodId: integer("period_id").references(() => financialPeriods.id).notNull(),
  accountId: integer("account_id").references(() => chartOfAccounts.id).notNull(),
  transactionDate: date("transaction_date").notNull(),
  description: text("description").notNull(),
  reference: varchar("reference", { length: 100 }), // Document reference or voucher number
  debitAmount: decimal("debit_amount", { precision: 15, scale: 2 }).default("0.00"),
  creditAmount: decimal("credit_amount", { precision: 15, scale: 2 }).default("0.00"),
  runningBalance: decimal("running_balance", { precision: 15, scale: 2 }).default("0.00"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  uploadedBy: integer("uploaded_by").references(() => users.id),
});

// Financial statements
export const financialStatements = pgTable("financial_statements", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  periodId: integer("period_id").references(() => financialPeriods.id).notNull(),
  statementType: varchar("statement_type", { length: 50 }).notNull(), // balance_sheet, income_statement, cash_flow
  format: varchar("format", { length: 50 }).notNull(), // vertical, horizontal, schedule_iii, uae_standard, ifrs_standard, custom
  content: jsonb("content"),
  status: varchar("status", { length: 50 }).default("draft"), // draft, final, approved
  generatedAt: timestamp("generated_at").defaultNow(),
  generatedBy: integer("generated_by").references(() => users.id),
});

// Audit engagements
export const auditEngagements = pgTable("audit_engagements", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  engagementType: varchar("engagement_type", { length: 50 }).notNull(), // internal_audit, external_audit, icofr
  startDate: date("start_date"),
  endDate: date("end_date"),
  status: varchar("status", { length: 50 }).default("planned"), // planned, in_progress, completed, cancelled
  leadAuditor: integer("lead_auditor").references(() => users.id),
  seniorManager: varchar("senior_manager", { length: 255 }), // Name of senior manager
  teamMembers: jsonb("team_members"), // Array of team member objects with name, role, responsibilities
  riskLevel: varchar("risk_level", { length: 50 }).default("medium"), // low, medium, high
  scope: text("scope"),
  objectives: text("objectives"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Audit findings
export const auditFindings = pgTable("audit_findings", {
  id: serial("id").primaryKey(),
  engagementId: integer("engagement_id").references(() => auditEngagements.id).notNull(),
  finding: text("finding").notNull(),
  riskLevel: varchar("risk_level", { length: 50 }).default("medium"),
  recommendation: text("recommendation"),
  managementResponse: text("management_response"),
  status: varchar("status", { length: 50 }).default("open"), // open, in_progress, closed
  dueDate: date("due_date"),
  auditArea: varchar("audit_area", { length: 100 }), // financial_reporting, it_controls, operational, compliance
  accountCode: varchar("account_code", { length: 50 }), // Related account code from chart of accounts
  amountInvolved: decimal("amount_involved", { precision: 15, scale: 2 }), // Financial amount if applicable
  evidenceReference: text("evidence_reference"), // Reference to supporting documents/evidence
  testingProcedure: text("testing_procedure"), // Audit procedure used to identify the finding
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Audit procedures and testing
export const auditProcedures = pgTable("audit_procedures", {
  id: serial("id").primaryKey(),
  engagementId: integer("engagement_id").references(() => auditEngagements.id).notNull(),
  procedureType: varchar("procedure_type", { length: 100 }).notNull(), // substantive, control_testing, analytical_review
  auditArea: varchar("audit_area", { length: 100 }).notNull(), // cash, receivables, inventory, revenue, expenses
  accountCode: varchar("account_code", { length: 50 }), // Related account from chart of accounts
  description: text("description").notNull(),
  expectedResult: text("expected_result"),
  actualResult: text("actual_result"),
  conclusion: text("conclusion"),
  status: varchar("status", { length: 50 }).default("not_started"), // not_started, in_progress, completed, review_required
  samplingMethod: varchar("sampling_method", { length: 50 }), // judgmental, statistical, monetary_unit
  sampleSize: integer("sample_size"),
  populationSize: integer("population_size"),
  materiality: decimal("materiality", { precision: 15, scale: 2 }),
  performedBy: integer("performed_by").references(() => users.id),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  completedDate: date("completed_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ICOFR assessments
export const icofrAssessments = pgTable("icofr_assessments", {
  id: serial("id").primaryKey(),
  engagementId: integer("engagement_id").references(() => auditEngagements.id).notNull(),
  controlActivity: varchar("control_activity", { length: 255 }).notNull(),
  controlObjective: text("control_objective").notNull(),
  controlType: varchar("control_type", { length: 50 }).notNull(), // preventive, detective, corrective
  frequency: varchar("frequency", { length: 50 }).notNull(), // daily, weekly, monthly, quarterly, annually
  automationLevel: varchar("automation_level", { length: 50 }).notNull(), // manual, automated, hybrid
  accountCode: varchar("account_code", { length: 50 }), // Related account from chart of accounts
  processArea: varchar("process_area", { length: 100 }).notNull(), // revenue, procurement, payroll, financial_close
  riskRating: varchar("risk_rating", { length: 50 }).default("medium"), // low, medium, high, critical
  designEffectiveness: varchar("design_effectiveness", { length: 50 }), // effective, ineffective, not_evaluated
  operatingEffectiveness: varchar("operating_effectiveness", { length: 50 }), // effective, ineffective, not_evaluated
  testingApproach: text("testing_approach"),
  testingResults: text("testing_results"),
  deficiencies: text("deficiencies"),
  managementActions: text("management_actions"),
  status: varchar("status", { length: 50 }).default("not_tested"), // not_tested, testing, completed, remediation_required
  lastTestDate: date("last_test_date"),
  nextTestDate: date("next_test_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Document management
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  fileName: varchar("file_name", { length: 255 }).notNull(),
  fileType: varchar("file_type", { length: 100 }),
  fileSize: integer("file_size"),
  filePath: varchar("file_path", { length: 500 }),
  category: varchar("category", { length: 100 }), // trial_balance, general_ledger, supporting_docs
  uploadedBy: integer("uploaded_by").references(() => users.id),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  isActive: boolean("is_active").default(true),
});

// Compliance tracking
export const complianceItems = pgTable("compliance_items", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  dueDate: date("due_date"),
  status: varchar("status", { length: 50 }).default("pending"), // pending, in_progress, completed, overdue
  assignedTo: integer("assigned_to").references(() => users.id),
  priority: varchar("priority", { length: 50 }).default("medium"), // low, medium, high
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Activity log
export const activityLog = pgTable("activity_log", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  clientId: integer("client_id").references(() => clients.id),
  action: varchar("action", { length: 100 }).notNull(),
  description: text("description"),
  entityType: varchar("entity_type", { length: 50 }),
  entityId: integer("entity_id"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Report templates for different standards and formats
export const reportTemplates = pgTable("report_templates", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  reportType: varchar("report_type", { length: 50 }).notNull(), // financial_statement, auditor_report, management_report, notes_to_accounts
  standard: varchar("standard", { length: 100 }).notNull(), // UAE_IFRS, INDIAN_GAAP, IFRS_INTERNATIONAL, UAE_AUDITING
  region: varchar("region", { length: 50 }).notNull(), // UAE, India, International
  format: varchar("format", { length: 50 }).notNull(), // vertical, horizontal, schedule_iii, custom
  templateContent: jsonb("template_content"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Generated reports with different export formats
export const generatedReports = pgTable("generated_reports", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  templateId: integer("template_id").references(() => reportTemplates.id).notNull(),
  reportType: varchar("report_type", { length: 50 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: jsonb("content"),
  exportFormat: varchar("export_format", { length: 20 }).notNull(), // word, excel, pdf, html
  filePath: varchar("file_path", { length: 500 }),
  status: varchar("status", { length: 50 }).default("draft"), // draft, final, approved
  generatedAt: timestamp("generated_at").defaultNow(),
  generatedBy: integer("generated_by").references(() => users.id),
});

// Validation results for IFRS compliance and other validations
export const validationResults = pgTable("validation_results", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  validationType: varchar("validation_type", { length: 50 }).default("ifrs_coa"), // ifrs_coa, trial_balance, etc.
  totalAccounts: integer("total_accounts"),
  passedChecks: integer("passed_checks"),
  warningChecks: integer("warning_checks"),
  errorChecks: integer("error_checks"),
  overallStatus: varchar("overall_status", { length: 20 }), // passed, warning, failed
  ifrsCompliance: varchar("ifrs_compliance", { length: 20 }), // Compliant, Non-Compliant
  detailedResults: jsonb("detailed_results"), // Array of validation check results
  recommendations: jsonb("recommendations"), // Array of recommendations
  validatedBy: integer("validated_by").references(() => users.id),
  validatedAt: timestamp("validated_at").defaultNow(),
  resolved: boolean("resolved").default(false),
  resolvedAt: timestamp("resolved_at"),
  resolvedBy: integer("resolved_by").references(() => users.id),
});

// Relations
export const firmsRelations = relations(firms, ({ many }) => ({
  users: many(users),
  clients: many(clients),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  firm: one(firms, { fields: [users.firmId], references: [firms.id] }),
  auditEngagements: many(auditEngagements),
  documents: many(documents),
  complianceItems: many(complianceItems),
  activityLog: many(activityLog),
}));

export const clientsRelations = relations(clients, ({ one, many }) => ({
  firm: one(firms, { fields: [clients.firmId], references: [firms.id] }),
  financialPeriods: many(financialPeriods),
  chartOfAccounts: many(chartOfAccounts),
  trialBalanceEntries: many(trialBalanceEntries),
  generalLedgerEntries: many(generalLedgerEntries),
  financialStatements: many(financialStatements),
  auditEngagements: many(auditEngagements),
  documents: many(documents),
  complianceItems: many(complianceItems),
  activityLog: many(activityLog),
  validationResults: many(validationResults),
}));

export const financialPeriodsRelations = relations(financialPeriods, ({ one, many }) => ({
  client: one(clients, { fields: [financialPeriods.clientId], references: [clients.id] }),
  trialBalanceEntries: many(trialBalanceEntries),
  generalLedgerEntries: many(generalLedgerEntries),
  financialStatements: many(financialStatements),
}));

export const chartOfAccountsRelations = relations(chartOfAccounts, ({ one, many }) => ({
  client: one(clients, { fields: [chartOfAccounts.clientId], references: [clients.id] }),
  parentAccount: one(chartOfAccounts, { fields: [chartOfAccounts.parentAccountId], references: [chartOfAccounts.id], relationName: "parent" }),
  childAccounts: many(chartOfAccounts, { relationName: "parent" }),
  trialBalanceEntries: many(trialBalanceEntries),
  generalLedgerEntries: many(generalLedgerEntries),
}));

export const generalLedgerEntriesRelations = relations(generalLedgerEntries, ({ one }) => ({
  client: one(clients, { fields: [generalLedgerEntries.clientId], references: [clients.id] }),
  period: one(financialPeriods, { fields: [generalLedgerEntries.periodId], references: [financialPeriods.id] }),
  account: one(chartOfAccounts, { fields: [generalLedgerEntries.accountId], references: [chartOfAccounts.id] }),
  uploadedBy: one(users, { fields: [generalLedgerEntries.uploadedBy], references: [users.id] }),
}));

export const auditEngagementsRelations = relations(auditEngagements, ({ one, many }) => ({
  client: one(clients, { fields: [auditEngagements.clientId], references: [clients.id] }),
  leadAuditor: one(users, { fields: [auditEngagements.leadAuditor], references: [users.id] }),
  findings: many(auditFindings),
}));

export const auditFindingsRelations = relations(auditFindings, ({ one }) => ({
  engagement: one(auditEngagements, { fields: [auditFindings.engagementId], references: [auditEngagements.id] }),
}));

export const validationResultsRelations = relations(validationResults, ({ one }) => ({
  client: one(clients, { fields: [validationResults.clientId], references: [clients.id] }),
  validatedBy: one(users, { fields: [validationResults.validatedBy], references: [users.id] }),
  resolvedBy: one(users, { fields: [validationResults.resolvedBy], references: [users.id] }),
}));

// Insert schemas
export const insertFirmSchema = createInsertSchema(firms).omit({ id: true, createdAt: true, updatedAt: true });
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, updatedAt: true });
export const insertClientSchema = createInsertSchema(clients).omit({ id: true, createdAt: true, updatedAt: true });
export const insertFinancialPeriodSchema = createInsertSchema(financialPeriods).omit({ id: true, createdAt: true });
export const insertChartOfAccountsSchema = createInsertSchema(chartOfAccounts).omit({ id: true, createdAt: true });
export const insertTrialBalanceEntrySchema = createInsertSchema(trialBalanceEntries).omit({ id: true, uploadedAt: true });
export const insertGeneralLedgerEntrySchema = createInsertSchema(generalLedgerEntries).omit({ id: true, uploadedAt: true });
export const insertFinancialStatementSchema = createInsertSchema(financialStatements).omit({ id: true, generatedAt: true });
export const insertAuditEngagementSchema = createInsertSchema(auditEngagements).omit({ id: true, createdAt: true, updatedAt: true }).extend({
  teamMembers: z.array(z.object({
    name: z.string(),
    role: z.string(),
    responsibilities: z.string().optional(),
    email: z.string().optional()
  })).optional()
});
export const insertAuditFindingSchema = createInsertSchema(auditFindings).omit({ id: true, createdAt: true, updatedAt: true });
export const insertAuditProcedureSchema = createInsertSchema(auditProcedures).omit({ id: true, createdAt: true, updatedAt: true });
export const insertIcofrAssessmentSchema = createInsertSchema(icofrAssessments).omit({ id: true, createdAt: true, updatedAt: true });
export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true, uploadedAt: true });
export const insertComplianceItemSchema = createInsertSchema(complianceItems).omit({ id: true, createdAt: true, updatedAt: true });
export const insertActivityLogSchema = createInsertSchema(activityLog).omit({ id: true, timestamp: true });
export const insertReportTemplateSchema = createInsertSchema(reportTemplates).omit({ id: true, createdAt: true, updatedAt: true });
export const insertGeneratedReportSchema = createInsertSchema(generatedReports).omit({ id: true, generatedAt: true });
export const insertValidationResultSchema = createInsertSchema(validationResults).omit({ id: true, validatedAt: true });

// Types
export type Firm = typeof firms.$inferSelect;
export type InsertFirm = z.infer<typeof insertFirmSchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;
export type FinancialPeriod = typeof financialPeriods.$inferSelect;
export type InsertFinancialPeriod = z.infer<typeof insertFinancialPeriodSchema>;
export type ChartOfAccount = typeof chartOfAccounts.$inferSelect;
export type InsertChartOfAccount = z.infer<typeof insertChartOfAccountsSchema>;
export type TrialBalanceEntry = typeof trialBalanceEntries.$inferSelect;
export type InsertTrialBalanceEntry = z.infer<typeof insertTrialBalanceEntrySchema>;
export type GeneralLedgerEntry = typeof generalLedgerEntries.$inferSelect;
export type InsertGeneralLedgerEntry = z.infer<typeof insertGeneralLedgerEntrySchema>;
export type FinancialStatement = typeof financialStatements.$inferSelect;
export type InsertFinancialStatement = z.infer<typeof insertFinancialStatementSchema>;
export type AuditEngagement = typeof auditEngagements.$inferSelect;
export type InsertAuditEngagement = z.infer<typeof insertAuditEngagementSchema>;
export type AuditFinding = typeof auditFindings.$inferSelect;
export type InsertAuditFinding = z.infer<typeof insertAuditFindingSchema>;
export type AuditProcedure = typeof auditProcedures.$inferSelect;
export type InsertAuditProcedure = z.infer<typeof insertAuditProcedureSchema>;
export type IcofrAssessment = typeof icofrAssessments.$inferSelect;
export type InsertIcofrAssessment = z.infer<typeof insertIcofrAssessmentSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type ComplianceItem = typeof complianceItems.$inferSelect;
export type InsertComplianceItem = z.infer<typeof insertComplianceItemSchema>;
export type ActivityLog = typeof activityLog.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ReportTemplate = typeof reportTemplates.$inferSelect;
export type InsertReportTemplate = z.infer<typeof insertReportTemplateSchema>;
export type GeneratedReport = typeof generatedReports.$inferSelect;
export type InsertGeneratedReport = z.infer<typeof insertGeneratedReportSchema>;
export type ValidationResult = typeof validationResults.$inferSelect;
export type InsertValidationResult = z.infer<typeof insertValidationResultSchema>;
