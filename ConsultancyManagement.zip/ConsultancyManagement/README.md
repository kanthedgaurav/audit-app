# FinAudit Pro - Integrated Financial Management Suite

![FinAudit Pro](https://img.shields.io/badge/FinAudit%20Pro-v1.0.0-blue)
![Node.js](https://img.shields.io/badge/node.js-%3E%3D18.0.0-brightgreen)
![React](https://img.shields.io/badge/react-18.x-blue)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15%2B-blue)

A comprehensive financial management and audit platform for consultancy firms, CA firms, ACCA practitioners, chartered accountants, internal auditors, and corporate finance teams in the UAE.

## 🚀 Features

### Core Financial Management
- **Multi-tenant Client Management** - Manage multiple clients with role-based access
- **Trial Balance Processing** - Advanced Excel parsing with auto-account creation
- **Chart of Accounts** - IFRS-compliant account management with validation
- **General Ledger** - Complete transaction tracking and reconciliation

### Financial Statement Generation
- **Automated Statement Creation** - Balance Sheet, P&L, Cash Flow statements
- **IFRS Compliance** - Full International Financial Reporting Standards support
- **UAE-specific Features** - Compliance with UAE regulatory requirements
- **Multiple Export Formats** - Word, Excel, PDF, and HTML exports

### Audit & Compliance
- **Risk-based Internal Audit** - Comprehensive audit workflow management
- **ICOFR Implementation** - Internal Controls over Financial Reporting
- **Compliance Tracking** - Automated compliance monitoring and reporting
- **Document Management** - Version-controlled document storage

### Advanced Features
- **AI-powered Analytics** - Financial insights and trend analysis
- **Flexible File Processing** - Handles various Excel formats and structures
- **Secure File Storage** - Local filesystem with planned cloud integration
- **Real-time Collaboration** - Multi-user workspace with activity tracking

## 🛠️ Technology Stack

### Frontend
- **React 18** with TypeScript
- **Wouter** for routing
- **TanStack Query** for state management
- **Radix UI + shadcn/ui** for components
- **Tailwind CSS** for styling
- **Vite** for development and building

### Backend
- **Node.js** with Express.js
- **TypeScript** for type safety
- **Drizzle ORM** for database operations
- **Multer** for file uploads
- **Express Session** for authentication

### Database
- **PostgreSQL 15+** (Neon serverless compatible)
- **Drizzle Kit** for schema migrations

## 📋 Prerequisites

Before setting up the project, ensure you have:

- **Node.js 18+** installed
- **PostgreSQL 15+** database running
- **Git** for version control
- **npm** or **yarn** package manager

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone https://github.com/kanthedgaurav/audit-app.git
cd audit-app
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Database Setup

#### Option A: Local PostgreSQL
1. Install PostgreSQL 15+ on your system
2. Create a new database:
```sql
CREATE DATABASE finaudit_pro;
CREATE USER finaudit_user WITH ENCRYPTED PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE finaudit_pro TO finaudit_user;
```

#### Option B: Neon Serverless (Recommended)
1. Sign up at [Neon.tech](https://neon.tech)
2. Create a new database
3. Copy the connection string

### 4. Environment Configuration

Create a `.env` file in the root directory:

```env
# Database Configuration
DATABASE_URL="postgresql://username:password@localhost:5432/finaudit_pro"
# For Neon: DATABASE_URL="postgresql://username:password@hostname/database?sslmode=require"

# Server Configuration
PORT=5000
NODE_ENV=development

# Session Configuration
SESSION_SECRET="your-super-secret-session-key-here"

# File Storage Configuration
UPLOAD_DIR="./uploads"
SECURE_STORAGE_DIR="./secure-storage"

# Optional: Replit Object Storage (for production)
# REPLIT_OBJECT_STORAGE_BUCKET="your-bucket-name"
```

### 5. Database Schema Setup

Push the database schema:

```bash
npm run db:push
```

This command will:
- Create all necessary tables
- Set up relationships and indexes
- Initialize the database with the Drizzle schema

### 6. Start the Application

For development:
```bash
npm run dev
```

The application will be available at:
- **Frontend**: http://localhost:5000
- **Backend API**: http://localhost:5000/api

## 🏗️ Project Structure

```
audit-app/
├── client/                    # React frontend
│   ├── src/
│   │   ├── components/       # Reusable UI components
│   │   ├── pages/           # Application pages
│   │   ├── hooks/           # Custom React hooks
│   │   ├── lib/             # Utility functions
│   │   └── App.tsx          # Main application component
│   └── index.html           # HTML template
├── server/                   # Node.js backend
│   ├── routes.ts           # API route definitions
│   ├── storage.ts          # Database operations
│   ├── file-processor.ts   # Excel file processing
│   ├── file-storage.ts     # File upload handling
│   ├── db.ts              # Database connection
│   └── index.ts           # Express server setup
├── shared/                  # Shared types and schemas
│   └── schema.ts           # Drizzle database schema
├── uploads/                # File upload directory
├── secure-storage/         # Client-specific secure storage
├── package.json           # Project dependencies
├── drizzle.config.ts      # Database configuration
├── tailwind.config.ts     # Tailwind CSS config
└── vite.config.ts         # Vite configuration
```

## 📊 Database Schema

The application uses a comprehensive PostgreSQL schema including:

### Core Tables
- **Users** - System users with role-based access
- **Firms** - Consultancy firms using the platform
- **Clients** - Client companies being managed
- **Financial Periods** - Fiscal year and period management

### Financial Data
- **Chart of Accounts** - IFRS-compliant account structure
- **Trial Balance** - Balance data for financial periods
- **General Ledger** - Detailed transaction records
- **Financial Statements** - Generated statements and reports

### Audit & Compliance
- **Audit Engagements** - Audit workflow management
- **Documents** - File and document tracking
- **Compliance Items** - Regulatory compliance monitoring
- **Activity Logs** - System activity and audit trails

## 🔧 Configuration Options

### File Processing
The application supports various Excel formats for:
- Trial Balance uploads
- Chart of Accounts imports
- General Ledger data

### Storage Options
- **Local Filesystem** (default) - Files stored in `uploads/` and `secure-storage/`
- **Replit Object Storage** (optional) - Cloud storage for production deployments

### IFRS Compliance
Built-in validation for:
- Account type requirements
- Essential IFRS accounts
- UAE-specific compliance checks
- Balance sheet equation validation

## 🧪 Development

### Available Scripts

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Database operations
npm run db:push          # Push schema changes
npm run db:studio        # Open Drizzle Studio
npm run db:generate      # Generate migrations

# Linting and formatting
npm run lint
npm run format
```

### Development Workflow

1. **Frontend Development**: Uses Vite with hot reload
2. **Backend Development**: Uses tsx with auto-restart
3. **Database Changes**: Use `npm run db:push` for schema updates
4. **File Processing**: Test with sample Excel files in various formats

## 🚀 Deployment

### Production Setup

1. **Environment Variables**
```env
NODE_ENV=production
DATABASE_URL="your-production-database-url"
PORT=5000
SESSION_SECRET="your-production-session-secret"
```

2. **Build the Application**
```bash
npm run build
```

3. **Start Production Server**
```bash
npm start
```

### Deployment Platforms

#### Replit Deployments (Recommended)
- Automatic builds and deployment
- Integrated with Neon PostgreSQL
- Built-in SSL and custom domains
- Auto-scaling capabilities

#### Other Platforms
- **Vercel** - Frontend deployment
- **Railway** - Full-stack deployment
- **Heroku** - Traditional PaaS deployment
- **DigitalOcean App Platform** - Container deployment

## 🔒 Security Features

- **Role-based Access Control** - Multi-level user permissions
- **Session Management** - Secure session handling
- **File Upload Security** - Validated file types and sizes
- **Database Security** - Parameterized queries and validation
- **IFRS Compliance** - Built-in financial compliance checks

## 📚 API Documentation

The application provides RESTful APIs for:

### Client Management
- `GET /api/clients/:firmId` - List clients
- `POST /api/clients` - Create new client
- `PUT /api/clients/:id` - Update client
- `DELETE /api/clients/:id` - Delete client

### Financial Data
- `GET /api/chart-of-accounts/:clientId` - Get chart of accounts
- `POST /api/upload/chart-of-accounts` - Upload COA file
- `GET /api/trial-balance/:clientId/:periodId` - Get trial balance
- `POST /api/upload/trial-balance` - Upload TB file
- `POST /api/generate-statement` - Generate financial statements

### File Management
- `POST /api/upload/:type` - Upload files
- `GET /api/documents/:clientId` - List client documents
- `DELETE /api/documents/:id` - Delete document

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:

- **GitHub Issues**: [Create an issue](https://github.com/kanthedgaurav/audit-app/issues)
- **Documentation**: Check the `/docs` folder for detailed guides
- **Email**: support@finauditpro.com

## 🔄 Recent Updates

### Version 1.0.0 (January 2025)
- Initial release with complete financial management suite
- IFRS compliance validation system
- Enhanced Excel processing with auto-account creation
- Multi-tenant architecture with role-based access
- Comprehensive audit workflow management

---

**FinAudit Pro** - Empowering financial professionals in the UAE with integrated audit and financial management solutions.