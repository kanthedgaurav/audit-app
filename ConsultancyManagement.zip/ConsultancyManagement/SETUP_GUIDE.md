# FinAudit Pro - Detailed Setup Guide

This guide provides step-by-step instructions for setting up FinAudit Pro on different environments.

## 🖥️ Local Development Setup

### 1. System Requirements
- **Node.js 18+** (LTS recommended)
- **PostgreSQL 15+**
- **Git**
- **4GB RAM minimum**
- **2GB free disk space**

### 2. PostgreSQL Installation

#### On Windows:
1. Download PostgreSQL from https://www.postgresql.org/download/windows/
2. Install with default settings
3. Remember the superuser password
4. Add PostgreSQL to PATH

#### On macOS:
```bash
# Using Homebrew
brew install postgresql@15
brew services start postgresql@15

# Or using PostgreSQL.app
# Download from https://postgresapp.com/
```

#### On Ubuntu/Debian:
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### 3. Database Setup

1. **Connect to PostgreSQL:**
```bash
# Switch to postgres user (Linux/macOS)
sudo -u postgres psql

# Or connect directly (Windows/macOS)
psql -U postgres
```

2. **Create Database and User:**
```sql
-- Create database
CREATE DATABASE finaudit_pro;

-- Create user
CREATE USER finaudit_user WITH ENCRYPTED PASSWORD 'your_secure_password';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE finaudit_pro TO finaudit_user;

-- Grant schema privileges
\c finaudit_pro
GRANT ALL ON SCHEMA public TO finaudit_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO finaudit_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO finaudit_user;

-- Exit
\q
```

### 4. Project Setup

1. **Clone and Install:**
```bash
git clone https://github.com/kanthedgaurav/audit-app.git
cd audit-app
npm install
```

2. **Environment Configuration:**
```bash
# Copy environment template
cp .env.example .env

# Edit .env file
nano .env  # or use your preferred editor
```

3. **Environment Variables:**
```env
# Database
DATABASE_URL="postgresql://finaudit_user:your_secure_password@localhost:5432/finaudit_pro"

# Server
PORT=5000
NODE_ENV=development

# Security
SESSION_SECRET="generate-a-super-secure-random-key-here"

# File Storage
UPLOAD_DIR="./uploads"
SECURE_STORAGE_DIR="./secure-storage"

# Optional: Enable debug logging
DEBUG=finaudit:*
```

4. **Initialize Database:**
```bash
# Push database schema
npm run db:push

# Verify tables were created
npm run db:studio
```

5. **Start Development:**
```bash
# Start development server
npm run dev

# Open browser to http://localhost:5000
```

## ☁️ Cloud Setup (Neon + Replit)

### 1. Neon PostgreSQL Setup

1. **Sign up at [Neon.tech](https://neon.tech)**
2. **Create a new project:**
   - Project name: `finaudit-pro`
   - PostgreSQL version: 15+
   - Region: Choose closest to your users

3. **Get connection string:**
   - Go to Dashboard → Connection Details
   - Copy the connection string
   - Format: `postgresql://username:password@hostname/database?sslmode=require`

### 2. Replit Deployment

1. **Import Repository:**
   - Go to [Replit.com](https://replit.com)
   - Click "Create Repl"
   - Choose "Import from GitHub"
   - Enter: `https://github.com/kanthedgaurav/audit-app`

2. **Environment Variables in Replit:**
   - Go to "Secrets" tab (lock icon)
   - Add these secrets:
   ```
   DATABASE_URL: your-neon-connection-string
   SESSION_SECRET: your-secure-session-secret
   NODE_ENV: production
   ```

3. **Deploy:**
   - Replit will automatically install dependencies
   - Run database migrations: `npm run db:push`
   - Start the application: `npm run dev`

## 🐳 Docker Setup (Optional)

1. **Create Dockerfile:**
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 5000

CMD ["npm", "start"]
```

2. **Create docker-compose.yml:**
```yaml
version: '3.8'

services:
  db:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: finaudit_pro
      POSTGRES_USER: finaudit_user
      POSTGRES_PASSWORD: your_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  app:
    build: .
    ports:
      - "5000:5000"
    depends_on:
      - db
    environment:
      DATABASE_URL: postgresql://finaudit_user:your_password@db:5432/finaudit_pro
      SESSION_SECRET: your_session_secret
      NODE_ENV: production

volumes:
  postgres_data:
```

3. **Start with Docker:**
```bash
docker-compose up --build
```

## 🔧 Troubleshooting

### Common Issues

1. **Database Connection Errors:**
   - Check PostgreSQL is running: `pg_isready -h localhost -p 5432`
   - Verify credentials in .env file
   - Check firewall settings

2. **Node.js Version Issues:**
   ```bash
   # Check Node version
   node --version
   
   # Use Node Version Manager (nvm)
   nvm install 18
   nvm use 18
   ```

3. **Permission Errors (Linux/macOS):**
   ```bash
   # Fix npm permissions
   sudo chown -R $(whoami) ~/.npm
   
   # Or use npx instead of global installs
   npx create-react-app my-app
   ```

4. **Port Already in Use:**
   ```bash
   # Find process using port 5000
   lsof -i :5000
   
   # Kill the process (replace PID)
   kill -9 <PID>
   
   # Or change port in .env
   PORT=3000
   ```

5. **File Upload Issues:**
   - Check directory permissions:
   ```bash
   chmod 755 uploads/
   chmod 755 secure-storage/
   ```
   - Verify disk space: `df -h`

### Database Issues

1. **Schema Migration Errors:**
   ```bash
   # Reset database (WARNING: Deletes all data)
   npm run db:reset
   
   # Or manually drop and recreate
   psql -U postgres -c "DROP DATABASE IF EXISTS finaudit_pro;"
   psql -U postgres -c "CREATE DATABASE finaudit_pro;"
   npm run db:push
   ```

2. **Connection Pool Errors:**
   - Increase PostgreSQL max_connections
   - Check for connection leaks in code
   - Restart PostgreSQL service

### Development Issues

1. **Hot Reload Not Working:**
   - Check if files are being watched
   - Restart development server
   - Clear npm cache: `npm cache clean --force`

2. **TypeScript Errors:**
   ```bash
   # Check TypeScript compilation
   npx tsc --noEmit
   
   # Clear TypeScript cache
   rm -rf node_modules/.cache
   ```

## 📊 Initial Data Setup

### 1. Create Admin User
After first startup, create an admin user through the database:

```sql
INSERT INTO users (email, password, first_name, last_name, role, is_active)
VALUES ('admin@example.com', 'hashed_password', 'Admin', 'User', 'admin', true);
```

### 2. Create Sample Firm
```sql
INSERT INTO firms (name, registration_number, address, phone, email, is_active)
VALUES ('Sample Consultancy LLC', 'REG123456', '123 Business Street, Dubai, UAE', '+971-4-1234567', 'info@sample.ae', true);
```

### 3. Sample Chart of Accounts
Upload the provided sample COA file or create basic accounts:

```sql
-- Assets
INSERT INTO chart_of_accounts (client_id, account_code, account_name, account_type, is_active)
VALUES 
(1, '1001', 'Cash and Cash Equivalents', 'Asset', true),
(1, '1002', 'Accounts Receivable', 'Asset', true),
(1, '1003', 'Inventory', 'Asset', true);

-- Liabilities  
INSERT INTO chart_of_accounts (client_id, account_code, account_name, account_type, is_active)
VALUES 
(1, '2001', 'Accounts Payable', 'Liability', true),
(1, '2002', 'Short-term Loans', 'Liability', true);

-- Equity
INSERT INTO chart_of_accounts (client_id, account_code, account_name, account_type, is_active)
VALUES 
(1, '3001', 'Share Capital', 'Equity', true),
(1, '3002', 'Retained Earnings', 'Equity', true);
```

## 🚀 Production Deployment Checklist

- [ ] Environment variables configured
- [ ] Database migrations applied
- [ ] SSL certificates installed
- [ ] File upload directories created with proper permissions
- [ ] Backup strategy implemented
- [ ] Monitoring and logging configured
- [ ] Security headers configured
- [ ] Rate limiting enabled
- [ ] Error tracking setup (Sentry, etc.)
- [ ] Performance monitoring (APM) configured

## 📞 Support

If you encounter issues not covered in this guide:

1. Check the GitHub Issues: https://github.com/kanthedgaurav/audit-app/issues
2. Review the main README.md
3. Check the application logs for error details
4. Contact support: support@finauditpro.com