# Deployment Guide for FinAudit Pro

This guide covers deployment strategies for FinAudit Pro in various environments.

## 🚀 Quick Deployment Options

### 1. Replit Deployments (Recommended)
**Best for**: Quick setup, managed hosting, automatic scaling

1. **Import Repository:**
   - Fork or import the repository to Replit
   - Replit will auto-detect the project type

2. **Configure Environment:**
   ```bash
   # Add these secrets in Replit
   DATABASE_URL=your-neon-connection-string
   SESSION_SECRET=your-secure-session-key
   NODE_ENV=production
   ```

3. **Deploy:**
   - Click "Deploy" in Replit
   - Application will be available at `your-repl-name.replit.app`

**Benefits:**
- Automatic SSL certificates
- Built-in monitoring
- Zero-config deployments
- Integrated with Neon PostgreSQL

### 2. Vercel + Neon
**Best for**: Frontend-heavy applications, serverless functions

1. **Setup:**
   ```bash
   npm install -g vercel
   vercel login
   vercel --prod
   ```

2. **Environment Variables in Vercel:**
   ```bash
   vercel env add DATABASE_URL
   vercel env add SESSION_SECRET
   vercel env add NODE_ENV
   ```

### 3. Railway
**Best for**: Full-stack applications, database included

1. **Connect Repository:**
   - Go to Railway.app
   - Connect your GitHub repository
   - Railway will auto-deploy

2. **Add PostgreSQL:**
   - Click "New Service" → "Database" → "PostgreSQL"
   - Railway provides DATABASE_URL automatically

## 🏗️ Production Setup

### Environment Configuration

```env
# Production Environment
NODE_ENV=production
PORT=5000

# Database (Use connection pooling)
DATABASE_URL="postgresql://user:pass@host:5432/db?pool_max=20"

# Security
SESSION_SECRET="generate-secure-64-char-random-string"

# File Storage
UPLOAD_DIR="/var/app/uploads"
SECURE_STORAGE_DIR="/var/app/secure-storage"

# Performance
NODE_OPTIONS="--max-old-space-size=2048"
```

### Security Checklist

- [ ] **HTTPS Enabled**: SSL certificates configured
- [ ] **Environment Variables**: No secrets in code
- [ ] **Database Security**: Connection strings secured
- [ ] **Session Security**: Secure session configuration
- [ ] **File Upload Security**: File type validation
- [ ] **CORS Configuration**: Proper origin restrictions
- [ ] **Rate Limiting**: API rate limits configured
- [ ] **Input Validation**: All inputs validated
- [ ] **Error Handling**: No sensitive info in errors
- [ ] **Logging**: Comprehensive logging without secrets

### Performance Optimization

```javascript
// Add to server/index.ts for production
if (process.env.NODE_ENV === 'production') {
  // Enable compression
  app.use(compression());
  
  // Security headers
  app.use(helmet());
  
  // Rate limiting
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100 // limit each IP to 100 requests per windowMs
  });
  app.use('/api', limiter);
}
```

## 🐳 Docker Deployment

### Dockerfile
```dockerfile
# Multi-stage build for smaller image
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production && npm cache clean --force

FROM node:18-alpine AS runner
WORKDIR /app

# Create non-root user
RUN addgroup -g 1001 -S nodejs
RUN adduser -S finaudit -u 1001

# Copy built application
COPY --from=builder /app/node_modules ./node_modules
COPY . .

# Set permissions
RUN mkdir -p uploads secure-storage
RUN chown -R finaudit:nodejs /app
USER finaudit

EXPOSE 5000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:5000/api/health || exit 1

CMD ["npm", "start"]
```

### Docker Compose Production
```yaml
version: '3.8'

services:
  traefik:
    image: traefik:v2.9
    command:
      - --providers.docker=true
      - --entrypoints.web.address=:80
      - --entrypoints.websecure.address=:443
      - --certificatesresolvers.letsencrypt.acme.email=admin@yourdomain.com
      - --certificatesresolvers.letsencrypt.acme.storage=/acme.json
      - --certificatesresolvers.letsencrypt.acme.httpchallenge.entrypoint=web
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock:ro
      - ./acme.json:/acme.json

  db:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: finaudit_pro
      POSTGRES_USER: finaudit_user
      POSTGRES_PASSWORD_FILE: /run/secrets/db_password
    secrets:
      - db_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./backups:/backups
    restart: unless-stopped

  app:
    build: .
    environment:
      DATABASE_URL: postgresql://finaudit_user:${DB_PASSWORD}@db:5432/finaudit_pro
      SESSION_SECRET_FILE: /run/secrets/session_secret
      NODE_ENV: production
    secrets:
      - session_secret
    volumes:
      - app_uploads:/app/uploads
      - app_storage:/app/secure-storage
    depends_on:
      - db
    restart: unless-stopped
    labels:
      - traefik.enable=true
      - traefik.http.routers.finaudit.rule=Host(`your-domain.com`)
      - traefik.http.routers.finaudit.tls.certresolver=letsencrypt

  backup:
    image: postgres:15-alpine
    environment:
      PGPASSWORD_FILE: /run/secrets/db_password
    secrets:
      - db_password
    volumes:
      - ./backups:/backups
    command: |
      sh -c '
      while true; do
        pg_dump -h db -U finaudit_user -d finaudit_pro > /backups/backup-$$(date +%Y%m%d-%H%M%S).sql
        find /backups -name "backup-*.sql" -mtime +7 -delete
        sleep 86400
      done'
    depends_on:
      - db

secrets:
  db_password:
    file: ./secrets/db_password.txt
  session_secret:
    file: ./secrets/session_secret.txt

volumes:
  postgres_data:
  app_uploads:
  app_storage:
```

## ☁️ Cloud Provider Specific

### AWS Deployment

1. **Using Elastic Beanstalk:**
   ```bash
   # Install EB CLI
   pip install awsebcli
   
   # Initialize and deploy
   eb init finaudit-pro
   eb create production
   eb deploy
   ```

2. **Using ECS with Fargate:**
   - Use the provided Dockerfile
   - Configure RDS for PostgreSQL
   - Set up Application Load Balancer
   - Configure CloudWatch for monitoring

### Google Cloud Platform

1. **Using Cloud Run:**
   ```bash
   # Build and deploy
   gcloud run deploy finaudit-pro \
     --source . \
     --platform managed \
     --region us-central1 \
     --allow-unauthenticated
   ```

2. **Database:** Use Cloud SQL for PostgreSQL

### Microsoft Azure

1. **Using Container Instances:**
   ```bash
   # Deploy container
   az container create \
     --resource-group finaudit-rg \
     --name finaudit-pro \
     --image your-registry/finaudit-pro:latest \
     --dns-name-label finaudit-pro \
     --ports 5000
   ```

## 🔄 CI/CD Pipeline

### GitHub Actions
```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm test

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Deploy to production
        run: |
          # Add your deployment commands here
          # e.g., docker build and push, or deploy to cloud provider
```

## 📊 Monitoring & Maintenance

### Health Checks
Add health check endpoint:

```javascript
// server/routes.ts
app.get('/api/health', async (req, res) => {
  try {
    // Check database connection
    await db.raw('SELECT 1');
    
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      memory: process.memoryUsage()
    });
  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      error: error.message
    });
  }
});
```

### Logging
Use structured logging:

```javascript
import winston from 'winston';

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: 'finaudit-pro' },
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});
```

### Database Backups
Automated backup script:

```bash
#!/bin/bash
# backup-db.sh

DB_NAME="finaudit_pro"
BACKUP_DIR="/var/backups/finaudit"
DATE=$(date +%Y%m%d_%H%M%S)

# Create backup
pg_dump $DB_NAME > $BACKUP_DIR/backup_$DATE.sql

# Compress
gzip $BACKUP_DIR/backup_$DATE.sql

# Clean old backups (keep 30 days)
find $BACKUP_DIR -name "backup_*.sql.gz" -mtime +30 -delete
```

## 🚨 Troubleshooting Production Issues

### Common Issues

1. **Memory Leaks:**
   - Monitor memory usage
   - Restart application if memory > 80%
   - Profile with `--inspect` flag

2. **Database Connection Issues:**
   - Check connection pool settings
   - Monitor active connections
   - Implement connection retry logic

3. **File Upload Problems:**
   - Check disk space
   - Verify directory permissions
   - Monitor upload directory size

4. **Performance Issues:**
   - Enable response compression
   - Implement caching
   - Optimize database queries
   - Use CDN for static assets

### Monitoring Commands
```bash
# Check application logs
docker logs finaudit-pro --tail=100 -f

# Monitor resource usage
docker stats finaudit-pro

# Check database connections
docker exec -it finaudit-db psql -U finaudit_user -c "SELECT * FROM pg_stat_activity;"

# Monitor disk usage
df -h
```

This deployment guide ensures your FinAudit Pro application runs reliably in production with proper security, monitoring, and maintenance procedures.