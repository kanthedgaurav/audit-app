import { Button } from "@/components/ui/button";
import { Bell, Plus } from "lucide-react";
import { DashboardMetrics } from "@/components/dashboard-metrics";
import { RecentActivity } from "@/components/recent-activity";
import { ClientPortfolio } from "@/components/client-portfolio";
import { QuickActions } from "@/components/quick-actions";
import { UpcomingDeadlines } from "@/components/upcoming-deadlines";
import { PerformanceAnalytics } from "@/components/performance-analytics";

export default function Dashboard() {
  // For now, using a static firm ID. In a real app, this would come from auth context
  const firmId = 1;

  return (
    <div className="flex-1">
      {/* Top Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 lg:px-6 py-4 pt-16 lg:pt-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl lg:text-2xl font-bold text-gray-900">Dashboard</h2>
            <p className="text-sm text-gray-500">Overview of your consultancy firm's operations</p>
          </div>
          <div className="flex items-center space-x-2 lg:space-x-4">
            <Button className="bg-primary text-white hover:bg-primary-dark text-xs lg:text-sm px-2 lg:px-4">
              <Plus className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
              <span className="hidden sm:inline">New Client</span>
              <span className="sm:hidden">New</span>
            </Button>
            <div className="relative">
              <Bell className="w-4 h-4 lg:w-5 lg:h-5 text-gray-500 cursor-pointer hover:text-primary" />
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-4 h-4 lg:w-5 lg:h-5 flex items-center justify-center text-[10px] lg:text-xs">
                3
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="p-4 lg:p-6">
        {/* Key Metrics */}
        <DashboardMetrics firmId={firmId} />

        {/* Recent Activity & Client Portfolio */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <RecentActivity firmId={firmId} />
          <ClientPortfolio firmId={firmId} />
        </div>

        {/* Quick Actions & Upcoming Deadlines */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <QuickActions />
          <UpcomingDeadlines firmId={firmId} />
        </div>

        {/* Performance Analytics */}
        <PerformanceAnalytics />
      </main>
    </div>
  );
}
