import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { 
  Plus, Search, Shield, Calendar, AlertTriangle, CheckCircle, 
  Clock, FileText, Users, Target, TrendingUp, Eye, Edit, User,
  Database, Brain, Zap, Activity, DollarSign, BarChart
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, differenceInDays } from "date-fns";

export default function EnhancedAudit() {
  const [selectedClient, setSelectedClient] = useState("");
  const [selectedEngagement, setSelectedEngagement] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState("");
  const [showProcedureDialog, setShowProcedureDialog] = useState(false);
  const [showIcofrDialog, setShowIcofrDialog] = useState(false);
  const [showAutomateDialog, setShowAutomateDialog] = useState(false);
  const [activeTab, setActiveTab] = useState("procedures");
  
  const [newProcedure, setNewProcedure] = useState({
    procedureType: "substantive",
    auditArea: "",
    accountCode: "",
    description: "",
    expectedResult: "",
    materiality: "",
    samplingMethod: "judgmental",
    sampleSize: "",
    status: "not_started"
  });

  const [newIcofr, setNewIcofr] = useState({
    controlObjective: "",
    controlDescription: "",
    controlType: "preventive",
    frequency: "daily",
    effectiveness: "effective",
    deficiencies: "",
    recommendations: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const firmId = 1; // Static for now

  // Fetch clients
  const { data: clients } = useQuery({
    queryKey: ['/api/clients', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/clients/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch clients');
      return response.json();
    },
  });

  // Fetch engagements for selected client
  const { data: engagements } = useQuery({
    queryKey: ['/api/audit-engagements', selectedClient],
    queryFn: async () => {
      if (!selectedClient) return [];
      const response = await fetch(`/api/audit-engagements/${selectedClient}`);
      if (!response.ok) throw new Error('Failed to fetch engagements');
      return response.json();
    },
    enabled: !!selectedClient,
  });

  // Fetch financial periods for selected client
  const { data: periods } = useQuery({
    queryKey: ['/api/financial-periods', selectedClient],
    queryFn: async () => {
      if (!selectedClient) return [];
      const response = await fetch(`/api/financial-periods/${selectedClient}`);
      if (!response.ok) throw new Error('Failed to fetch periods');
      return response.json();
    },
    enabled: !!selectedClient,
  });

  // Fetch audit procedures for selected engagement
  const { data: procedures, isLoading: proceduresLoading } = useQuery({
    queryKey: ['/api/audit-procedures', selectedEngagement],
    queryFn: async () => {
      if (!selectedEngagement) return [];
      const response = await fetch(`/api/audit-procedures/${selectedEngagement}`);
      if (!response.ok) throw new Error('Failed to fetch procedures');
      return response.json();
    },
    enabled: !!selectedEngagement,
  });

  // Fetch ICOFR assessments for selected engagement
  const { data: icofrAssessments, isLoading: icofrLoading } = useQuery({
    queryKey: ['/api/icofr-assessments', selectedEngagement],
    queryFn: async () => {
      if (!selectedEngagement) return [];
      const response = await fetch(`/api/icofr-assessments/${selectedEngagement}`);
      if (!response.ok) throw new Error('Failed to fetch ICOFR assessments');
      return response.json();
    },
    enabled: !!selectedEngagement,
  });

  // Fetch risk analysis
  const { data: riskAnalysis, isLoading: riskLoading } = useQuery({
    queryKey: ['/api/audit-analytics/risk-analysis', selectedClient, selectedPeriod],
    queryFn: async () => {
      if (!selectedClient || !selectedPeriod) return [];
      const response = await fetch(`/api/audit-analytics/risk-analysis/${selectedClient}/${selectedPeriod}`);
      if (!response.ok) throw new Error('Failed to fetch risk analysis');
      return response.json();
    },
    enabled: !!selectedClient && !!selectedPeriod,
  });

  // Fetch anomalies
  const { data: anomalies, isLoading: anomaliesLoading } = useQuery({
    queryKey: ['/api/audit-analytics/anomalies', selectedClient, selectedPeriod],
    queryFn: async () => {
      if (!selectedClient || !selectedPeriod) return [];
      const response = await fetch(`/api/audit-analytics/anomalies/${selectedClient}/${selectedPeriod}`);
      if (!response.ok) throw new Error('Failed to fetch anomalies');
      return response.json();
    },
    enabled: !!selectedClient && !!selectedPeriod,
  });

  // Fetch journal testing
  const { data: journalTesting, isLoading: journalLoading } = useQuery({
    queryKey: ['/api/audit-analytics/journal-testing', selectedClient, selectedPeriod],
    queryFn: async () => {
      if (!selectedClient || !selectedPeriod) return [];
      const response = await fetch(`/api/audit-analytics/journal-testing/${selectedClient}/${selectedPeriod}?sampleSize=15`);
      if (!response.ok) throw new Error('Failed to fetch journal testing');
      return response.json();
    },
    enabled: !!selectedClient && !!selectedPeriod,
  });

  // Create audit procedure mutation
  const createProcedureMutation = useMutation({
    mutationFn: async (procedure: any) => {
      await apiRequest('POST', '/api/audit-procedures', { 
        ...procedure, 
        engagementId: parseInt(selectedEngagement),
        materiality: parseFloat(procedure.materiality) || 0,
        sampleSize: parseInt(procedure.sampleSize) || null,
        performedBy: 1
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/audit-procedures', selectedEngagement] });
      toast({ title: "Success", description: "Audit procedure created successfully" });
      setShowProcedureDialog(false);
      setNewProcedure({
        procedureType: "substantive",
        auditArea: "",
        accountCode: "",
        description: "",
        expectedResult: "",
        materiality: "",
        samplingMethod: "judgmental",
        sampleSize: "",
        status: "not_started"
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create audit procedure", variant: "destructive" });
    },
  });

  // Create ICOFR assessment mutation
  const createIcofrMutation = useMutation({
    mutationFn: async (icofr: any) => {
      await apiRequest('POST', '/api/icofr-assessments', { 
        ...icofr, 
        engagementId: parseInt(selectedEngagement),
        assessedBy: 1
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/icofr-assessments', selectedEngagement] });
      toast({ title: "Success", description: "ICOFR assessment created successfully" });
      setShowIcofrDialog(false);
      setNewIcofr({
        controlObjective: "",
        controlDescription: "",
        controlType: "preventive",
        frequency: "daily",
        effectiveness: "effective",
        deficiencies: "",
        recommendations: ""
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create ICOFR assessment", variant: "destructive" });
    },
  });

  // Generate automated procedures mutation
  const generateAutomatedMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/audit-procedures/generate-automated/${selectedEngagement}`, { 
        clientId: parseInt(selectedClient),
        periodId: parseInt(selectedPeriod)
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/audit-procedures', selectedEngagement] });
      toast({ 
        title: "Success", 
        description: `Generated ${data.procedures?.length || 0} automated audit procedures based on financial data analysis` 
      });
      setShowAutomateDialog(false);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to generate automated procedures", variant: "destructive" });
    },
  });

  const getProcedureStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'in_progress': return 'bg-blue-500';
      case 'not_started': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getRiskLevelColor = (riskScore: number) => {
    if (riskScore >= 3) return 'text-red-600 bg-red-50';
    if (riskScore >= 2) return 'text-yellow-600 bg-yellow-50';
    return 'text-green-600 bg-green-50';
  };

  const getEffectivenessColor = (effectiveness: string) => {
    switch (effectiveness) {
      case 'effective': return 'text-green-600 bg-green-50';
      case 'deficient': return 'text-red-600 bg-red-50';
      case 'requires_improvement': return 'text-yellow-600 bg-yellow-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-6 lg:py-8">
        {/* Header */}
        <div className="mb-6 lg:mb-8">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Enhanced Internal Audit & ICOFR
          </h1>
          <p className="text-sm lg:text-base text-gray-600 dark:text-gray-300">
            Comprehensive audit management with financial data integration and automated analytics
          </p>
        </div>

        {/* Selection Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div>
            <Label htmlFor="client">Select Client</Label>
            <Select value={selectedClient} onValueChange={setSelectedClient}>
              <SelectTrigger>
                <SelectValue placeholder="Choose client..." />
              </SelectTrigger>
              <SelectContent>
                {clients?.map((client: any) => (
                  <SelectItem key={client.id} value={client.id.toString()}>
                    {client.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="engagement">Select Engagement</Label>
            <Select value={selectedEngagement} onValueChange={setSelectedEngagement} disabled={!selectedClient}>
              <SelectTrigger>
                <SelectValue placeholder="Choose engagement..." />
              </SelectTrigger>
              <SelectContent>
                {engagements?.map((engagement: any) => (
                  <SelectItem key={engagement.id} value={engagement.id.toString()}>
                    {engagement.engagementType} - {engagement.scope?.substring(0, 30)}...
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="period">Select Period</Label>
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod} disabled={!selectedClient}>
              <SelectTrigger>
                <SelectValue placeholder="Choose period..." />
              </SelectTrigger>
              <SelectContent>
                {periods?.map((period: any) => (
                  <SelectItem key={period.id} value={period.id.toString()}>
                    {period.description} ({format(new Date(period.startDate), 'MMM yyyy')} - {format(new Date(period.endDate), 'MMM yyyy')})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-end">
            <Dialog open={showAutomateDialog} onOpenChange={setShowAutomateDialog}>
              <DialogTrigger asChild>
                <Button 
                  className="w-full" 
                  disabled={!selectedEngagement || !selectedPeriod}
                  variant="outline"
                >
                  <Brain className="w-4 h-4 mr-2" />
                  AI Generate
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Generate Automated Audit Procedures</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Alert>
                    <Brain className="h-4 w-4" />
                    <AlertDescription>
                      This will analyze your financial data (trial balance, chart of accounts, risk analysis) and automatically generate targeted audit procedures based on account balances, risk scores, and transaction patterns.
                    </AlertDescription>
                  </Alert>
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => generateAutomatedMutation.mutate()}
                      disabled={generateAutomatedMutation.isPending}
                      className="flex-1"
                    >
                      {generateAutomatedMutation.isPending ? "Generating..." : "Generate Procedures"}
                    </Button>
                    <Button variant="outline" onClick={() => setShowAutomateDialog(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {selectedClient && selectedEngagement ? (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4">
              <TabsTrigger value="procedures" className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                <span className="hidden sm:inline">Procedures</span>
              </TabsTrigger>
              <TabsTrigger value="icofr" className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                <span className="hidden sm:inline">ICOFR</span>
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-2">
                <BarChart className="w-4 h-4" />
                <span className="hidden sm:inline">Analytics</span>
              </TabsTrigger>
              <TabsTrigger value="testing" className="flex items-center gap-2">
                <Database className="w-4 h-4" />
                <span className="hidden sm:inline">Testing</span>
              </TabsTrigger>
            </TabsList>

            {/* Audit Procedures Tab */}
            <TabsContent value="procedures" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h2 className="text-xl font-semibold">Audit Procedures</h2>
                <Dialog open={showProcedureDialog} onOpenChange={setShowProcedureDialog}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Procedure
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Create New Audit Procedure</DialogTitle>
                    </DialogHeader>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="procedureType">Procedure Type</Label>
                        <Select value={newProcedure.procedureType} onValueChange={(value) => setNewProcedure({...newProcedure, procedureType: value})}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="substantive">Substantive Testing</SelectItem>
                            <SelectItem value="analytical_review">Analytical Review</SelectItem>
                            <SelectItem value="control_testing">Control Testing</SelectItem>
                            <SelectItem value="compliance_testing">Compliance Testing</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="auditArea">Audit Area</Label>
                        <Input
                          value={newProcedure.auditArea}
                          onChange={(e) => setNewProcedure({...newProcedure, auditArea: e.target.value})}
                          placeholder="e.g., Revenue, Cash, Inventory"
                        />
                      </div>
                      <div>
                        <Label htmlFor="accountCode">Account Code</Label>
                        <Input
                          value={newProcedure.accountCode}
                          onChange={(e) => setNewProcedure({...newProcedure, accountCode: e.target.value})}
                          placeholder="e.g., 100, 400, 500"
                        />
                      </div>
                      <div>
                        <Label htmlFor="materiality">Materiality (AED)</Label>
                        <Input
                          type="number"
                          value={newProcedure.materiality}
                          onChange={(e) => setNewProcedure({...newProcedure, materiality: e.target.value})}
                          placeholder="5000"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                          value={newProcedure.description}
                          onChange={(e) => setNewProcedure({...newProcedure, description: e.target.value})}
                          placeholder="Detailed procedure description..."
                          rows={3}
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label htmlFor="expectedResult">Expected Result</Label>
                        <Textarea
                          value={newProcedure.expectedResult}
                          onChange={(e) => setNewProcedure({...newProcedure, expectedResult: e.target.value})}
                          placeholder="Expected audit outcome..."
                          rows={2}
                        />
                      </div>
                      <div>
                        <Label htmlFor="samplingMethod">Sampling Method</Label>
                        <Select value={newProcedure.samplingMethod} onValueChange={(value) => setNewProcedure({...newProcedure, samplingMethod: value})}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="judgmental">Judgmental</SelectItem>
                            <SelectItem value="statistical">Statistical</SelectItem>
                            <SelectItem value="monetary_unit">Monetary Unit</SelectItem>
                            <SelectItem value="systematic">Systematic</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="sampleSize">Sample Size</Label>
                        <Input
                          type="number"
                          value={newProcedure.sampleSize}
                          onChange={(e) => setNewProcedure({...newProcedure, sampleSize: e.target.value})}
                          placeholder="25"
                        />
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <Button 
                        onClick={() => createProcedureMutation.mutate(newProcedure)}
                        disabled={createProcedureMutation.isPending}
                        className="flex-1"
                      >
                        {createProcedureMutation.isPending ? "Creating..." : "Create Procedure"}
                      </Button>
                      <Button variant="outline" onClick={() => setShowProcedureDialog(false)}>
                        Cancel
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              {proceduresLoading ? (
                <div className="text-center py-8">Loading procedures...</div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                  {procedures?.map((procedure: any) => (
                    <Card key={procedure.id} className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <Badge variant="outline" className="text-xs">
                              {procedure.procedureType.replace('_', ' ')}
                            </Badge>
                            <CardTitle className="text-base">{procedure.auditArea}</CardTitle>
                          </div>
                          <Badge className={`text-xs ${getProcedureStatusColor(procedure.status)}`}>
                            {procedure.status.replace('_', ' ')}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">
                          {procedure.description}
                        </p>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>Account: {procedure.accountCode}</span>
                          <span>Materiality: AED {procedure.materiality?.toLocaleString() || 'N/A'}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>{procedure.samplingMethod}</span>
                          {procedure.sampleSize && <span>Sample: {procedure.sampleSize}</span>}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* ICOFR Tab */}
            <TabsContent value="icofr" className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h2 className="text-xl font-semibold">Internal Control Over Financial Reporting</h2>
                <Dialog open={showIcofrDialog} onOpenChange={setShowIcofrDialog}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Assessment
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Create ICOFR Assessment</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="controlObjective">Control Objective</Label>
                        <Input
                          value={newIcofr.controlObjective}
                          onChange={(e) => setNewIcofr({...newIcofr, controlObjective: e.target.value})}
                          placeholder="e.g., Revenue Recognition Accuracy"
                        />
                      </div>
                      <div>
                        <Label htmlFor="controlDescription">Control Description</Label>
                        <Textarea
                          value={newIcofr.controlDescription}
                          onChange={(e) => setNewIcofr({...newIcofr, controlDescription: e.target.value})}
                          placeholder="Detailed description of the control..."
                          rows={3}
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="controlType">Control Type</Label>
                          <Select value={newIcofr.controlType} onValueChange={(value) => setNewIcofr({...newIcofr, controlType: value})}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="preventive">Preventive</SelectItem>
                              <SelectItem value="detective">Detective</SelectItem>
                              <SelectItem value="corrective">Corrective</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="frequency">Frequency</Label>
                          <Select value={newIcofr.frequency} onValueChange={(value) => setNewIcofr({...newIcofr, frequency: value})}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="daily">Daily</SelectItem>
                              <SelectItem value="weekly">Weekly</SelectItem>
                              <SelectItem value="monthly">Monthly</SelectItem>
                              <SelectItem value="quarterly">Quarterly</SelectItem>
                              <SelectItem value="annually">Annually</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="effectiveness">Effectiveness</Label>
                          <Select value={newIcofr.effectiveness} onValueChange={(value) => setNewIcofr({...newIcofr, effectiveness: value})}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="effective">Effective</SelectItem>
                              <SelectItem value="deficient">Deficient</SelectItem>
                              <SelectItem value="requires_improvement">Requires Improvement</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="deficiencies">Deficiencies</Label>
                        <Textarea
                          value={newIcofr.deficiencies}
                          onChange={(e) => setNewIcofr({...newIcofr, deficiencies: e.target.value})}
                          placeholder="Identified control deficiencies..."
                          rows={2}
                        />
                      </div>
                      <div>
                        <Label htmlFor="recommendations">Recommendations</Label>
                        <Textarea
                          value={newIcofr.recommendations}
                          onChange={(e) => setNewIcofr({...newIcofr, recommendations: e.target.value})}
                          placeholder="Recommendations for improvement..."
                          rows={2}
                        />
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <Button 
                        onClick={() => createIcofrMutation.mutate(newIcofr)}
                        disabled={createIcofrMutation.isPending}
                        className="flex-1"
                      >
                        {createIcofrMutation.isPending ? "Creating..." : "Create Assessment"}
                      </Button>
                      <Button variant="outline" onClick={() => setShowIcofrDialog(false)}>
                        Cancel
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              {icofrLoading ? (
                <div className="text-center py-8">Loading ICOFR assessments...</div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {icofrAssessments?.map((assessment: any) => (
                    <Card key={assessment.id} className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <CardTitle className="text-base">{assessment.controlObjective}</CardTitle>
                            <div className="flex gap-2">
                              <Badge variant="outline" className="text-xs">
                                {assessment.controlType}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {assessment.frequency}
                              </Badge>
                            </div>
                          </div>
                          <Badge className={`text-xs ${getEffectivenessColor(assessment.effectiveness)}`}>
                            {assessment.effectiveness.replace('_', ' ')}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">
                          {assessment.controlDescription}
                        </p>
                        {assessment.deficiencies && (
                          <div className="p-2 bg-red-50 dark:bg-red-900/20 rounded text-xs">
                            <strong>Deficiencies:</strong> {assessment.deficiencies}
                          </div>
                        )}
                        {assessment.recommendations && (
                          <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded text-xs">
                            <strong>Recommendations:</strong> {assessment.recommendations}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics" className="space-y-6">
              <h2 className="text-xl font-semibold">Financial Data Analytics</h2>
              
              {!selectedPeriod ? (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Please select a financial period to view analytics data.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Risk Analysis */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <TrendingUp className="w-5 h-5" />
                        Account Risk Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {riskLoading ? (
                        <div className="text-center py-4">Loading risk analysis...</div>
                      ) : (
                        <div className="space-y-3">
                          {riskAnalysis?.slice(0, 5).map((account: any, index: number) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded">
                              <div className="flex-1">
                                <div className="font-medium text-sm">{account.accountName}</div>
                                <div className="text-xs text-gray-500">
                                  {account.accountCode} • {account.accountType} • {account.entryCount} entries
                                </div>
                              </div>
                              <div className="text-right">
                                <Badge className={`text-xs ${getRiskLevelColor(account.riskScore)}`}>
                                  Risk: {account.riskScore}
                                </Badge>
                                <div className="text-xs text-gray-500 mt-1">
                                  AED {account.balance?.toLocaleString() || 0}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Anomalies */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5" />
                        Data Anomalies
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {anomaliesLoading ? (
                        <div className="text-center py-4">Loading anomalies...</div>
                      ) : anomalies?.length === 0 ? (
                        <div className="text-center py-4 text-gray-500">No anomalies detected</div>
                      ) : (
                        <div className="space-y-3">
                          {anomalies?.slice(0, 5).map((anomaly: any, index: number) => (
                            <div key={index} className="p-3 bg-red-50 dark:bg-red-900/20 rounded">
                              <div className="font-medium text-sm">{anomaly.accountName}</div>
                              <div className="text-xs text-gray-600 dark:text-gray-300">
                                {anomaly.accountCode} • {anomaly.anomalyType}
                              </div>
                              <div className="text-xs text-gray-500 mt-1">
                                Debit: {anomaly.debitAmount || 'N/A'} • Credit: {anomaly.creditAmount || 'N/A'}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}
            </TabsContent>

            {/* Testing Tab */}
            <TabsContent value="testing" className="space-y-6">
              <h2 className="text-xl font-semibold">Journal Entry Testing</h2>
              
              {!selectedPeriod ? (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Please select a financial period to view journal entry testing.
                  </AlertDescription>
                </Alert>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Database className="w-5 h-5" />
                      Sample Journal Entries for Testing
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {journalLoading ? (
                      <div className="text-center py-4">Loading journal testing...</div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left p-2">Account</th>
                              <th className="text-left p-2">Date</th>
                              <th className="text-left p-2">Description</th>
                              <th className="text-right p-2">Debit</th>
                              <th className="text-right p-2">Credit</th>
                              <th className="text-center p-2">Risk</th>
                            </tr>
                          </thead>
                          <tbody>
                            {journalTesting?.map((entry: any, index: number) => (
                              <tr key={index} className="border-b hover:bg-gray-50 dark:hover:bg-gray-800">
                                <td className="p-2">
                                  <div className="font-medium">{entry.accountName}</div>
                                  <div className="text-xs text-gray-500">{entry.accountCode}</div>
                                </td>
                                <td className="p-2 text-xs">
                                  {format(new Date(entry.transactionDate), 'MMM dd, yyyy')}
                                </td>
                                <td className="p-2 text-xs max-w-xs truncate">
                                  {entry.description}
                                </td>
                                <td className="p-2 text-right text-xs">
                                  {entry.debitAmount ? `AED ${entry.debitAmount.toLocaleString()}` : '-'}
                                </td>
                                <td className="p-2 text-right text-xs">
                                  {entry.creditAmount ? `AED ${entry.creditAmount.toLocaleString()}` : '-'}
                                </td>
                                <td className="p-2 text-center">
                                  <Badge 
                                    variant="outline" 
                                    className={`text-xs ${
                                      entry.riskLevel === 'High' ? 'text-red-600 bg-red-50' :
                                      entry.riskLevel === 'Medium' ? 'text-yellow-600 bg-yellow-50' :
                                      'text-green-600 bg-green-50'
                                    }`}
                                  >
                                    {entry.riskLevel}
                                  </Badge>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        ) : (
          <Card>
            <CardContent className="text-center py-12">
              <Shield className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                Enhanced Audit Management
              </h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Select a client and audit engagement to access comprehensive audit procedures, ICOFR assessments, and financial data analytics.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-2xl mx-auto">
                <div className="text-center p-4">
                  <Target className="w-8 h-8 mx-auto text-blue-500 mb-2" />
                  <div className="text-sm font-medium">Audit Procedures</div>
                  <div className="text-xs text-gray-500">Risk-based testing</div>
                </div>
                <div className="text-center p-4">
                  <Shield className="w-8 h-8 mx-auto text-green-500 mb-2" />
                  <div className="text-sm font-medium">ICOFR Assessment</div>
                  <div className="text-xs text-gray-500">Control evaluation</div>
                </div>
                <div className="text-center p-4">
                  <BarChart className="w-8 h-8 mx-auto text-purple-500 mb-2" />
                  <div className="text-sm font-medium">Data Analytics</div>
                  <div className="text-xs text-gray-500">Risk & anomaly detection</div>
                </div>
                <div className="text-center p-4">
                  <Database className="w-8 h-8 mx-auto text-orange-500 mb-2" />
                  <div className="text-sm font-medium">Journal Testing</div>
                  <div className="text-xs text-gray-500">Transaction sampling</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}