import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Search, Building, Factory, Laptop, Edit, Eye } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Clients() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [selectedClient, setSelectedClient] = useState<any>(null);
  const [newClient, setNewClient] = useState({
    name: "",
    industry: "",
    registrationNumber: "",
    jurisdiction: "UAE",
    reportingRegime: "IFRS",
    contactPerson: "",
    contactEmail: "",
    contactPhone: "",
    address: "",
    fiscalYearEnd: "",
    status: "active"
  });
  const [editClient, setEditClient] = useState({
    name: "",
    industry: "",
    registrationNumber: "",
    jurisdiction: "UAE",
    reportingRegime: "IFRS",
    contactPerson: "",
    contactEmail: "",
    contactPhone: "",
    address: "",
    fiscalYearEnd: "",
    status: "active"
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const firmId = 1; // Static for now

  const { data: clients, isLoading } = useQuery({
    queryKey: ['/api/clients', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/clients/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch clients');
      return response.json();
    },
  });

  const addClientMutation = useMutation({
    mutationFn: async (client: any) => {
      const response = await apiRequest('POST', '/api/clients', { ...client, firmId });
      return response;
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/clients', firmId] });
      const message = data.periodsCreated > 0 ? 
        `Client added successfully with ${data.periodsCreated} fiscal periods generated automatically` : 
        "Client added successfully";
      toast({ title: "Success", description: message });
      setShowAddDialog(false);
      resetNewClient();
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to add client", variant: "destructive" });
    },
  });

  const updateClientMutation = useMutation({
    mutationFn: async (client: any) => {
      const response = await apiRequest('PUT', `/api/clients/${client.id}`, client);
      return response;
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/clients', firmId] });
      const message = data.periodsCreated > 0 ? 
        `Client updated successfully with ${data.periodsCreated} new fiscal periods generated` : 
        "Client updated successfully";
      toast({ title: "Success", description: message });
      setShowEditDialog(false);
      setSelectedClient(null);
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to update client", variant: "destructive" });
    },
  });

  const resetNewClient = () => {
    setNewClient({
      name: "",
      industry: "",
      registrationNumber: "",
      jurisdiction: "UAE",
      reportingRegime: "IFRS",
      contactPerson: "",
      contactEmail: "",
      contactPhone: "",
      address: "",
      fiscalYearEnd: "",
      status: "active"
    });
  };

  const handleViewClient = (client: any) => {
    setSelectedClient(client);
    setShowViewDialog(true);
  };

  const handleEditClient = (client: any) => {
    setSelectedClient(client);
    setEditClient({
      name: client.name || "",
      industry: client.industry || "",
      registrationNumber: client.registrationNumber || "",
      jurisdiction: client.jurisdiction || "UAE",
      reportingRegime: client.reportingRegime || "IFRS",
      contactPerson: client.contactPerson || "",
      contactEmail: client.contactEmail || "",
      contactPhone: client.contactPhone || "",
      address: client.address || "",
      fiscalYearEnd: client.fiscalYearEnd || "",
      status: client.status || "active"
    });
    setShowEditDialog(true);
  };

  const handleUpdateClient = () => {
    if (!selectedClient) return;
    updateClientMutation.mutate({
      ...editClient,
      id: selectedClient.id
    });
  };

  const getIndustryIcon = (industry: string) => {
    switch (industry?.toLowerCase()) {
      case 'trading':
      case 'trading & distribution':
        return Building;
      case 'manufacturing':
        return Factory;
      case 'technology':
      case 'technology services':
        return Laptop;
      default:
        return Building;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'inactive':
        return <Badge className="bg-gray-100 text-gray-800">Inactive</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>;
    }
  };

  const filteredClients = clients?.filter((client: any) => {
    const matchesSearch = client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         client.industry?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || client.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleAddClient = () => {
    addClientMutation.mutate(newClient);
  };

  return (
    <div className="flex-1">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 lg:px-6 py-4 pt-16 lg:pt-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl lg:text-2xl font-bold text-gray-900">Client Management</h2>
            <p className="text-sm text-gray-500">Manage your client portfolio and engagements</p>
          </div>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-white hover:bg-primary-dark text-xs lg:text-sm px-2 lg:px-4">
                <Plus className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                <span className="hidden sm:inline">Add Client</span>
                <span className="sm:hidden">Add</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add New Client</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 lg:gap-4 max-h-[60vh] lg:max-h-none overflow-y-auto lg:overflow-visible pr-2 lg:pr-0">
                <div>
                  <Label htmlFor="name">Client Name *</Label>
                  <Input
                    id="name"
                    value={newClient.name}
                    onChange={(e) => setNewClient({ ...newClient, name: e.target.value })}
                    placeholder="Enter client name"
                  />
                </div>
                <div>
                  <Label htmlFor="industry">Industry</Label>
                  <Select value={newClient.industry} onValueChange={(value) => setNewClient({ ...newClient, industry: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Trading">Trading</SelectItem>
                      <SelectItem value="Manufacturing">Manufacturing</SelectItem>
                      <SelectItem value="Technology">Technology</SelectItem>
                      <SelectItem value="Healthcare">Healthcare</SelectItem>
                      <SelectItem value="Construction">Construction</SelectItem>
                      <SelectItem value="Real Estate">Real Estate</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="registrationNumber">Registration Number</Label>
                  <Input
                    id="registrationNumber"
                    value={newClient.registrationNumber}
                    onChange={(e) => setNewClient({ ...newClient, registrationNumber: e.target.value })}
                    placeholder="Enter registration number"
                  />
                </div>
                <div>
                  <Label htmlFor="jurisdiction">Jurisdiction</Label>
                  <Select value={newClient.jurisdiction} onValueChange={(value) => setNewClient({ ...newClient, jurisdiction: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select jurisdiction" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UAE">UAE</SelectItem>
                      <SelectItem value="Saudi Arabia">Saudi Arabia</SelectItem>
                      <SelectItem value="Qatar">Qatar</SelectItem>
                      <SelectItem value="Kuwait">Kuwait</SelectItem>
                      <SelectItem value="Bahrain">Bahrain</SelectItem>
                      <SelectItem value="Oman">Oman</SelectItem>
                      <SelectItem value="India">India</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="reportingRegime">Reporting Regime</Label>
                  <Select value={newClient.reportingRegime} onValueChange={(value) => setNewClient({ ...newClient, reportingRegime: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select reporting regime" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="IFRS">IFRS</SelectItem>
                      <SelectItem value="UAE">UAE GAAP</SelectItem>
                      <SelectItem value="India">Indian GAAP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="auditingStandards">Auditing Standards</Label>
                  <Select value={newClient.auditingStandards || "ISA"} onValueChange={(value) => setNewClient({ ...newClient, auditingStandards: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select auditing standards" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ISA">ISA (International Standards on Auditing)</SelectItem>
                      <SelectItem value="UAE">UAE Auditing Standards</SelectItem>
                      <SelectItem value="India">Indian Auditing Standards</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="reportingRegion">Reporting Region</Label>
                  <Select value={newClient.reportingRegion || "UAE"} onValueChange={(value) => setNewClient({ ...newClient, reportingRegion: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select reporting region" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UAE">UAE</SelectItem>
                      <SelectItem value="India">India</SelectItem>
                      <SelectItem value="International">International</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="complianceFramework">Compliance Framework</Label>
                  <Select value={newClient.complianceFramework || "UAE_IFRS"} onValueChange={(value) => setNewClient({ ...newClient, complianceFramework: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select compliance framework" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UAE_IFRS">UAE IFRS</SelectItem>
                      <SelectItem value="INDIAN_GAAP">Indian GAAP</SelectItem>
                      <SelectItem value="IFRS_INTERNATIONAL">IFRS International</SelectItem>
                      <SelectItem value="UAE_AUDITING">UAE Auditing Standards</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="preferredReportFormat">Preferred Report Format</Label>
                  <Select value={newClient.preferredReportFormat || "vertical"} onValueChange={(value) => setNewClient({ ...newClient, preferredReportFormat: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select preferred format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vertical">Vertical Format</SelectItem>
                      <SelectItem value="horizontal">Horizontal Format</SelectItem>
                      <SelectItem value="schedule_iii">Schedule III (Indian)</SelectItem>
                      <SelectItem value="custom">Custom Format</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="fiscalYearEnd">Fiscal Year End</Label>
                  <Input
                    id="fiscalYearEnd"
                    type="date"
                    value={newClient.fiscalYearEnd}
                    onChange={(e) => setNewClient({ ...newClient, fiscalYearEnd: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="contactPerson">Contact Person</Label>
                  <Input
                    id="contactPerson"
                    value={newClient.contactPerson}
                    onChange={(e) => setNewClient({ ...newClient, contactPerson: e.target.value })}
                    placeholder="Enter contact person name"
                  />
                </div>
                <div>
                  <Label htmlFor="contactEmail">Contact Email</Label>
                  <Input
                    id="contactEmail"
                    type="email"
                    value={newClient.contactEmail}
                    onChange={(e) => setNewClient({ ...newClient, contactEmail: e.target.value })}
                    placeholder="Enter contact email"
                  />
                </div>
                <div>
                  <Label htmlFor="contactPhone">Contact Phone</Label>
                  <Input
                    id="contactPhone"
                    value={newClient.contactPhone}
                    onChange={(e) => setNewClient({ ...newClient, contactPhone: e.target.value })}
                    placeholder="Enter contact phone"
                  />
                </div>
                <div className="lg:col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <Textarea
                    id="address"
                    value={newClient.address}
                    onChange={(e) => setNewClient({ ...newClient, address: e.target.value })}
                    placeholder="Enter client address"
                  />
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-2 sm:gap-0 sm:space-x-2 mt-4 lg:mt-6">
                <Button variant="outline" onClick={() => setShowAddDialog(false)} className="w-full sm:w-auto">
                  Cancel
                </Button>
                <Button onClick={handleAddClient} disabled={addClientMutation.isPending} className="w-full sm:w-auto">
                  {addClientMutation.isPending ? "Adding..." : "Add Client"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-4 lg:p-6">
        {/* Filters */}
        <div className="mb-4 lg:mb-6 flex flex-col sm:flex-row gap-3 lg:gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search clients..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 text-sm lg:text-base"
              />
            </div>
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full sm:w-[180px] text-sm lg:text-base">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Clients Grid with Scroll */}
        <div className="max-h-[calc(100vh-300px)] overflow-y-auto scrollbar-thin scroll-container pr-2">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                      <div>
                        <div className="h-4 bg-gray-200 rounded w-24 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-20"></div>
                      </div>
                    </div>
                    <div className="h-5 bg-gray-200 rounded w-16"></div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-3 bg-gray-200 rounded w-full"></div>
                    <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredClients?.map((client: any) => {
                const Icon = getIndustryIcon(client.industry);
              return (
                <Card key={client.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
                          <Icon className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{client.name}</CardTitle>
                          <p className="text-sm text-gray-500">{client.industry || 'General Business'}</p>
                        </div>
                      </div>
                      {getStatusBadge(client.status)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <p><span className="font-medium">Registration:</span> {client.registrationNumber || 'N/A'}</p>
                      <p><span className="font-medium">Jurisdiction:</span> {client.jurisdiction}</p>
                      <p><span className="font-medium">Reporting:</span> {client.reportingRegime}</p>
                      <p><span className="font-medium">Contact:</span> {client.contactPerson || 'N/A'}</p>
                    </div>
                    <div className="flex justify-end space-x-2 mt-4">
                      <Button variant="outline" size="sm" onClick={() => handleViewClient(client)}>
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleEditClient(client)}>
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
              })}
            </div>
          )}
        </div>

        {filteredClients?.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <div className="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <Building className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No clients found</h3>
            <p className="text-gray-500 mb-4">
              {searchTerm || filterStatus !== "all" 
                ? "Try adjusting your search or filters"
                : "Get started by adding your first client"
              }
            </p>
            <Button onClick={() => setShowAddDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Client
            </Button>
          </div>
        )}

        {/* View Client Dialog */}
        <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Client Details</DialogTitle>
            </DialogHeader>
            {selectedClient && (
              <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 lg:gap-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Client Name</Label>
                    <p className="text-sm">{selectedClient.name}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Industry</Label>
                    <p className="text-sm">{selectedClient.industry || 'N/A'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Registration Number</Label>
                    <p className="text-sm">{selectedClient.registrationNumber || 'N/A'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Jurisdiction</Label>
                    <p className="text-sm">{selectedClient.jurisdiction}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Reporting Regime</Label>
                    <p className="text-sm">{selectedClient.reportingRegime}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Auditing Standards</Label>
                    <p className="text-sm">{selectedClient.auditingStandards || 'ISA'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Reporting Region</Label>
                    <p className="text-sm">{selectedClient.reportingRegion || 'UAE'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Compliance Framework</Label>
                    <p className="text-sm">{selectedClient.complianceFramework || 'UAE_IFRS'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Preferred Report Format</Label>
                    <p className="text-sm">{selectedClient.preferredReportFormat || 'Vertical'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Fiscal Year End</Label>
                    <p className="text-sm">{selectedClient.fiscalYearEnd || 'N/A'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Contact Person</Label>
                    <p className="text-sm">{selectedClient.contactPerson || 'N/A'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Contact Email</Label>
                    <p className="text-sm">{selectedClient.contactEmail || 'N/A'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Contact Phone</Label>
                    <p className="text-sm">{selectedClient.contactPhone || 'N/A'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Status</Label>
                    <div className="mt-1">{getStatusBadge(selectedClient.status)}</div>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Address</Label>
                  <p className="text-sm">{selectedClient.address || 'N/A'}</p>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Edit Client Dialog */}
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Client</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 lg:gap-4 max-h-[60vh] lg:max-h-none overflow-y-auto lg:overflow-visible pr-2 lg:pr-0">
              <div>
                <Label htmlFor="editName">Client Name *</Label>
                <Input
                  id="editName"
                  value={editClient.name}
                  onChange={(e) => setEditClient({ ...editClient, name: e.target.value })}
                  placeholder="Enter client name"
                />
              </div>
              <div>
                <Label htmlFor="editIndustry">Industry</Label>
                <Select value={editClient.industry} onValueChange={(value) => setEditClient({ ...editClient, industry: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select industry" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Trading">Trading</SelectItem>
                    <SelectItem value="Manufacturing">Manufacturing</SelectItem>
                    <SelectItem value="Technology">Technology</SelectItem>
                    <SelectItem value="Healthcare">Healthcare</SelectItem>
                    <SelectItem value="Construction">Construction</SelectItem>
                    <SelectItem value="Real Estate">Real Estate</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="editRegistration">Registration Number</Label>
                <Input
                  id="editRegistration"
                  value={editClient.registrationNumber}
                  onChange={(e) => setEditClient({ ...editClient, registrationNumber: e.target.value })}
                  placeholder="Enter registration number"
                />
              </div>
              <div>
                <Label htmlFor="editJurisdiction">Jurisdiction</Label>
                <Select value={editClient.jurisdiction} onValueChange={(value) => setEditClient({ ...editClient, jurisdiction: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select jurisdiction" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UAE">UAE</SelectItem>
                    <SelectItem value="Saudi Arabia">Saudi Arabia</SelectItem>
                    <SelectItem value="Qatar">Qatar</SelectItem>
                    <SelectItem value="Kuwait">Kuwait</SelectItem>
                    <SelectItem value="Bahrain">Bahrain</SelectItem>
                    <SelectItem value="Oman">Oman</SelectItem>
                    <SelectItem value="India">India</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="editReportingRegime">Reporting Regime</Label>
                <Select value={editClient.reportingRegime} onValueChange={(value) => setEditClient({ ...editClient, reportingRegime: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select reporting regime" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="IFRS">IFRS</SelectItem>
                    <SelectItem value="UAE">UAE GAAP</SelectItem>
                    <SelectItem value="India">Indian GAAP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="editStatus">Status</Label>
                <Select value={editClient.status} onValueChange={(value) => setEditClient({ ...editClient, status: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="editFiscalYearEnd">Fiscal Year End</Label>
                <Input
                  id="editFiscalYearEnd"
                  type="date"
                  value={editClient.fiscalYearEnd}
                  onChange={(e) => setEditClient({ ...editClient, fiscalYearEnd: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="editContactPerson">Contact Person</Label>
                <Input
                  id="editContactPerson"
                  value={editClient.contactPerson}
                  onChange={(e) => setEditClient({ ...editClient, contactPerson: e.target.value })}
                  placeholder="Enter contact person name"
                />
              </div>
              <div>
                <Label htmlFor="editContactEmail">Contact Email</Label>
                <Input
                  id="editContactEmail"
                  type="email"
                  value={editClient.contactEmail}
                  onChange={(e) => setEditClient({ ...editClient, contactEmail: e.target.value })}
                  placeholder="Enter contact email"
                />
              </div>
              <div>
                <Label htmlFor="editContactPhone">Contact Phone</Label>
                <Input
                  id="editContactPhone"
                  value={editClient.contactPhone}
                  onChange={(e) => setEditClient({ ...editClient, contactPhone: e.target.value })}
                  placeholder="Enter contact phone"
                />
              </div>
              <div className="col-span-2">
                <Label htmlFor="editAddress">Address</Label>
                <Textarea
                  id="editAddress"
                  value={editClient.address}
                  onChange={(e) => setEditClient({ ...editClient, address: e.target.value })}
                  placeholder="Enter client address"
                />
              </div>
            </div>
            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={() => setShowEditDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateClient} disabled={updateClientMutation.isPending}>
                {updateClientMutation.isPending ? "Updating..." : "Update Client"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
