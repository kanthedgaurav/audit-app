import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Plus, Search, FileText, Download, Eye, BarChart3, 
  TrendingUp, AlertCircle, CheckCircle, Clock, Zap, History 
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ValidationResultsModal } from "@/components/ValidationResultsModal";

export default function FinancialStatements() {
  const [selectedClient, setSelectedClient] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState("");
  const [showGenerateDialog, setShowGenerateDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [selectedStatement, setSelectedStatement] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [newStatement, setNewStatement] = useState({
    statementType: "",
    format: "vertical",
    periodId: "",
    clientId: "",
    cashFlowMethod: "indirect", // New field for cash flow method selection
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const firmId = 1; // Static for now

  const { data: clients } = useQuery({
    queryKey: ['/api/clients', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/clients/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch clients');
      return response.json();
    },
  });

  const { data: periods } = useQuery({
    queryKey: ['/api/financial-periods', selectedClient],
    queryFn: async () => {
      if (!selectedClient) return [];
      const response = await fetch(`/api/financial-periods/${selectedClient}`);
      if (!response.ok) throw new Error('Failed to fetch periods');
      return response.json();
    },
    enabled: !!selectedClient,
  });

  const { data: statements, isLoading } = useQuery({
    queryKey: ['/api/financial-statements', selectedClient],
    queryFn: async () => {
      if (!selectedClient) return [];
      const response = await fetch(`/api/financial-statements/${selectedClient}`);
      if (!response.ok) throw new Error('Failed to fetch statements');
      return response.json();
    },
    enabled: !!selectedClient,
  });

  const validateCoaMutation = useMutation({
    mutationFn: async (clientId: number) => {
      const response = await fetch(`/api/validate-coa/${clientId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to validate Chart of Accounts');
      }
      return response.json();
    },
    onSuccess: (data) => {
      const { validationResults, clientName, totalAccounts, ifrsCompliance } = data;
      const errors = validationResults.filter((r: any) => r.status === 'error');
      const warnings = validationResults.filter((r: any) => r.status === 'warning');
      const passed = validationResults.filter((r: any) => r.status === 'passed');
      
      if (errors.length > 0) {
        toast({
          title: "❌ IFRS Validation Failed",
          description: `${clientName}: ${errors.length} critical issues found in ${totalAccounts} accounts. Status: ${ifrsCompliance}`,
          variant: "destructive",
        });
        console.group(`🔍 IFRS Validation Results for ${clientName}`);
        console.log(`📊 Total Accounts: ${totalAccounts}`);
        console.log(`✅ Passed: ${passed.length}`);
        console.log(`⚠️  Warnings: ${warnings.length}`);
        console.log(`❌ Errors: ${errors.length}`);
        console.log(`📋 Compliance Status: ${ifrsCompliance}`);
        console.log('\n🔴 Critical Issues:', errors);
        console.groupEnd();
      } else if (warnings.length > 0) {
        toast({
          title: "⚠️ IFRS Validation: Compliant with Warnings",
          description: `${clientName}: ${warnings.length} warnings, ${passed.length} checks passed. Status: ${ifrsCompliance}`,
          variant: "default",
        });
        console.group(`🔍 IFRS Validation Results for ${clientName}`);
        console.log(`📊 Total Accounts: ${totalAccounts}`);
        console.log(`✅ Passed: ${passed.length}`);
        console.log(`⚠️  Warnings: ${warnings.length}`);
        console.log(`❌ Errors: ${errors.length}`);
        console.log(`📋 Compliance Status: ${ifrsCompliance}`);
        console.log('\n🟡 Recommendations:', warnings);
        console.groupEnd();
      } else {
        toast({
          title: "✅ IFRS Validation: Fully Compliant",
          description: `${clientName}: All ${passed.length} IFRS compliance checks passed successfully. Status: ${ifrsCompliance}`,
          variant: "default",
        });
        console.group(`🔍 IFRS Validation Results for ${clientName}`);
        console.log(`📊 Total Accounts: ${totalAccounts}`);
        console.log(`✅ Passed: ${passed.length}`);
        console.log(`⚠️  Warnings: ${warnings.length}`);
        console.log(`❌ Errors: ${errors.length}`);
        console.log(`📋 Compliance Status: ${ifrsCompliance}`);
        console.log('\n🟢 All validation checks passed!');
        console.groupEnd();
      }
      
      // Show detailed breakdown in console
      console.log('\n📋 Detailed Validation Results:', validationResults);
      
      // Show alert with summary
      setTimeout(() => {
        alert(`IFRS Validation Complete!\n\nClient: ${clientName}\nTotal Accounts: ${totalAccounts}\nCompliance Status: ${ifrsCompliance}\n\nResults:\n✅ Passed: ${passed.length}\n⚠️ Warnings: ${warnings.length}\n❌ Errors: ${errors.length}\n\nCheck the browser console for detailed breakdown of all validation checks.`);
      }, 1000);
    },
    onError: (error: Error) => {
      toast({
        title: "Validation Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const generateStatementMutation = useMutation({
    mutationFn: async (statement: any) => {
      // Use the new generate-statement endpoint with format
      const response = await fetch('/api/generate-statement', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          clientId: parseInt(statement.clientId),
          periodId: parseInt(statement.periodId),
          statementType: statement.statementType,
          format: statement.format,
          cashFlowMethod: statement.cashFlowMethod
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw { message: data.message, errors: data.errors, suggestions: data.suggestions };
      }
      
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial-statements', selectedClient] });
      toast({ 
        title: "Success", 
        description: data.message || "Financial statement generated successfully" 
      });
      setShowGenerateDialog(false);
      setNewStatement({
        statementType: "",
        format: "vertical",
        periodId: "",
        clientId: "",
        cashFlowMethod: "indirect",
      });
    },
    onError: (error: any) => {
      const errorMessage = error.message || "Failed to generate financial statement";
      let description = errorMessage;
      
      if (error.suggestions && error.suggestions.length > 0) {
        description = `${errorMessage}\n\nSuggestions:\n${error.suggestions.map((s: string) => `• ${s}`).join('\n')}`;
      }
      
      toast({ 
        title: "Error", 
        description: description, 
        variant: "destructive" 
      });
    },
  });

  // Mock content generation for different statement types
  const getStatementContent = (type: string) => {
    const baseContent = {
      metadata: {
        generatedAt: new Date().toISOString(),
        regime: "IFRS",
        currency: "AED"
      }
    };

    switch (type) {
      case 'balance_sheet':
        return {
          ...baseContent,
          sections: {
            assets: {
              current: { cash: 0, receivables: 0, inventory: 0 },
              nonCurrent: { property: 0, equipment: 0, intangible: 0 }
            },
            liabilities: {
              current: { payables: 0, shortTermDebt: 0 },
              nonCurrent: { longTermDebt: 0, provisions: 0 }
            },
            equity: { capital: 0, retainedEarnings: 0 }
          }
        };
      case 'income_statement':
        return {
          ...baseContent,
          sections: {
            revenue: { sales: 0, otherIncome: 0 },
            expenses: { costOfSales: 0, operating: 0, financial: 0 },
            netIncome: 0
          }
        };
      case 'cash_flow':
        return {
          ...baseContent,
          sections: {
            operating: { netIncome: 0, adjustments: 0, workingCapital: 0 },
            investing: { capex: 0, investments: 0 },
            financing: { debt: 0, equity: 0, dividends: 0 }
          }
        };
      default:
        return baseContent;
    }
  };

  const getStatementTypeLabel = (type: string) => {
    const labels: { [key: string]: string } = {
      'balance_sheet': 'Balance Sheet',
      'income_statement': 'Income Statement',
      'cash_flow': 'Cash Flow Statement'
    };
    return labels[type] || type;
  };

  const getStatusBadge = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'final':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Final</Badge>;
      case 'completed':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'draft':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Draft</Badge>;
      case 'approved':
        return <Badge className="bg-blue-100 text-blue-800"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>;
    }
  };

  const handleGenerateStatement = () => {
    if (!selectedClient || !selectedPeriod || !newStatement.statementType) {
      toast({ title: "Error", description: "Please fill in all required fields", variant: "destructive" });
      return;
    }

    // Validate cash flow method for cash flow statements
    if (newStatement.statementType === 'cash_flow' && !newStatement.cashFlowMethod) {
      toast({ title: "Error", description: "Please select a cash flow method", variant: "destructive" });
      return;
    }

    generateStatementMutation.mutate({
      ...newStatement,
      clientId: parseInt(selectedClient),
      periodId: parseInt(selectedPeriod),
    });
  };

  const handleDownloadWorkingFile = async () => {
    if (!selectedClient || !selectedPeriod) {
      toast({
        title: "Error",
        description: "Please select a client and period first",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch(`/api/download-working-file/${selectedClient}/${selectedPeriod}`);
      
      if (!response.ok) {
        throw new Error('Failed to download working file');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `working-file-${selectedClient}-${selectedPeriod}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Success",
        description: "Working file downloaded successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download working file",
        variant: "destructive",
      });
    }
  };

  const filteredStatements = statements?.filter((statement: any) => {
    const matchesSearch = getStatementTypeLabel(statement.statementType).toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || statement.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleViewStatement = (statement: any) => {
    setSelectedStatement(statement);
    setShowViewDialog(true);
  };

  const handleDownloadStatement = (statement: any) => {
    // Generate and download the statement based on format
    const content = renderStatementContent(statement);
    if (content) {
      const formatStyles = getFormatStyles(statement.format);
      const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>${getStatementTypeLabel(statement.statementType)} - ${getFormatLabel(statement.format)}</title>
          <style>
            ${formatStyles}
          </style>
        </head>
        <body>
          <div class="statement-container">
            ${content}
          </div>
        </body>
        </html>
      `;
      
      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${getStatementTypeLabel(statement.statementType)}_${getFormatLabel(statement.format)}_${statement.id}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({ title: "Success", description: `Statement downloaded in ${getFormatLabel(statement.format)}` });
    }
  };

  const handleExportStatement = async (statement: any, format: string) => {
    try {
      const response = await fetch(`/api/financial-statements/${statement.id}/export/${format}`);
      
      if (!response.ok) {
        throw new Error('Failed to export statement');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      const fileExtension = format === 'word' ? 'docx' : format === 'excel' ? 'xlsx' : format === 'pdf' ? 'pdf' : 'html';
      a.download = `${getStatementTypeLabel(statement.statementType)}_${statement.id}.${fileExtension}`;
      
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Success",
        description: `Statement exported to ${format.toUpperCase()} format successfully`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export statement",
        variant: "destructive",
      });
    }
  };

  const getFormatLabel = (format: string) => {
    const labels: { [key: string]: string } = {
      'vertical': 'Vertical Format',
      'horizontal': 'Horizontal Format',
      'schedule_iii': 'Schedule III (Indian Companies Act)',
      'uae_standard': 'UAE Standard Format',
      'ifrs_standard': 'IFRS Standard Format',
      'custom': 'Custom Format'
    };
    return labels[format] || 'Standard Format';
  };

  const getFormatStyles = (format: string) => {
    const baseStyles = `
      body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
      .statement-container { max-width: 800px; margin: 0 auto; }
      .statement-header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #000; padding-bottom: 15px; }
      .statement-section { margin-bottom: 25px; }
      .statement-row { display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid #eee; }
      .statement-total { font-weight: bold; border-top: 2px solid #000; padding-top: 10px; margin-top: 10px; }
      .amount { text-align: right; min-width: 120px; }
      .section-title { font-weight: bold; font-size: 16px; margin-bottom: 10px; color: #000; }
      .sub-section { margin-left: 20px; margin-bottom: 15px; }
      .grand-total { font-size: 18px; font-weight: bold; border-top: 3px double #000; padding-top: 15px; }
    `;

    switch (format) {
      case 'horizontal':
        return baseStyles + `
          .statement-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; }
          .statement-section { break-inside: avoid; }
        `;
      case 'schedule_iii':
        return baseStyles + `
          .statement-header { border-bottom: 3px solid #000; }
          .section-title { text-decoration: underline; }
          .statement-row { border-bottom: none; }
          .statement-total { border-top: 3px solid #000; border-bottom: 1px solid #000; }
          .notes { margin-top: 30px; font-size: 12px; }
        `;
      case 'uae_standard':
        return baseStyles + `
          .statement-header::after { content: "\\A(Prepared in accordance with UAE Standards)"; white-space: pre; font-size: 12px; }
          .currency-note { text-align: center; font-style: italic; margin-bottom: 20px; }
        `;
      case 'ifrs_standard':
        return baseStyles + `
          .statement-header::after { content: "\\A(Prepared in accordance with IFRS)"; white-space: pre; font-size: 12px; }
          .ifrs-note { text-align: center; font-style: italic; margin-bottom: 20px; }
        `;
      case 'custom':
        return baseStyles + `
          .statement-container { border: 2px solid #4A90E2; padding: 30px; }
          .statement-header { color: #4A90E2; }
          .section-title { color: #4A90E2; }
        `;
      default:
        return baseStyles;
    }
  };

  // Render financial statement content based on type
  const renderStatementContent = (statement: any) => {
    if (!statement.content || !statement.content.sections) return null;

    const { metadata, sections } = statement.content;

    if (statement.statementType === 'balance_sheet') {
      const { assets, liabilities, equity } = sections;
      return (
        <div className="space-y-6">
          <div className="text-center border-b pb-4">
            <h3 className="text-lg font-bold">{metadata.clientName}</h3>
            <h4 className="text-md font-semibold">Balance Sheet</h4>
            <p className="text-sm text-gray-600">{metadata.period}</p>
            <p className="text-xs text-gray-500">All amounts in {metadata.currency}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Assets */}
            <div className="space-y-4">
              <h4 className="font-semibold text-lg border-b pb-2">ASSETS</h4>
              
              <div>
                <h5 className="font-medium text-md mb-2">Current Assets</h5>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Cash and Cash Equivalents</span>
                    <span>{assets.current.cash.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Trade Receivables</span>
                    <span>{assets.current.receivables.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Inventory</span>
                    <span>{assets.current.inventory.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Prepaid Expenses</span>
                    <span>{assets.current.prepaid.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-medium border-t pt-1">
                    <span>Total Current Assets</span>
                    <span>{assets.current.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div>
                <h5 className="font-medium text-md mb-2">Non-Current Assets</h5>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Property, Plant & Equipment</span>
                    <span>{assets.nonCurrent.property.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Intangible Assets</span>
                    <span>{assets.nonCurrent.intangible.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-medium border-t pt-1">
                    <span>Total Non-Current Assets</span>
                    <span>{assets.nonCurrent.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div className="border-t pt-2">
                <div className="flex justify-between font-bold text-lg">
                  <span>TOTAL ASSETS</span>
                  <span>{assets.totalAssets.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Liabilities and Equity */}
            <div className="space-y-4">
              <h4 className="font-semibold text-lg border-b pb-2">LIABILITIES & EQUITY</h4>
              
              <div>
                <h5 className="font-medium text-md mb-2">Current Liabilities</h5>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Trade Payables</span>
                    <span>{liabilities.current.payables.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Accrued Expenses</span>
                    <span>{liabilities.current.accrued.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Short-term Borrowings</span>
                    <span>{liabilities.current.shortTermDebt.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-medium border-t pt-1">
                    <span>Total Current Liabilities</span>
                    <span>{liabilities.current.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div>
                <h5 className="font-medium text-md mb-2">Non-Current Liabilities</h5>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Long-term Debt</span>
                    <span>{liabilities.nonCurrent.longTermDebt.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Provisions</span>
                    <span>{liabilities.nonCurrent.provisions.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-medium border-t pt-1">
                    <span>Total Non-Current Liabilities</span>
                    <span>{liabilities.nonCurrent.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div className="border-t pt-2">
                <div className="flex justify-between font-medium">
                  <span>Total Liabilities</span>
                  <span>{liabilities.totalLiabilities.toLocaleString()}</span>
                </div>
              </div>

              <div>
                <h5 className="font-medium text-md mb-2">Equity</h5>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Share Capital</span>
                    <span>{equity.shareCapital.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Retained Earnings</span>
                    <span>{equity.retainedEarnings.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-medium border-t pt-1">
                    <span>Total Equity</span>
                    <span>{equity.totalEquity.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div className="border-t pt-2">
                <div className="flex justify-between font-bold text-lg">
                  <span>TOTAL LIABILITIES & EQUITY</span>
                  <span>{sections.totalEquityLiabilities.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Notes to the Financial Statements */}
          {statement.content.notes && (
            <div className="mt-8 pt-6 border-t border-gray-300">
              <h4 className="font-bold text-lg mb-4">NOTES TO THE FINANCIAL STATEMENTS</h4>
              <div className="space-y-4 text-sm">
                {Object.entries(statement.content.notes).map(([key, value], index) => (
                  <div key={key} className="space-y-2">
                    <h5 className="font-semibold text-md text-blue-800">
                      {index + 1}. {key.replace(/note\d+_/, '').replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                    </h5>
                    <p className="text-gray-700 leading-relaxed pl-4">{value}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Auditor's Report */}
          {statement.content.auditorReport && (
            <div className="mt-8 pt-6 border-t border-gray-300">
              <h4 className="font-bold text-lg mb-4 text-center">{statement.content.auditorReport.reportTitle}</h4>
              <div className="space-y-4 text-sm">
                <p className="font-semibold">{statement.content.auditorReport.addressee}</p>
                
                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.opinionHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.opinionParagraph}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.opinionStatement}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.basisHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.basisParagraph}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.beliefStatement}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.keyAuditMattersHeader}</h5>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{statement.content.auditorReport.keyAuditMatters}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.managementHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.managementParagraph}</p>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.goingConcernParagraph}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.governanceParagraph}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.auditorHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.auditorObjective}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.misstatementParagraph}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">UAE SPECIFIC REQUIREMENTS</h5>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{statement.content.auditorReport.uaeRequirements}</p>
                </div>

                <div className="mt-6 pt-4 border-t border-gray-200">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{statement.content.auditorReport.signatureBlock}</p>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  <p className="text-xs text-gray-600">{statement.content.auditorReport.uaeCompliance}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      );
    } else if (statement.statementType === 'income_statement') {
      const { revenue, expenses } = sections;
      return (
        <div className="space-y-6">
          <div className="text-center border-b pb-4">
            <h3 className="text-lg font-bold">{metadata.clientName}</h3>
            <h4 className="text-md font-semibold">Income Statement</h4>
            <p className="text-sm text-gray-600">{metadata.period}</p>
            <p className="text-xs text-gray-500">All amounts in {metadata.currency}</p>
          </div>
          
          <div className="space-y-4">
            <div>
              <h5 className="font-medium text-md mb-2">Revenue</h5>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Sales Revenue</span>
                  <span>{revenue.sales.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Other Income</span>
                  <span>{revenue.otherIncome.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-medium border-t pt-1">
                  <span>Total Revenue</span>
                  <span>{revenue.totalRevenue.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div>
              <h5 className="font-medium text-md mb-2">Expenses</h5>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Cost of Sales</span>
                  <span>({expenses.costOfSales.toLocaleString()})</span>
                </div>
                <div className="flex justify-between">
                  <span>Operating Expenses</span>
                  <span>({expenses.operating.toLocaleString()})</span>
                </div>
                <div className="flex justify-between">
                  <span>Administrative Expenses</span>
                  <span>({expenses.administrative.toLocaleString()})</span>
                </div>
                <div className="flex justify-between">
                  <span>Financial Expenses</span>
                  <span>({expenses.financial.toLocaleString()})</span>
                </div>
                <div className="flex justify-between font-medium border-t pt-1">
                  <span>Total Expenses</span>
                  <span>({expenses.totalExpenses.toLocaleString()})</span>
                </div>
              </div>
            </div>

            <div className="border-t pt-2">
              <div className="flex justify-between font-medium">
                <span>Gross Profit</span>
                <span>{sections.grossProfit.toLocaleString()}</span>
              </div>
            </div>

            <div className="border-t pt-2">
              <div className="flex justify-between font-bold text-lg">
                <span>Net Income</span>
                <span className={sections.netIncome >= 0 ? 'text-green-600' : 'text-red-600'}>
                  {sections.netIncome.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Notes to the Financial Statements */}
          {statement.content.notes && (
            <div className="mt-8 pt-6 border-t border-gray-300">
              <h4 className="font-bold text-lg mb-4">NOTES TO THE FINANCIAL STATEMENTS</h4>
              <div className="space-y-4 text-sm">
                {Object.entries(statement.content.notes).map(([key, value], index) => (
                  <div key={key} className="space-y-2">
                    <h5 className="font-semibold text-md text-blue-800">
                      {index + 1}. {key.replace(/note\d+_/, '').replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                    </h5>
                    <p className="text-gray-700 leading-relaxed pl-4">{value}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Auditor's Report */}
          {statement.content.auditorReport && (
            <div className="mt-8 pt-6 border-t border-gray-300">
              <h4 className="font-bold text-lg mb-4 text-center">{statement.content.auditorReport.reportTitle}</h4>
              <div className="space-y-4 text-sm">
                <p className="font-semibold">{statement.content.auditorReport.addressee}</p>
                
                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.opinionHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.opinionParagraph}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.opinionStatement}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.basisHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.basisParagraph}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.beliefStatement}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.keyAuditMattersHeader}</h5>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{statement.content.auditorReport.keyAuditMatters}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.managementHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.managementParagraph}</p>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.goingConcernParagraph}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.governanceParagraph}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.auditorHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.auditorObjective}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.misstatementParagraph}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">UAE SPECIFIC REQUIREMENTS</h5>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{statement.content.auditorReport.uaeRequirements}</p>
                </div>

                <div className="mt-6 pt-4 border-t border-gray-200">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{statement.content.auditorReport.signatureBlock}</p>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  <p className="text-xs text-gray-600">{statement.content.auditorReport.uaeCompliance}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      );
    } else if (statement.statementType === 'cash_flow') {
      const { operating, investing, financing } = sections;
      const isDirectMethod = statement.content?.metadata?.cashFlowMethod === 'direct';
      
      return (
        <div className="space-y-6">
          <div className="text-center border-b pb-4">
            <h3 className="text-lg font-bold">{metadata.clientName}</h3>
            <h4 className="text-md font-semibold">Cash Flow Statement</h4>
            <p className="text-sm text-gray-600">{metadata.period}</p>
            <p className="text-xs text-gray-500">All amounts in {metadata.currency}</p>
            <p className="text-xs text-blue-600 font-medium mt-1">
              Prepared using the {isDirectMethod ? 'Direct' : 'Indirect'} Method
            </p>
          </div>
          
          <div className="space-y-6">
            {/* Operating Activities */}
            <div>
              <h5 className="font-medium text-md mb-3 text-blue-700">
                Operating Activities ({isDirectMethod ? 'Direct Method' : 'Indirect Method'})
              </h5>
              <div className="space-y-2 text-sm">
                {isDirectMethod ? (
                  <>
                    <div className="font-medium text-gray-700 mb-2">Cash Receipts:</div>
                    <div className="flex justify-between ml-4">
                      <span>From customers</span>
                      <span>{(operating?.cashReceipts?.fromCustomers || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>From interest</span>
                      <span>{(operating?.cashReceipts?.fromInterest || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>From other operating activities</span>
                      <span>{(operating?.cashReceipts?.fromOtherOperating || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4 font-medium border-t pt-1">
                      <span>Total Cash Receipts</span>
                      <span>{(operating?.cashReceipts?.total || 0).toLocaleString()}</span>
                    </div>
                    
                    <div className="font-medium text-gray-700 mb-2 mt-4">Cash Payments:</div>
                    <div className="flex justify-between ml-4">
                      <span>To suppliers</span>
                      <span>({Math.abs(operating?.cashPayments?.toSuppliers || 0).toLocaleString()})</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>To employees</span>
                      <span>({Math.abs(operating?.cashPayments?.toEmployees || 0).toLocaleString()})</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>For operating expenses</span>
                      <span>({Math.abs(operating?.cashPayments?.forOperatingExpenses || 0).toLocaleString()})</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>For interest</span>
                      <span>({Math.abs(operating?.cashPayments?.forInterest || 0).toLocaleString()})</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>For taxes</span>
                      <span>({Math.abs(operating?.cashPayments?.forTaxes || 0).toLocaleString()})</span>
                    </div>
                    <div className="flex justify-between ml-4 font-medium border-t pt-1">
                      <span>Total Cash Payments</span>
                      <span>({Math.abs(operating?.cashPayments?.total || 0).toLocaleString()})</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between">
                      <span>Net Income</span>
                      <span>{(operating?.netIncome || 0).toLocaleString()}</span>
                    </div>
                    
                    <div className="font-medium text-gray-700 mb-2 mt-4">Adjustments for non-cash items:</div>
                    <div className="flex justify-between ml-4">
                      <span>Depreciation</span>
                      <span>{(operating?.adjustments?.depreciation || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>Amortization</span>
                      <span>{(operating?.adjustments?.amortization || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>Bad debt expense</span>
                      <span>{(operating?.adjustments?.badDebtExpense || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>Gain on sale of assets</span>
                      <span>{(operating?.adjustments?.gainOnSaleOfAssets || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>Loss on sale of assets</span>
                      <span>{(operating?.adjustments?.lossOnSaleOfAssets || 0).toLocaleString()}</span>
                    </div>
                    
                    <div className="font-medium text-gray-700 mb-2 mt-4">Changes in working capital:</div>
                    <div className="flex justify-between ml-4">
                      <span>Receivables</span>
                      <span>{(operating?.workingCapitalChanges?.receivables || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>Inventory</span>
                      <span>{(operating?.workingCapitalChanges?.inventory || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>Prepaid expenses</span>
                      <span>{(operating?.workingCapitalChanges?.prepaidExpenses || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>Payables</span>
                      <span>{(operating?.workingCapitalChanges?.payables || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>Accrued expenses</span>
                      <span>{(operating?.workingCapitalChanges?.accruedExpenses || 0).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between ml-4">
                      <span>Deferred revenue</span>
                      <span>{(operating?.workingCapitalChanges?.deferredRevenue || 0).toLocaleString()}</span>
                    </div>
                  </>
                )}
                
                <div className="flex justify-between font-medium border-t pt-2 text-blue-700">
                  <span>Net Cash from Operating Activities</span>
                  <span>{(operating?.totalOperating || 0).toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Investing Activities */}
            <div>
              <h5 className="font-medium text-md mb-3 text-green-700">Investing Activities</h5>
              <div className="space-y-2 text-sm">
                <div className="font-medium text-gray-700 mb-2">Cash Receipts:</div>
                <div className="flex justify-between ml-4">
                  <span>From sale of assets</span>
                  <span>{(investing?.cashReceipts?.fromSaleOfAssets || 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between ml-4">
                  <span>From investments</span>
                  <span>{(investing?.cashReceipts?.fromInvestments || 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between ml-4 font-medium border-t pt-1">
                  <span>Total Cash Receipts</span>
                  <span>{(investing?.cashReceipts?.total || 0).toLocaleString()}</span>
                </div>
                
                <div className="font-medium text-gray-700 mb-2 mt-4">Cash Payments:</div>
                <div className="flex justify-between ml-4">
                  <span>For property purchases</span>
                  <span>({Math.abs(investing?.cashPayments?.forPropertyPurchases || 0).toLocaleString()})</span>
                </div>
                <div className="flex justify-between ml-4">
                  <span>For equipment purchases</span>
                  <span>({Math.abs(investing?.cashPayments?.forEquipmentPurchases || 0).toLocaleString()})</span>
                </div>
                <div className="flex justify-between ml-4">
                  <span>For intangible assets</span>
                  <span>({Math.abs(investing?.cashPayments?.forIntangibleAssets || 0).toLocaleString()})</span>
                </div>
                <div className="flex justify-between ml-4">
                  <span>For investments</span>
                  <span>({Math.abs(investing?.cashPayments?.forInvestments || 0).toLocaleString()})</span>
                </div>
                <div className="flex justify-between ml-4 font-medium border-t pt-1">
                  <span>Total Cash Payments</span>
                  <span>({Math.abs(investing?.cashPayments?.total || 0).toLocaleString()})</span>
                </div>
                
                <div className="flex justify-between font-medium border-t pt-2 text-green-700">
                  <span>Net Cash from Investing Activities</span>
                  <span>{(investing?.totalInvesting || 0).toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Financing Activities */}
            <div>
              <h5 className="font-medium text-md mb-3 text-purple-700">Financing Activities</h5>
              <div className="space-y-2 text-sm">
                <div className="font-medium text-gray-700 mb-2">Cash Receipts:</div>
                <div className="flex justify-between ml-4">
                  <span>From borrowings</span>
                  <span>{(financing?.cashReceipts?.fromBorrowings || 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between ml-4">
                  <span>From equity issuance</span>
                  <span>{(financing?.cashReceipts?.fromEquityIssuance || 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between ml-4 font-medium border-t pt-1">
                  <span>Total Cash Receipts</span>
                  <span>{(financing?.cashReceipts?.total || 0).toLocaleString()}</span>
                </div>
                
                <div className="font-medium text-gray-700 mb-2 mt-4">Cash Payments:</div>
                <div className="flex justify-between ml-4">
                  <span>For loan repayments</span>
                  <span>({Math.abs(financing?.cashPayments?.forLoanRepayments || 0).toLocaleString()})</span>
                </div>
                <div className="flex justify-between ml-4">
                  <span>For dividends</span>
                  <span>({Math.abs(financing?.cashPayments?.forDividends || 0).toLocaleString()})</span>
                </div>
                <div className="flex justify-between ml-4">
                  <span>For share repurchases</span>
                  <span>({Math.abs(financing?.cashPayments?.forShareRepurchases || 0).toLocaleString()})</span>
                </div>
                <div className="flex justify-between ml-4 font-medium border-t pt-1">
                  <span>Total Cash Payments</span>
                  <span>({Math.abs(financing?.cashPayments?.total || 0).toLocaleString()})</span>
                </div>
                
                <div className="flex justify-between font-medium border-t pt-2 text-purple-700">
                  <span>Net Cash from Financing Activities</span>
                  <span>{(financing?.totalFinancing || 0).toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Cash Flow Summary */}
            <div className="border-t-2 border-gray-300 pt-4">
              <h5 className="font-medium text-md mb-3 text-gray-800">Cash Flow Summary</h5>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Net Change in Cash</span>
                  <span className={sections.netCashFlow >= 0 ? 'text-green-600' : 'text-red-600'}>
                    {(sections.netCashFlow || 0).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Cash at Beginning of Year</span>
                  <span>{(sections.beginningCash || 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>Cash at End of Year</span>
                  <span className={sections.endingCash >= 0 ? 'text-green-600' : 'text-red-600'}>
                    {(sections.endingCash || 0).toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Notes to the Financial Statements */}
          {statement.content.notes && (
            <div className="mt-8 pt-6 border-t border-gray-300">
              <h4 className="font-bold text-lg mb-4">NOTES TO THE FINANCIAL STATEMENTS</h4>
              <div className="space-y-4 text-sm">
                {Object.entries(statement.content.notes).map(([key, value], index) => (
                  <div key={key} className="space-y-2">
                    <h5 className="font-semibold text-md text-blue-800">
                      {index + 1}. {key.replace(/note\d+_/, '').replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                    </h5>
                    <p className="text-gray-700 leading-relaxed pl-4">{value}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Auditor's Report */}
          {statement.content.auditorReport && (
            <div className="mt-8 pt-6 border-t border-gray-300">
              <h4 className="font-bold text-lg mb-4 text-center">{statement.content.auditorReport.reportTitle}</h4>
              <div className="space-y-4 text-sm">
                <p className="font-semibold">{statement.content.auditorReport.addressee}</p>
                
                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.opinionHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.opinionParagraph}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.opinionStatement}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.basisHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.basisParagraph}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.beliefStatement}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.keyAuditMattersHeader}</h5>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{statement.content.auditorReport.keyAuditMatters}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.managementHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.managementParagraph}</p>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.goingConcernParagraph}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.governanceParagraph}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">{statement.content.auditorReport.auditorHeader}</h5>
                  <p className="text-gray-700 leading-relaxed mb-2">{statement.content.auditorReport.auditorObjective}</p>
                  <p className="text-gray-700 leading-relaxed">{statement.content.auditorReport.misstatementParagraph}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-md mb-2">UAE SPECIFIC REQUIREMENTS</h5>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{statement.content.auditorReport.uaeRequirements}</p>
                </div>

                <div className="mt-6 pt-4 border-t border-gray-200">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{statement.content.auditorReport.signatureBlock}</p>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  <p className="text-xs text-gray-600">{statement.content.auditorReport.uaeCompliance}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      );
    }

    return null;
  };

  return (
    <div className="flex-1">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 lg:px-6 py-4 pt-16 lg:pt-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl lg:text-2xl font-bold text-gray-900">Financial Statements</h2>
            <p className="text-sm text-gray-500">Generate and manage IFRS-compliant financial statements</p>
          </div>
          <div className="flex items-center space-x-2 lg:space-x-3">
            <Button 
              variant="outline" 
              onClick={() => selectedClient && validateCoaMutation.mutate(parseInt(selectedClient))}
              disabled={!selectedClient || validateCoaMutation.isPending}
              className="text-xs lg:text-sm px-2 lg:px-4"
            >
              <CheckCircle className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
              <span className="hidden sm:inline">
                {validateCoaMutation.isPending ? "Validating..." : "Validate COA"}
              </span>
              <span className="sm:hidden">
                {validateCoaMutation.isPending ? "Val..." : "Validate"}
              </span>
            </Button>
            
            <ValidationResultsModal
              clientId={selectedClient ? parseInt(selectedClient) : 0}
              clientName={clients?.find(c => c.id === parseInt(selectedClient))?.name || ""}
              trigger={
                <Button 
                  variant="outline" 
                  disabled={!selectedClient}
                  className="text-xs lg:text-sm px-2 lg:px-4"
                >
                  <History className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                  <span className="hidden sm:inline">View Details</span>
                  <span className="sm:hidden">Details</span>
                </Button>
              }
            />
            <Button variant="outline" onClick={handleDownloadWorkingFile} className="text-xs lg:text-sm px-2 lg:px-4">
              <Download className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
              <span className="hidden sm:inline">Download Working File</span>
              <span className="sm:hidden">Download</span>
            </Button>
            <Dialog open={showGenerateDialog} onOpenChange={setShowGenerateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-primary text-white hover:bg-primary-dark text-xs lg:text-sm px-2 lg:px-4" disabled={generateStatementMutation.isPending}>
                  <Zap className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                  <span className="hidden sm:inline">{generateStatementMutation.isPending ? "Generating..." : "Generate Statement"}</span>
                  <span className="sm:hidden">{generateStatementMutation.isPending ? "Gen..." : "Generate"}</span>
                </Button>
              </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Generate Financial Statement</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="client">Client *</Label>
                  <Select value={selectedClient} onValueChange={setSelectedClient}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select client" />
                    </SelectTrigger>
                    <SelectContent>
                      {clients?.map((client: any) => (
                        <SelectItem key={client.id} value={client.id.toString()}>
                          {client.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="period">Financial Period *</Label>
                  <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select period" />
                    </SelectTrigger>
                    <SelectContent>
                      {periods?.map((period: any) => (
                        <SelectItem key={period.id} value={period.id.toString()}>
                          {period.description || `${period.startDate} to ${period.endDate}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="statementType">Statement Type *</Label>
                  <Select 
                    value={newStatement.statementType} 
                    onValueChange={(value) => setNewStatement({ ...newStatement, statementType: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select statement type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="balance_sheet">Balance Sheet</SelectItem>
                      <SelectItem value="income_statement">Income Statement</SelectItem>
                      <SelectItem value="cash_flow">Cash Flow Statement</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="format">Reporting Format *</Label>
                  <Select 
                    value={newStatement.format} 
                    onValueChange={(value) => setNewStatement({ ...newStatement, format: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select reporting format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vertical">Vertical Format</SelectItem>
                      <SelectItem value="horizontal">Horizontal Format</SelectItem>
                      <SelectItem value="schedule_iii">Schedule III (Indian Companies Act)</SelectItem>
                      <SelectItem value="uae_standard">UAE Standard Format</SelectItem>
                      <SelectItem value="ifrs_standard">IFRS Standard Format</SelectItem>
                      <SelectItem value="custom">Custom Format</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {/* Cash Flow Method Selection - Only show for cash flow statements */}
                {newStatement.statementType === 'cash_flow' && (
                  <div>
                    <Label htmlFor="cashFlowMethod">Cash Flow Method *</Label>
                    <Select 
                      value={newStatement.cashFlowMethod} 
                      onValueChange={(value) => setNewStatement({ ...newStatement, cashFlowMethod: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select cash flow method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="indirect">Indirect Method</SelectItem>
                        <SelectItem value="direct">Direct Method</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-gray-500 mt-1">
                      {newStatement.cashFlowMethod === 'indirect' 
                        ? 'Starts with net income and adjusts for non-cash items (most common)' 
                        : 'Shows actual cash receipts and payments from operating activities'}
                    </p>
                  </div>
                )}
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button variant="outline" onClick={() => setShowGenerateDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleGenerateStatement} disabled={generateStatementMutation.isPending}>
                  {generateStatementMutation.isPending ? "Generating..." : "Generate"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-4 lg:p-6">
        <div className="space-y-4 lg:space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-6">
            <Card>
              <CardContent className="p-3 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs lg:text-sm font-medium text-gray-600">Total Statements</p>
                    <p className="text-lg lg:text-2xl font-bold text-gray-900">{statements?.length || 0}</p>
                  </div>
                  <FileText className="w-6 h-6 lg:w-8 lg:h-8 text-primary" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs lg:text-sm font-medium text-gray-600">Final Statements</p>
                    <p className="text-lg lg:text-2xl font-bold text-gray-900">
                      {statements?.filter((s: any) => s.status === 'final').length || 0}
                    </p>
                  </div>
                  <CheckCircle className="w-6 h-6 lg:w-8 lg:h-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs lg:text-sm font-medium text-gray-600">Draft Statements</p>
                    <p className="text-lg lg:text-2xl font-bold text-gray-900">
                      {statements?.filter((s: any) => s.status === 'draft').length || 0}
                    </p>
                  </div>
                  <Clock className="w-6 h-6 lg:w-8 lg:h-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs lg:text-sm font-medium text-gray-600">This Month</p>
                    <p className="text-lg lg:text-2xl font-bold text-gray-900">
                      {statements?.filter((s: any) => 
                        new Date(s.generatedAt).getMonth() === new Date().getMonth()
                      ).length || 0}
                    </p>
                  </div>
                  <TrendingUp className="w-6 h-6 lg:w-8 lg:h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Client Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select Client</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-4">
                <div className="flex-1">
                  <Label htmlFor="clientSelect">Client</Label>
                  <Select value={selectedClient} onValueChange={setSelectedClient}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a client to view statements" />
                    </SelectTrigger>
                    <SelectContent>
                      {clients?.map((client: any) => (
                        <SelectItem key={client.id} value={client.id.toString()}>
                          {client.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {selectedClient && (
                  <div className="flex-1">
                    <Label htmlFor="periodSelect">Period (for new statements)</Label>
                    <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select period" />
                      </SelectTrigger>
                      <SelectContent>
                        {periods?.map((period: any) => (
                          <SelectItem key={period.id} value={period.id.toString()}>
                            {period.description || `${period.startDate} to ${period.endDate}`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {selectedClient && (
            <>
              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search statements..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="final">Final</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Statements List */}
              <Card>
                <CardHeader>
                  <CardTitle>Financial Statements</CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg animate-pulse">
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                            <div className="space-y-2">
                              <div className="h-4 bg-gray-200 rounded w-32"></div>
                              <div className="h-3 bg-gray-200 rounded w-24"></div>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <div className="h-5 bg-gray-200 rounded w-16"></div>
                            <div className="h-3 bg-gray-200 rounded w-20"></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : filteredStatements?.length === 0 ? (
                    <div className="text-center py-12">
                      <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No Financial Statements</h3>
                      <p className="text-gray-500 mb-4">
                        {searchTerm || filterStatus !== "all" 
                          ? "No statements match your current filters"
                          : "No financial statements have been generated for this client yet"
                        }
                      </p>
                      <Button onClick={() => setShowGenerateDialog(true)}>
                        <Zap className="w-4 h-4 mr-2" />
                        Generate First Statement
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredStatements?.map((statement: any) => (
                        <div key={statement.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
                              <FileText className="w-6 h-6 text-primary" />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">
                                {getStatementTypeLabel(statement.statementType)}
                              </p>
                              <p className="text-sm text-gray-500">
                                {getFormatLabel(statement.format)} • Generated {format(new Date(statement.generatedAt), 'MMM d, yyyy')}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-4">
                            {getStatusBadge(statement.status)}
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleViewStatement(statement)}
                              >
                                <Eye className="w-4 h-4 mr-1" />
                                View
                              </Button>
                              <div className="flex space-x-1">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleExportStatement(statement, 'html')}
                                >
                                  <Download className="w-4 h-4 mr-1" />
                                  HTML
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleExportStatement(statement, 'word')}
                                >
                                  Word
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleExportStatement(statement, 'excel')}
                                >
                                  Excel
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleExportStatement(statement, 'pdf')}
                                >
                                  PDF
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}

          {/* AI Features Notice */}
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>AI-Powered Features:</strong> Our system automatically generates IFRS-compliant financial statements 
              from your uploaded trial balance data. The AI engine maps accounts, applies necessary adjustments, 
              and creates professional reports ready for review and finalization.
            </AlertDescription>
          </Alert>
        </div>
      </main>

      {/* View Statement Dialog */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedStatement ? getStatementTypeLabel(selectedStatement.statementType) : 'Financial Statement'}
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            {selectedStatement && renderStatementContent(selectedStatement)}
          </div>
          <div className="flex justify-end space-x-2 mt-6">
            <Button variant="outline" onClick={() => setShowViewDialog(false)}>
              Close
            </Button>
            <Button onClick={() => selectedStatement && handleDownloadStatement(selectedStatement)}>
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
