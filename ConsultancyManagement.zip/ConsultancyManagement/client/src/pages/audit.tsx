import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { 
  Plus, Search, Shield, Calendar, AlertTriangle, CheckCircle, 
  Clock, FileText, Users, Target, TrendingUp, Eye, Edit, User
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, differenceInDays } from "date-fns";

export default function Audit() {
  const [selectedClient, setSelectedClient] = useState("");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showFindingDialog, setShowFindingDialog] = useState(false);
  const [selectedEngagement, setSelectedEngagement] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [newEngagement, setNewEngagement] = useState({
    engagementType: "",
    startDate: "",
    endDate: "",
    scope: "",
    objectives: "",
    riskLevel: "medium",
    leadAuditor: "",
    seniorManager: "",
    teamMembers: []
  });
  
  const [newTeamMember, setNewTeamMember] = useState({
    name: "",
    role: "",
    responsibilities: "",
    email: ""
  });
  const [newFinding, setNewFinding] = useState({
    finding: "",
    riskLevel: "medium",
    recommendation: "",
    dueDate: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const firmId = 1; // Static for now

  const { data: clients } = useQuery({
    queryKey: ['/api/clients', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/clients/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch clients');
      return response.json();
    },
  });

  const { data: engagements, isLoading } = useQuery({
    queryKey: ['/api/audit-engagements', selectedClient],
    queryFn: async () => {
      if (!selectedClient) return [];
      const response = await fetch(`/api/audit-engagements/${selectedClient}`);
      if (!response.ok) throw new Error('Failed to fetch engagements');
      return response.json();
    },
    enabled: !!selectedClient,
  });

  const { data: findings } = useQuery({
    queryKey: ['/api/audit-findings', selectedEngagement],
    queryFn: async () => {
      if (!selectedEngagement) return [];
      const response = await fetch(`/api/audit-findings/${selectedEngagement}`);
      if (!response.ok) throw new Error('Failed to fetch findings');
      return response.json();
    },
    enabled: !!selectedEngagement,
  });

  const createEngagementMutation = useMutation({
    mutationFn: async (engagement: any) => {
      await apiRequest('POST', '/api/audit-engagements', { 
        ...engagement, 
        clientId: parseInt(selectedClient),
        leadAuditor: 1 // Static user ID
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/audit-engagements', selectedClient] });
      toast({ title: "Success", description: "Audit engagement created successfully" });
      setShowCreateDialog(false);
      setNewEngagement({
        engagementType: "",
        startDate: "",
        endDate: "",
        scope: "",
        objectives: "",
        riskLevel: "medium",
        leadAuditor: "",
        seniorManager: "",
        teamMembers: []
      });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to create audit engagement", variant: "destructive" });
    },
  });

  const createFindingMutation = useMutation({
    mutationFn: async (finding: any) => {
      await apiRequest('POST', '/api/audit-findings', { 
        ...finding, 
        engagementId: parseInt(selectedEngagement)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/audit-findings', selectedEngagement] });
      toast({ title: "Success", description: "Audit finding added successfully" });
      setShowFindingDialog(false);
      setNewFinding({
        finding: "",
        riskLevel: "medium",
        recommendation: "",
        dueDate: ""
      });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to add audit finding", variant: "destructive" });
    },
  });

  const getEngagementTypeLabel = (type: string) => {
    const labels: { [key: string]: string } = {
      'internal_audit': 'Internal Audit',
      'external_audit': 'External Audit',
      'icofr': 'ICOFR Review'
    };
    return labels[type] || type;
  };

  const getStatusBadge = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'in_progress':
        return <Badge className="bg-blue-100 text-blue-800"><Clock className="w-3 h-3 mr-1" />In Progress</Badge>;
      case 'planned':
        return <Badge className="bg-yellow-100 text-yellow-800"><Calendar className="w-3 h-3 mr-1" />Planned</Badge>;
      case 'cancelled':
        return <Badge className="bg-gray-100 text-gray-800">Cancelled</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>;
    }
  };

  const getRiskBadge = (risk: string) => {
    switch (risk?.toLowerCase()) {
      case 'high':
        return <Badge className="bg-red-100 text-red-800">High Risk</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-100 text-yellow-800">Medium Risk</Badge>;
      case 'low':
        return <Badge className="bg-green-100 text-green-800">Low Risk</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>;
    }
  };

  const getProgressPercentage = (engagement: any) => {
    if (engagement.status === 'completed') return 100;
    if (engagement.status === 'in_progress') {
      const total = differenceInDays(new Date(engagement.endDate), new Date(engagement.startDate));
      const elapsed = differenceInDays(new Date(), new Date(engagement.startDate));
      return Math.min(Math.max((elapsed / total) * 100, 0), 100);
    }
    return 0;
  };

  const handleCreateEngagement = () => {
    if (!selectedClient || !newEngagement.engagementType || !newEngagement.startDate) {
      toast({ title: "Error", description: "Please fill in all required fields", variant: "destructive" });
      return;
    }
    createEngagementMutation.mutate(newEngagement);
  };

  const handleCreateFinding = () => {
    if (!selectedEngagement || !newFinding.finding) {
      toast({ title: "Error", description: "Please fill in all required fields", variant: "destructive" });
      return;
    }
    createFindingMutation.mutate(newFinding);
  };

  const handleAddTeamMember = () => {
    if (!newTeamMember.name || !newTeamMember.role) {
      toast({ title: "Error", description: "Please enter team member name and role", variant: "destructive" });
      return;
    }
    
    setNewEngagement(prev => ({
      ...prev,
      teamMembers: [...prev.teamMembers, { ...newTeamMember }]
    }));
    
    setNewTeamMember({ name: "", role: "", responsibilities: "", email: "" });
  };

  const handleRemoveTeamMember = (index: number) => {
    setNewEngagement(prev => ({
      ...prev,
      teamMembers: prev.teamMembers.filter((_, i) => i !== index)
    }));
  };

  const filteredEngagements = engagements?.filter((engagement: any) => {
    const matchesSearch = getEngagementTypeLabel(engagement.engagementType).toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || engagement.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="flex-1">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 lg:px-6 py-4 pt-16 lg:pt-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl lg:text-2xl font-bold text-gray-900">Internal Audit & ICOFR</h2>
            <p className="text-sm text-gray-500">Manage audit engagements and internal control assessments</p>
          </div>
          <div className="flex space-x-2">
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-primary text-white hover:bg-primary-dark text-xs lg:text-sm px-2 lg:px-4">
                  <Plus className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                  <span className="hidden sm:inline">New Engagement</span>
                  <span className="sm:hidden">New</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create Audit Engagement</DialogTitle>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label htmlFor="client">Client *</Label>
                    <Select value={selectedClient} onValueChange={setSelectedClient}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select client" />
                      </SelectTrigger>
                      <SelectContent>
                        {clients?.map((client: any) => (
                          <SelectItem key={client.id} value={client.id.toString()}>
                            {client.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="engagementType">Engagement Type *</Label>
                    <Select 
                      value={newEngagement.engagementType} 
                      onValueChange={(value) => setNewEngagement({ ...newEngagement, engagementType: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="internal_audit">Internal Audit</SelectItem>
                        <SelectItem value="external_audit">External Audit</SelectItem>
                        <SelectItem value="icofr">ICOFR Review</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="riskLevel">Risk Level</Label>
                    <Select 
                      value={newEngagement.riskLevel} 
                      onValueChange={(value) => setNewEngagement({ ...newEngagement, riskLevel: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select risk level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="startDate">Start Date *</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={newEngagement.startDate}
                      onChange={(e) => setNewEngagement({ ...newEngagement, startDate: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="endDate">End Date</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={newEngagement.endDate}
                      onChange={(e) => setNewEngagement({ ...newEngagement, endDate: e.target.value })}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="scope">Audit Scope</Label>
                    <Textarea
                      id="scope"
                      value={newEngagement.scope}
                      onChange={(e) => setNewEngagement({ ...newEngagement, scope: e.target.value })}
                      placeholder="Define the scope of the audit engagement"
                    />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="objectives">Objectives</Label>
                    <Textarea
                      id="objectives"
                      value={newEngagement.objectives}
                      onChange={(e) => setNewEngagement({ ...newEngagement, objectives: e.target.value })}
                      placeholder="Define the objectives and goals of this engagement"
                    />
                  </div>

                  {/* Senior Manager and Team Members Section */}
                  <div className="col-span-2">
                    <Label htmlFor="seniorManager">Senior Manager</Label>
                    <Input
                      id="seniorManager"
                      value={newEngagement.seniorManager}
                      onChange={(e) => setNewEngagement({ ...newEngagement, seniorManager: e.target.value })}
                      placeholder="Enter senior manager name"
                    />
                  </div>

                  <div className="col-span-2">
                    <Label>Team Members</Label>
                    
                    {/* Current Team Members */}
                    {newEngagement.teamMembers.length > 0 && (
                      <div className="mb-4 space-y-2">
                        {newEngagement.teamMembers.map((member, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex-1">
                              <div className="font-medium">{member.name}</div>
                              <div className="text-sm text-gray-600">{member.role}</div>
                              {member.responsibilities && (
                                <div className="text-sm text-gray-500">{member.responsibilities}</div>
                              )}
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemoveTeamMember(index)}
                              className="text-red-600 hover:text-red-700"
                            >
                              Remove
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Add New Team Member */}
                    <div className="border rounded-lg p-4 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label htmlFor="memberName">Name *</Label>
                          <Input
                            id="memberName"
                            value={newTeamMember.name}
                            onChange={(e) => setNewTeamMember({ ...newTeamMember, name: e.target.value })}
                            placeholder="Employee name"
                          />
                        </div>
                        <div>
                          <Label htmlFor="memberRole">Role *</Label>
                          <Select
                            value={newTeamMember.role}
                            onValueChange={(value) => setNewTeamMember({ ...newTeamMember, role: value })}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select role" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="audit_manager">Audit Manager</SelectItem>
                              <SelectItem value="senior_auditor">Senior Auditor</SelectItem>
                              <SelectItem value="junior_auditor">Junior Auditor</SelectItem>
                              <SelectItem value="it_auditor">IT Auditor</SelectItem>
                              <SelectItem value="compliance_officer">Compliance Officer</SelectItem>
                              <SelectItem value="risk_analyst">Risk Analyst</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="memberEmail">Email</Label>
                        <Input
                          id="memberEmail"
                          type="email"
                          value={newTeamMember.email}
                          onChange={(e) => setNewTeamMember({ ...newTeamMember, email: e.target.value })}
                          placeholder="employee@company.com"
                        />
                      </div>
                      <div>
                        <Label htmlFor="memberResponsibilities">Responsibilities</Label>
                        <Textarea
                          id="memberResponsibilities"
                          value={newTeamMember.responsibilities}
                          onChange={(e) => setNewTeamMember({ ...newTeamMember, responsibilities: e.target.value })}
                          placeholder="Describe specific responsibilities for this engagement"
                          rows={2}
                        />
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handleAddTeamMember}
                        className="w-full"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Team Member
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="flex justify-end space-x-2 mt-6">
                  <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateEngagement} disabled={createEngagementMutation.isPending}>
                    {createEngagementMutation.isPending ? "Creating..." : "Create Engagement"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            
            {selectedEngagement && (
              <Dialog open={showFindingDialog} onOpenChange={setShowFindingDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Add Finding
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Add Audit Finding</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="finding">Finding Description *</Label>
                      <Textarea
                        id="finding"
                        value={newFinding.finding}
                        onChange={(e) => setNewFinding({ ...newFinding, finding: e.target.value })}
                        placeholder="Describe the audit finding"
                      />
                    </div>
                    <div>
                      <Label htmlFor="riskLevel">Risk Level</Label>
                      <Select 
                        value={newFinding.riskLevel} 
                        onValueChange={(value) => setNewFinding({ ...newFinding, riskLevel: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select risk level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="recommendation">Recommendation</Label>
                      <Textarea
                        id="recommendation"
                        value={newFinding.recommendation}
                        onChange={(e) => setNewFinding({ ...newFinding, recommendation: e.target.value })}
                        placeholder="Recommended actions to address this finding"
                      />
                    </div>
                    <div>
                      <Label htmlFor="dueDate">Due Date</Label>
                      <Input
                        id="dueDate"
                        type="date"
                        value={newFinding.dueDate}
                        onChange={(e) => setNewFinding({ ...newFinding, dueDate: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2 mt-6">
                    <Button variant="outline" onClick={() => setShowFindingDialog(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleCreateFinding} disabled={createFindingMutation.isPending}>
                      {createFindingMutation.isPending ? "Adding..." : "Add Finding"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-4 lg:p-6">
        <div className="space-y-4 lg:space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-6">
            <Card className="p-3 lg:p-4">
              <CardContent className="p-0">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs lg:text-sm font-medium text-gray-600">Total Engagements</p>
                    <p className="text-lg lg:text-2xl font-bold text-gray-900">{engagements?.length || 0}</p>
                  </div>
                  <Shield className="w-5 h-5 lg:w-8 lg:h-8 text-primary" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">In Progress</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {engagements?.filter((e: any) => e.status === 'in_progress').length || 0}
                    </p>
                  </div>
                  <Clock className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Completed</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {engagements?.filter((e: any) => e.status === 'completed').length || 0}
                    </p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">High Risk</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {engagements?.filter((e: any) => e.riskLevel === 'high').length || 0}
                    </p>
                  </div>
                  <AlertTriangle className="w-8 h-8 text-red-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Client Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select Client</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="w-full max-w-md">
                <Label htmlFor="clientSelect">Client</Label>
                <Select value={selectedClient} onValueChange={setSelectedClient}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a client to view audit engagements" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients?.map((client: any) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {selectedClient && (
            <Tabs defaultValue="engagements" className="space-y-6">
              <TabsList>
                <TabsTrigger value="engagements">Audit Engagements</TabsTrigger>
                <TabsTrigger value="findings">Audit Findings</TabsTrigger>
              </TabsList>

              <TabsContent value="engagements" className="space-y-6">
                {/* Filters */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Search engagements..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="planned">Planned</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Engagements List */}
                <Card>
                  <CardContent className="p-6">
                    {isLoading ? (
                      <div className="space-y-4">
                        {[1, 2, 3].map((i) => (
                          <div key={i} className="p-4 border border-gray-200 rounded-lg animate-pulse">
                            <div className="flex items-center justify-between mb-4">
                              <div className="space-y-2">
                                <div className="h-4 bg-gray-200 rounded w-32"></div>
                                <div className="h-3 bg-gray-200 rounded w-24"></div>
                              </div>
                              <div className="h-5 bg-gray-200 rounded w-20"></div>
                            </div>
                            <div className="h-2 bg-gray-200 rounded w-full"></div>
                          </div>
                        ))}
                      </div>
                    ) : filteredEngagements?.length === 0 ? (
                      <div className="text-center py-12">
                        <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No Audit Engagements</h3>
                        <p className="text-gray-500 mb-4">
                          {searchTerm || filterStatus !== "all" 
                            ? "No engagements match your current filters"
                            : "No audit engagements have been created for this client yet"
                          }
                        </p>
                        <Button onClick={() => setShowCreateDialog(true)}>
                          <Plus className="w-4 h-4 mr-2" />
                          Create First Engagement
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {filteredEngagements?.map((engagement: any) => (
                          <div 
                            key={engagement.id} 
                            className={`p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer ${
                              selectedEngagement === engagement.id.toString() ? 'ring-2 ring-primary' : ''
                            }`}
                            onClick={() => setSelectedEngagement(engagement.id.toString())}
                          >
                            <div className="flex items-center justify-between mb-4">
                              <div>
                                <p className="font-medium text-gray-900">
                                  {getEngagementTypeLabel(engagement.engagementType)}
                                </p>
                                <p className="text-sm text-gray-500">
                                  {engagement.startDate && format(new Date(engagement.startDate), 'MMM d, yyyy')} - 
                                  {engagement.endDate && format(new Date(engagement.endDate), 'MMM d, yyyy')}
                                </p>
                              </div>
                              <div className="flex items-center space-x-2">
                                {getRiskBadge(engagement.riskLevel)}
                                {getStatusBadge(engagement.status)}
                              </div>
                            </div>
                            
                            {engagement.status === 'in_progress' && (
                              <div className="space-y-2">
                                <div className="flex justify-between text-sm">
                                  <span>Progress</span>
                                  <span>{Math.round(getProgressPercentage(engagement))}%</span>
                                </div>
                                <Progress value={getProgressPercentage(engagement)} className="h-2" />
                              </div>
                            )}
                            
                            <div className="mt-4 space-y-3">
                              <p className="text-sm text-gray-600">{engagement.scope?.substring(0, 100)}...</p>
                              
                              {/* Team Information */}
                              <div className="flex flex-wrap gap-4 text-sm">
                                {engagement.seniorManager && (
                                  <div className="flex items-center text-gray-600">
                                    <User className="w-4 h-4 mr-1" />
                                    <span className="font-medium">Senior Manager:</span>
                                    <span className="ml-1">{engagement.seniorManager}</span>
                                  </div>
                                )}
                                {engagement.teamMembers && engagement.teamMembers.length > 0 && (
                                  <div className="flex items-center text-gray-600">
                                    <Users className="w-4 h-4 mr-1" />
                                    <span className="font-medium">Team:</span>
                                    <span className="ml-1">{engagement.teamMembers.length} members</span>
                                  </div>
                                )}
                              </div>
                              
                              <div className="flex justify-end space-x-2">
                                <Button variant="outline" size="sm">
                                  <Eye className="w-4 h-4 mr-1" />
                                  View
                                </Button>
                                <Button variant="outline" size="sm">
                                  <Edit className="w-4 h-4 mr-1" />
                                  Edit
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="findings" className="space-y-6">
                {selectedEngagement ? (
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>Audit Findings</CardTitle>
                        <Button onClick={() => setShowFindingDialog(true)} size="sm">
                          <Plus className="w-4 h-4 mr-2" />
                          Add Finding
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {findings?.length === 0 ? (
                        <div className="text-center py-8">
                          <AlertTriangle className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-gray-500">No findings recorded for this engagement</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {findings?.map((finding: any) => (
                            <div key={finding.id} className="p-4 border border-gray-200 rounded-lg">
                              <div className="flex items-start justify-between mb-2">
                                <div className="flex-1">
                                  <p className="font-medium text-gray-900">{finding.finding}</p>
                                  {finding.recommendation && (
                                    <p className="text-sm text-gray-600 mt-2">
                                      <strong>Recommendation:</strong> {finding.recommendation}
                                    </p>
                                  )}
                                </div>
                                {getRiskBadge(finding.riskLevel)}
                              </div>
                              <div className="flex items-center justify-between text-sm text-gray-500">
                                <span>Created {format(new Date(finding.createdAt), 'MMM d, yyyy')}</span>
                                {finding.dueDate && (
                                  <span>Due: {format(new Date(finding.dueDate), 'MMM d, yyyy')}</span>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ) : (
                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      Please select an audit engagement to view its findings.
                    </AlertDescription>
                  </Alert>
                )}
              </TabsContent>
            </Tabs>
          )}

          {/* ICOFR Information */}
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              <strong>Internal Controls over Financial Reporting (ICOFR):</strong> Our platform supports comprehensive 
              ICOFR assessments including control design evaluation, testing procedures, deficiency tracking, 
              and SOX compliance documentation for publicly traded entities.
            </AlertDescription>
          </Alert>
        </div>
      </main>
    </div>
  );
}
