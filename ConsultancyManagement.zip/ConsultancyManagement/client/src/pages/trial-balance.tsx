import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Plus, Search, FileText, Download, Eye, BarChart3, 
  TrendingUp, AlertCircle, CheckCircle, Clock, Zap, Calculator, MapPin 
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function TrialBalance() {
  const [selectedClient, setSelectedClient] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState("");
  const [showMappingDialog, setShowMappingDialog] = useState(false);
  const [showErrorDialog, setShowErrorDialog] = useState(false);
  const [showGLDialog, setShowGLDialog] = useState(false);
  const [showEditMappingDialog, setShowEditMappingDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [mappingErrors, setMappingErrors] = useState<any[]>([]);
  const [selectedErrorEntry, setSelectedErrorEntry] = useState<any>(null);
  const [newEntry, setNewEntry] = useState({
    accountId: "",
    debitAmount: "",
    creditAmount: "",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const firmId = 1; // Static for now

  const { data: clients } = useQuery({
    queryKey: ['/api/clients', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/clients/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch clients');
      return response.json();
    },
  });

  const { data: periods } = useQuery({
    queryKey: ['/api/financial-periods', selectedClient],
    queryFn: async () => {
      if (!selectedClient) return [];
      const response = await fetch(`/api/financial-periods/${selectedClient}`);
      if (!response.ok) throw new Error('Failed to fetch periods');
      return response.json();
    },
    enabled: !!selectedClient,
  });

  const { data: chartOfAccounts } = useQuery({
    queryKey: ['/api/chart-of-accounts', selectedClient],
    queryFn: async () => {
      if (!selectedClient) return [];
      const response = await fetch(`/api/chart-of-accounts/${selectedClient}`);
      if (!response.ok) throw new Error('Failed to fetch chart of accounts');
      return response.json();
    },
    enabled: !!selectedClient,
  });

  const { data: trialBalance, isLoading } = useQuery({
    queryKey: ['/api/trial-balance', selectedClient, selectedPeriod],
    queryFn: async () => {
      if (!selectedClient || !selectedPeriod) return [];
      const response = await fetch(`/api/trial-balance/${selectedClient}/${selectedPeriod}`);
      if (!response.ok) throw new Error('Failed to fetch trial balance');
      return response.json();
    },
    enabled: !!selectedClient && !!selectedPeriod,
  });

  const createEntryMutation = useMutation({
    mutationFn: async (entry: any) => {
      await apiRequest('POST', '/api/trial-balance', { 
        ...entry, 
        clientId: parseInt(selectedClient),
        periodId: parseInt(selectedPeriod),
        uploadedBy: 1 // Static user ID
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/trial-balance', selectedClient, selectedPeriod] });
      toast({ title: "Success", description: "Trial balance entry created successfully" });
      setShowMappingDialog(false);
      setNewEntry({
        accountId: "",
        debitAmount: "",
        creditAmount: "",
      });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to create trial balance entry", variant: "destructive" });
    },
  });

  const generateStatementMutation = useMutation({
    mutationFn: async (statementType: string) => {
      await apiRequest('POST', '/api/generate-statement', { 
        clientId: parseInt(selectedClient),
        periodId: parseInt(selectedPeriod),
        statementType
      });
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Financial statement generated successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to generate financial statement", variant: "destructive" });
    },
  });

  const handleSubmit = () => {
    if (!newEntry.accountId || (!newEntry.debitAmount && !newEntry.creditAmount)) {
      toast({ title: "Error", description: "Please fill in all required fields", variant: "destructive" });
      return;
    }
    
    // Ensure at least one amount is provided and convert to proper format
    const entryData = {
      ...newEntry,
      accountId: parseInt(newEntry.accountId),
      debitAmount: newEntry.debitAmount ? parseFloat(newEntry.debitAmount).toFixed(2) : "0.00",
      creditAmount: newEntry.creditAmount ? parseFloat(newEntry.creditAmount).toFixed(2) : "0.00",
    };
    
    createEntryMutation.mutate(entryData);
  };

  const filteredAccounts = chartOfAccounts?.filter(account => 
    account.accountName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.accountCode.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const getAccountName = (accountId: number) => {
    const account = chartOfAccounts?.find(acc => acc.id === accountId);
    return account ? `${account.accountCode} - ${account.accountName}` : 'Unknown Account';
  };

  // Error detection functions
  const analyzeTrialBalance = () => {
    if (!trialBalance || !chartOfAccounts) return { errors: [], warnings: [] };
    
    const errors: any[] = [];
    const warnings: any[] = [];
    
    // Check for unmapped accounts
    const unmappedEntries = trialBalance.filter(entry => 
      !chartOfAccounts.find(acc => acc.id === entry.accountId)
    );
    
    if (unmappedEntries.length > 0) {
      errors.push({
        message: `${unmappedEntries.length} trial balance entries are not mapped to chart of accounts`,
        type: 'UNMAPPED_ACCOUNTS',
        details: unmappedEntries.map(entry => ({
          accountCode: entry.accountCode || 'Unknown',
          accountName: entry.accountName || 'Unknown',
          amount: entry.debitAmount || entry.creditAmount || '0'
        }))
      });
    }
    
    // Check for missing required accounts (e.g., Cash, Accounts Receivable)
    const requiredAccounts = ['Cash', 'Accounts Receivable', 'Accounts Payable'];
    const missingAccounts = requiredAccounts.filter(reqAcc => 
      !chartOfAccounts.find(acc => acc.accountName.toLowerCase().includes(reqAcc.toLowerCase()))
    );
    
    if (missingAccounts.length > 0) {
      warnings.push({
        message: `Missing critical accounts in chart of accounts`,
        type: 'MISSING_CRITICAL_ACCOUNTS',
        details: missingAccounts
      });
    }
    
    // Check for duplicate entries
    const duplicateEntries = trialBalance.filter((entry, index) => 
      trialBalance.findIndex(e => e.accountId === entry.accountId) !== index
    );
    
    if (duplicateEntries.length > 0) {
      warnings.push({
        message: `${duplicateEntries.length} duplicate entries found`,
        type: 'DUPLICATE_ENTRIES',
        details: duplicateEntries.map(entry => ({
          accountCode: chartOfAccounts.find(acc => acc.id === entry.accountId)?.accountCode || 'Unknown',
          accountName: chartOfAccounts.find(acc => acc.id === entry.accountId)?.accountName || 'Unknown',
          amount: entry.debitAmount || entry.creditAmount || '0'
        }))
      });
    }
    
    return { errors, warnings };
  };

  const calculateTotals = () => {
    if (!trialBalance) return { totalDebits: 0, totalCredits: 0 };
    
    const totalDebits = trialBalance.reduce((sum, entry) => sum + parseFloat(entry.debitAmount || "0"), 0);
    const totalCredits = trialBalance.reduce((sum, entry) => sum + parseFloat(entry.creditAmount || "0"), 0);
    
    return { totalDebits, totalCredits };
  };

  const { totalDebits, totalCredits } = calculateTotals();
  const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01;

  const { errors, warnings } = analyzeTrialBalance();

  // Working file generation
  const generateWorkingFile = async () => {
    if (!selectedClient || !selectedPeriod) {
      toast({ title: "Error", description: "Please select client and period", variant: "destructive" });
      return;
    }
    
    const client = clients?.find(c => c.id === parseInt(selectedClient));
    const period = periods?.find(p => p.id === parseInt(selectedPeriod));
    
    const mappedEntries = trialBalance?.filter(entry => 
      chartOfAccounts?.find(acc => acc.id === entry.accountId)
    ) || [];
    
    const unmappedEntries = trialBalance?.filter(entry => 
      !chartOfAccounts?.find(acc => acc.id === entry.accountId)
    ) || [];

    const workingFile = {
      generatedAt: new Date().toISOString(),
      client: {
        name: client?.name || 'Unknown',
        industry: client?.industry || 'Unknown',
        id: client?.id || 'Unknown'
      },
      period: {
        name: period?.name || 'Unknown',
        startDate: period?.startDate || '',
        endDate: period?.endDate || '',
        id: period?.id || 'Unknown'
      },
      summary: {
        totalTBEntries: trialBalance?.length || 0,
        totalCOAEntries: chartOfAccounts?.length || 0,
        mappedEntries: mappedEntries.length,
        unmappedEntries: unmappedEntries.length,
        errorCount: errors.length,
        warningCount: warnings.length,
        isBalanced: isBalanced,
        totalDebits: totalDebits,
        totalCredits: totalCredits,
        difference: Math.abs(totalDebits - totalCredits)
      },
      trialBalanceEntries: trialBalance?.map(entry => {
        const account = chartOfAccounts?.find(acc => acc.id === entry.accountId);
        return {
          id: entry.id,
          originalAccountCode: entry.accountCode || 'Unknown',
          originalAccountName: entry.accountName || 'Unknown',
          mappedAccountCode: account?.accountCode || 'UNMAPPED',
          mappedAccountName: account?.accountName || 'UNMAPPED',
          debitAmount: parseFloat(entry.debitAmount || "0"),
          creditAmount: parseFloat(entry.creditAmount || "0"),
          balance: parseFloat(entry.debitAmount || "0") - parseFloat(entry.creditAmount || "0"),
          mappingStatus: account ? 'MAPPED' : 'UNMAPPED',
          accountType: account?.accountType || 'Unknown',
          requiresReview: !account
        };
      }) || [],
      chartOfAccounts: chartOfAccounts?.map(acc => ({
        id: acc.id,
        accountCode: acc.accountCode,
        accountName: acc.accountName,
        accountType: acc.accountType,
        hasTrialBalanceEntry: trialBalance?.some(entry => entry.accountId === acc.id) || false,
        totalDebit: trialBalance?.filter(entry => entry.accountId === acc.id)
          .reduce((sum, entry) => sum + parseFloat(entry.debitAmount || "0"), 0) || 0,
        totalCredit: trialBalance?.filter(entry => entry.accountId === acc.id)
          .reduce((sum, entry) => sum + parseFloat(entry.creditAmount || "0"), 0) || 0
      })) || [],
      errorDetails: errors,
      warningDetails: warnings,
      recommendations: [
        ...(errors.length > 0 ? ['Fix mapping errors before generating financial statements'] : []),
        ...(warnings.length > 0 ? ['Review warning items for data quality'] : []),
        ...(!isBalanced ? ['Balance trial balance before proceeding'] : []),
        ...(unmappedEntries.length > 0 ? [`Map ${unmappedEntries.length} unmapped entries to chart of accounts`] : [])
      ],
      nextSteps: [
        'Review unmapped entries in the trial balance',
        'Use the Fix Mapping buttons to correct account mappings',
        'Ensure trial balance is balanced before proceeding',
        'Generate financial statements once all errors are resolved'
      ]
    };
    
    // Create CSV format for better Excel compatibility
    const csvContent = [
      'Trial Balance Working File Analysis',
      `Generated: ${new Date().toLocaleDateString()}`,
      `Client: ${client?.name || 'Unknown'}`,
      `Period: ${period?.name || 'Unknown'}`,
      '',
      'SUMMARY',
      `Total TB Entries,${workingFile.summary.totalTBEntries}`,
      `Mapped Entries,${workingFile.summary.mappedEntries}`,
      `Unmapped Entries,${workingFile.summary.unmappedEntries}`,
      `Total Debits,${workingFile.summary.totalDebits}`,
      `Total Credits,${workingFile.summary.totalCredits}`,
      `Difference,${workingFile.summary.difference}`,
      `Is Balanced,${workingFile.summary.isBalanced ? 'Yes' : 'No'}`,
      '',
      'TRIAL BALANCE ENTRIES',
      'ID,Original Code,Original Name,Mapped Code,Mapped Name,Debit,Credit,Balance,Status,Requires Review',
      ...workingFile.trialBalanceEntries.map(entry => 
        `${entry.id},"${entry.originalAccountCode}","${entry.originalAccountName}","${entry.mappedAccountCode}","${entry.mappedAccountName}",${entry.debitAmount},${entry.creditAmount},${entry.balance},${entry.mappingStatus},${entry.requiresReview ? 'Yes' : 'No'}`
      ),
      '',
      'CHART OF ACCOUNTS',
      'ID,Code,Name,Type,Has TB Entry,Total Debit,Total Credit',
      ...workingFile.chartOfAccounts.map(acc => 
        `${acc.id},"${acc.accountCode}","${acc.accountName}","${acc.accountType}",${acc.hasTrialBalanceEntry ? 'Yes' : 'No'},${acc.totalDebit},${acc.totalCredit}`
      ),
      '',
      'RECOMMENDATIONS',
      ...workingFile.recommendations.map(rec => `- ${rec}`)
    ].join('\n');

    // Download CSV file
    const csvBlob = new Blob([csvContent], { type: 'text/csv' });
    const csvUrl = URL.createObjectURL(csvBlob);
    const csvLink = document.createElement('a');
    csvLink.href = csvUrl;
    csvLink.download = `TB_Working_File_${client?.name?.replace(/\s+/g, '_') || 'Unknown'}_${period?.name?.replace(/\s+/g, '_') || 'Unknown'}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(csvLink);
    csvLink.click();
    document.body.removeChild(csvLink);
    URL.revokeObjectURL(csvUrl);

    // Also create JSON version for technical review
    const jsonBlob = new Blob([JSON.stringify(workingFile, null, 2)], { type: 'application/json' });
    const jsonUrl = URL.createObjectURL(jsonBlob);
    const jsonLink = document.createElement('a');
    jsonLink.href = jsonUrl;
    jsonLink.download = `TB_Working_File_${client?.name?.replace(/\s+/g, '_') || 'Unknown'}_${period?.name?.replace(/\s+/g, '_') || 'Unknown'}_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(jsonLink);
    jsonLink.click();
    document.body.removeChild(jsonLink);
    URL.revokeObjectURL(jsonUrl);
    
    toast({ 
      title: "Success", 
      description: "Working files downloaded (CSV & JSON formats) with detailed analysis" 
    });
  };

  // GL Reconciliation
  const performGLReconciliation = async () => {
    if (!selectedClient || !selectedPeriod) {
      toast({ title: "Error", description: "Please select client and period", variant: "destructive" });
      return;
    }
    
    try {
      const response = await fetch(`/api/gl-reconciliation/${selectedClient}/${selectedPeriod}`);
      if (!response.ok) throw new Error('Failed to perform GL reconciliation');
      
      const reconciliationData = await response.json();
      
      toast({ 
        title: "GL Reconciliation Complete", 
        description: `Found ${reconciliationData.discrepancies?.length || 0} discrepancies` 
      });
      
      // You can display the reconciliation results in a dialog or update state
      console.log('GL Reconciliation Results:', reconciliationData);
      
    } catch (error) {
      toast({ title: "Error", description: "Failed to perform GL reconciliation", variant: "destructive" });
    }
  };

  return (
    <div className="flex-1">
      <div className="p-4 lg:p-6 space-y-4 lg:space-y-6 pt-16 lg:pt-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl lg:text-2xl font-bold">Trial Balance & GL Mapping</h1>
            <p className="text-sm lg:text-base text-gray-600">Map trial balance entries to chart of accounts and generate financial statements</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              onClick={generateWorkingFile}
              disabled={!selectedClient || !selectedPeriod}
              className="text-xs lg:text-sm px-2 lg:px-4"
            >
              <Download className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
              <span className="hidden sm:inline">Download Working File</span>
              <span className="sm:hidden">Download</span>
            </Button>
            <Button 
              variant={errors.length > 0 ? "destructive" : "outline"}
              disabled={!selectedClient || !selectedPeriod}
              onClick={() => setShowErrorDialog(true)}
              className="text-xs lg:text-sm px-2 lg:px-4"
            >
              <AlertCircle className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
              <span className="hidden sm:inline">Error Analysis ({errors.length + warnings.length})</span>
              <span className="sm:hidden">Errors ({errors.length + warnings.length})</span>
            </Button>
            <Button 
              variant="outline" 
              disabled={!selectedClient || !selectedPeriod}
              onClick={() => setShowGLDialog(true)}
              className="text-xs lg:text-sm px-2 lg:px-4"
            >
              <Calculator className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
              <span className="hidden sm:inline">GL Reconciliation</span>
              <span className="sm:hidden">GL</span>
            </Button>
            <Button 
              disabled={!selectedClient || !selectedPeriod}
              onClick={() => setShowMappingDialog(true)}
              className="text-xs lg:text-sm px-2 lg:px-4"
            >
              <Plus className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
              <span className="hidden sm:inline">Add TB Entry</span>
              <span className="sm:hidden">Add</span>
            </Button>
          </div>
        </div>

        {/* Add TB Entry Dialog */}
        <Dialog open={showMappingDialog} onOpenChange={setShowMappingDialog}>
          <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Trial Balance Entry</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="account">Account</Label>
                    <Select value={newEntry.accountId} onValueChange={(value) => setNewEntry({...newEntry, accountId: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select account" />
                      </SelectTrigger>
                      <SelectContent>
                        {filteredAccounts.map((account) => (
                          <SelectItem key={account.id} value={account.id.toString()}>
                            {account.accountCode} - {account.accountName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="debit">Debit Amount</Label>
                      <Input
                        id="debit"
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        value={newEntry.debitAmount}
                        onChange={(e) => setNewEntry({...newEntry, debitAmount: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="credit">Credit Amount</Label>
                      <Input
                        id="credit"
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        value={newEntry.creditAmount}
                        onChange={(e) => setNewEntry({...newEntry, creditAmount: e.target.value})}
                      />
                    </div>
                  </div>
                  <Button onClick={handleSubmit} disabled={createEntryMutation.isPending}>
                    {createEntryMutation.isPending ? "Creating..." : "Create Entry"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            {/* Error Analysis Dialog */}
            <Dialog open={showErrorDialog} onOpenChange={setShowErrorDialog}>
              <DialogContent className="max-w-4xl">
                <DialogHeader>
                  <DialogTitle>Trial Balance Error Analysis</DialogTitle>
                </DialogHeader>
              <div className="space-y-6">
                {errors.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold text-red-600 mb-3">Critical Errors</h3>
                    <div className="space-y-3">
                      {errors.map((error, index) => (
                        <Alert key={index} className="border-red-200">
                          <AlertCircle className="h-4 w-4 text-red-500" />
                          <AlertDescription>
                            <div className="space-y-2">
                              <p className="font-medium">{error.message}</p>
                              {error.details && (
                                <div className="text-sm">
                                  <p className="font-medium">Affected Entries:</p>
                                  <div className="space-y-2">
                                    {error.details.map((detail: any, idx: number) => (
                                      <div key={idx} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                                        <span>
                                          {detail.accountCode} - {detail.accountName} 
                                          (AED {parseFloat(detail.amount || 0).toLocaleString()})
                                        </span>
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() => {
                                            setSelectedErrorEntry(detail);
                                            setShowEditMappingDialog(true);
                                          }}
                                        >
                                          Fix Mapping
                                        </Button>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          </AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  </div>
                )}

                {warnings.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold text-yellow-600 mb-3">Warnings</h3>
                    <div className="space-y-3">
                      {warnings.map((warning, index) => (
                        <Alert key={index} className="border-yellow-200">
                          <AlertCircle className="h-4 w-4 text-yellow-500" />
                          <AlertDescription>
                            <div className="space-y-2">
                              <p className="font-medium">{warning.message}</p>
                              {warning.details && (
                                <div className="text-sm">
                                  <p className="font-medium">Details:</p>
                                  <ul className="list-disc list-inside space-y-1">
                                    {warning.details.map((detail: any, idx: number) => (
                                      <li key={idx}>
                                        {typeof detail === 'object' ? 
                                          `${detail.accountCode} - ${detail.accountName} (AED ${parseFloat(detail.amount || 0).toLocaleString()})` : 
                                          detail
                                        }
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>
                          </AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  </div>
                )}

                {errors.length === 0 && warnings.length === 0 && (
                  <Alert className="border-green-200">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <AlertDescription>
                      <p className="font-medium text-green-700">No mapping errors found!</p>
                      <p className="text-sm text-green-600">All trial balance entries are properly mapped to chart of accounts.</p>
                    </AlertDescription>
                  </Alert>
                )}

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={generateWorkingFile}>
                    <Download className="w-4 h-4 mr-2" />
                    Download Detailed Report
                  </Button>
                  <Button onClick={() => setShowErrorDialog(false)}>Close</Button>
                </div>
              </div>
              </DialogContent>
            </Dialog>

            {/* GL Reconciliation Dialog */}
            <Dialog open={showGLDialog} onOpenChange={setShowGLDialog}>
              <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>General Ledger Reconciliation</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Total TB Entries</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{trialBalance?.length || 0}</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Chart of Accounts</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{chartOfAccounts?.length || 0}</div>
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Reconciliation Options</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">Full GL Reconciliation</p>
                        <p className="text-sm text-gray-600">Compare trial balance with general ledger entries</p>
                      </div>
                      <Button onClick={performGLReconciliation} variant="outline">
                        <Calculator className="w-4 h-4 mr-2" />
                        Run Reconciliation
                      </Button>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">Chart of Accounts Validation</p>
                        <p className="text-sm text-gray-600">Validate chart of accounts against IFRS standards</p>
                      </div>
                      <Button variant="outline">
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Validate COA
                      </Button>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">Upload Updated Chart of Accounts</p>
                        <p className="text-sm text-gray-600">Upload corrected or additional chart of accounts</p>
                      </div>
                      <Button variant="outline">
                        <Plus className="w-4 h-4 mr-2" />
                        Upload COA
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowGLDialog(false)}>Cancel</Button>
                  <Button onClick={generateWorkingFile}>
                    <Download className="w-4 h-4 mr-2" />
                    Download GL Report
                  </Button>
                </div>
              </div>
              </DialogContent>
            </Dialog>

            {/* Edit Mapping Dialog */}
            <Dialog open={showEditMappingDialog} onOpenChange={setShowEditMappingDialog}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Fix Trial Balance Mapping</DialogTitle>
                </DialogHeader>
                {selectedErrorEntry && (
                  <div className="space-y-4">
                    <div className="p-4 bg-gray-50 rounded">
                      <h3 className="font-medium">Current Entry</h3>
                      <p className="text-sm text-gray-600">
                        {selectedErrorEntry.accountCode} - {selectedErrorEntry.accountName}
                      </p>
                      <p className="text-sm">
                        Amount: AED {parseFloat(selectedErrorEntry.amount || 0).toLocaleString()}
                      </p>
                    </div>
                    
                    <div>
                      <Label htmlFor="mappingSearch">Search & Select Correct Account</Label>
                      <div className="space-y-2">
                        <Input
                          id="mappingSearch"
                          placeholder="Search chart of accounts..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        <Select value={newEntry.accountId} onValueChange={(value) => setNewEntry({...newEntry, accountId: value})}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select correct account from chart of accounts" />
                          </SelectTrigger>
                          <SelectContent>
                            {filteredAccounts.map((account) => (
                              <SelectItem key={account.id} value={account.id.toString()}>
                                {account.accountCode} - {account.accountName}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="editDebit">Debit Amount</Label>
                        <Input
                          id="editDebit"
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          value={newEntry.debitAmount}
                          onChange={(e) => setNewEntry({...newEntry, debitAmount: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="editCredit">Credit Amount</Label>
                        <Input
                          id="editCredit"
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          value={newEntry.creditAmount}
                          onChange={(e) => setNewEntry({...newEntry, creditAmount: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="flex justify-end space-x-2">
                      <Button variant="outline" onClick={() => setShowEditMappingDialog(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleSubmit} disabled={createEntryMutation.isPending}>
                        {createEntryMutation.isPending ? "Updating..." : "Update Mapping"}
                      </Button>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 lg:gap-4 mb-4 lg:mb-6">
          <Card className="p-3 lg:p-4">
            <CardHeader className="pb-2 lg:pb-3 p-0">
              <CardTitle className="text-xs lg:text-sm font-medium">Total Debits</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="text-lg lg:text-2xl font-bold">AED {totalDebits.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card className="p-3 lg:p-4">
            <CardHeader className="pb-2 lg:pb-3 p-0">
              <CardTitle className="text-xs lg:text-sm font-medium">Total Credits</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="text-lg lg:text-2xl font-bold">AED {totalCredits.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card className="p-3 lg:p-4 sm:col-span-2 lg:col-span-1">
            <CardHeader className="pb-2 lg:pb-3 p-0">
              <CardTitle className="text-xs lg:text-sm font-medium">Balance Status</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className={`flex items-center gap-2 ${isBalanced ? 'text-green-600' : 'text-red-600'}`}>
                {isBalanced ? <CheckCircle className="w-3 h-3 lg:w-4 lg:h-4" /> : <AlertCircle className="w-3 h-3 lg:w-4 lg:h-4" />}
                <span className="text-sm lg:text-base font-semibold">{isBalanced ? 'Balanced' : 'Unbalanced'}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 lg:gap-4 mb-4 lg:mb-6">
          <div>
            <Label htmlFor="client" className="text-sm lg:text-base">Client</Label>
            <Select value={selectedClient} onValueChange={setSelectedClient}>
              <SelectTrigger className="text-sm lg:text-base">
                <SelectValue placeholder="Select client" />
              </SelectTrigger>
              <SelectContent>
                {clients?.map((client) => (
                  <SelectItem key={client.id} value={client.id.toString()}>
                    {client.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="period" className="text-sm lg:text-base">Financial Period</Label>
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="text-sm lg:text-base">
                <SelectValue placeholder="Select period" />
              </SelectTrigger>
              <SelectContent>
                {periods?.map((period: any) => (
                  <SelectItem key={period.id} value={period.id.toString()}>
                    {period.description || `${format(new Date(period.startDate), 'MMM yyyy')} - ${format(new Date(period.endDate), 'MMM yyyy')}`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {selectedClient && selectedPeriod && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Trial Balance Entries</CardTitle>
                  <p className="text-sm text-gray-500 mt-1">
                    Client: {clients?.find((c: any) => c.id.toString() === selectedClient)?.name} | 
                    Period: {periods?.find((p: any) => p.id.toString() === selectedPeriod)?.description || 
                            `${format(new Date(periods?.find((p: any) => p.id.toString() === selectedPeriod)?.startDate || new Date()), 'MMM yyyy')} - ${format(new Date(periods?.find((p: any) => p.id.toString() === selectedPeriod)?.endDate || new Date()), 'MMM yyyy')}`}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => generateStatementMutation.mutate('balance_sheet')}
                    disabled={generateStatementMutation.isPending || !isBalanced}
                  >
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Generate Balance Sheet
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => generateStatementMutation.mutate('income_statement')}
                    disabled={generateStatementMutation.isPending || !isBalanced}
                  >
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Generate Income Statement
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : trialBalance && trialBalance.length > 0 ? (
                <div className="space-y-4">
                  {!isBalanced && (
                    <Alert className="border-red-200">
                      <AlertCircle className="h-4 w-4 text-red-500" />
                      <AlertDescription>
                        <div className="space-y-2">
                          <p className="font-medium">Trial Balance is not balanced!</p>
                          <p className="text-sm">
                            Difference: AED {Math.abs(totalDebits - totalCredits).toLocaleString()}
                          </p>
                          <div className="flex gap-2 mt-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setShowErrorDialog(true)}
                            >
                              View Error Details
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={generateWorkingFile}
                            >
                              Download Analysis
                            </Button>
                          </div>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}

                  {errors.length > 0 && (
                    <Alert className="border-red-200">
                      <AlertCircle className="h-4 w-4 text-red-500" />
                      <AlertDescription>
                        <div className="space-y-2">
                          <p className="font-medium">Mapping errors detected!</p>
                          <p className="text-sm">
                            {errors.length} critical errors and {warnings.length} warnings found
                          </p>
                          <div className="flex gap-2 mt-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setShowErrorDialog(true)}
                            >
                              View Error Details
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={generateWorkingFile}
                            >
                              Download Working File
                            </Button>
                          </div>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}

                  {isBalanced && errors.length === 0 && (
                    <Alert className="border-green-200">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <AlertDescription>
                        <div className="space-y-2">
                          <p className="font-medium text-green-700">Trial balance is balanced and ready!</p>
                          <p className="text-sm text-green-600">All entries are properly mapped and balanced. You can now generate financial statements.</p>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Account Code</TableHead>
                        <TableHead>Account Name</TableHead>
                        <TableHead className="text-right">Debit</TableHead>
                        <TableHead className="text-right">Credit</TableHead>
                        <TableHead className="text-right">Balance</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {trialBalance.map((entry) => {
                        const account = chartOfAccounts?.find(acc => acc.id === entry.accountId);
                        const debit = parseFloat(entry.debitAmount || "0");
                        const credit = parseFloat(entry.creditAmount || "0");
                        const balance = debit - credit;
                        
                        return (
                          <TableRow key={entry.id} className={!account ? 'bg-red-50' : ''}>
                            <TableCell className="font-medium">
                              {account?.accountCode || (
                                <span className="text-red-600">UNMAPPED</span>
                              )}
                            </TableCell>
                            <TableCell>
                              {account?.accountName || (
                                <span className="text-red-600">Account not found in COA</span>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              {debit > 0 ? `AED ${debit.toLocaleString()}` : '-'}
                            </TableCell>
                            <TableCell className="text-right">
                              {credit > 0 ? `AED ${credit.toLocaleString()}` : '-'}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end space-x-2">
                                <span className={balance >= 0 ? 'text-green-600' : 'text-red-600'}>
                                  AED {Math.abs(balance).toLocaleString()}
                                </span>
                                {!account && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setSelectedErrorEntry({
                                        accountCode: entry.accountCode || 'Unknown',
                                        accountName: entry.accountName || 'Unknown',
                                        amount: entry.debitAmount || entry.creditAmount || '0'
                                      });
                                      setNewEntry({
                                        accountId: '',
                                        debitAmount: entry.debitAmount || '',
                                        creditAmount: entry.creditAmount || ''
                                      });
                                      setShowEditMappingDialog(true);
                                    }}
                                  >
                                    Fix
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                      <TableRow className="border-t-2 font-bold">
                        <TableCell colSpan={2}>Total</TableCell>
                        <TableCell className="text-right">AED {totalDebits.toLocaleString()}</TableCell>
                        <TableCell className="text-right">AED {totalCredits.toLocaleString()}</TableCell>
                        <TableCell className="text-right">
                          <span className={isBalanced ? 'text-green-600' : 'text-red-600'}>
                            AED {Math.abs(totalDebits - totalCredits).toLocaleString()}
                          </span>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Calculator className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No trial balance entries found for this period.</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}