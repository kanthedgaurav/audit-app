import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Upload, FileText, AlertCircle, CheckCircle, X } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function DataUpload() {
  const [selectedClient, setSelectedClient] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState("");
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedFiles, setUploadedFiles] = useState<any[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const [activeUploadType, setActiveUploadType] = useState<string | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const firmId = 1; // Static for now

  const { data: clients } = useQuery({
    queryKey: ['/api/clients', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/clients/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch clients');
      return response.json();
    },
  });

  const { data: periods, refetch: refetchPeriods } = useQuery({
    queryKey: ['/api/financial-periods', selectedClient],
    queryFn: async () => {
      if (!selectedClient) return [];
      const response = await fetch(`/api/financial-periods/${selectedClient}`);
      if (!response.ok) throw new Error('Failed to fetch periods');
      const data = await response.json();
      console.log(`Frontend fetched ${data.length} periods for client ${selectedClient}:`, data);
      return data;
    },
    enabled: !!selectedClient,
    refetchOnWindowFocus: true,
    staleTime: 0, // Always refetch to get latest data
  });

  const { data: documents } = useQuery({
    queryKey: ['/api/documents', selectedClient],
    queryFn: async () => {
      if (!selectedClient) return [];
      const response = await fetch(`/api/documents/${selectedClient}`);
      if (!response.ok) throw new Error('Failed to fetch documents');
      return response.json();
    },
    enabled: !!selectedClient,
  });

  // Specialized upload mutations for each file type
  const chartOfAccountsUploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/upload/chart-of-accounts', {
        method: 'POST',
        body: formData,
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Upload failed');
      }
      
      return result;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents', selectedClient] });
      queryClient.invalidateQueries({ queryKey: ['/api/chart-of-accounts', selectedClient] });
      toast({ 
        title: "Success", 
        description: data.message || "Chart of accounts processed successfully" 
      });
      setUploadProgress(0);
      setUploadedFiles([]);
      setActiveUploadType(null);
    },
    onError: (error) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to process chart of accounts", 
        variant: "destructive" 
      });
    },
  });

  const trialBalanceUploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/upload/trial-balance', {
        method: 'POST',
        body: formData,
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Upload failed');
      }
      
      return result;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents', selectedClient] });
      queryClient.invalidateQueries({ queryKey: ['/api/trial-balance', selectedClient, selectedPeriod] });
      toast({ 
        title: "Success", 
        description: data.message || "Trial balance processed successfully" 
      });
      setUploadProgress(0);
      setUploadedFiles([]);
      setActiveUploadType(null);
    },
    onError: (error) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to process trial balance", 
        variant: "destructive" 
      });
    },
  });

  const generalLedgerUploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/upload/general-ledger', {
        method: 'POST',
        body: formData,
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Upload failed');
      }
      
      return result;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents', selectedClient] });
      queryClient.invalidateQueries({ queryKey: ['/api/general-ledger', selectedClient, selectedPeriod] });
      toast({ 
        title: "Success", 
        description: data.message || "General ledger processed successfully" 
      });
      setUploadProgress(0);
      setUploadedFiles([]);
      setActiveUploadType(null);
    },
    onError: (error) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to process general ledger", 
        variant: "destructive" 
      });
    },
  });

  // General document upload mutation
  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/documents/upload', {
        method: 'POST',
        body: formData,
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Upload failed');
      }
      
      return result;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents', selectedClient] });
      toast({ title: "Success", description: "Files uploaded successfully" });
      setUploadProgress(0);
      setUploadedFiles([]);
      setActiveUploadType(null);
    },
    onError: (error) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to upload files", 
        variant: "destructive" 
      });
    },
  });

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleFiles = (files: FileList) => {
    if (!selectedClient) {
      toast({ title: "Error", description: "Please select a client first", variant: "destructive" });
      return;
    }

    if (!activeUploadType) {
      toast({ title: "Error", description: "Please select an upload type first", variant: "destructive" });
      return;
    }

    const fileArray = Array.from(files);
    
    // File validation based on upload type
    const validFiles = fileArray.filter(file => {
      if (activeUploadType === 'supporting_docs') {
        return true; // Supporting docs accept all file types
      }
      
      // For financial data, only accept Excel and CSV files
      return file.type.includes('csv') || 
             file.type.includes('excel') || 
             file.type.includes('spreadsheet') ||
             file.name.toLowerCase().endsWith('.xlsx') ||
             file.name.toLowerCase().endsWith('.xls') ||
             file.name.toLowerCase().endsWith('.csv');
    });

    if (validFiles.length === 0) {
      const errorMessage = activeUploadType === 'supporting_docs' ? 
        "No valid files selected" : 
        "Please upload CSV or Excel files only";
      toast({ title: "Error", description: errorMessage, variant: "destructive" });
      return;
    }

    setUploadedFiles(validFiles.map(file => ({
      file,
      name: file.name,
      size: file.size,
      type: activeUploadType, // Use the selected upload type
      status: 'pending'
    })));
  };

  const getFileType = (fileName: string) => {
    const name = fileName.toLowerCase();
    if (name.includes('trial') || name.includes('tb')) return 'trial_balance';
    if (name.includes('ledger') || name.includes('gl')) return 'general_ledger';
    if (name.includes('chart') || name.includes('coa')) return 'chart_of_accounts';
    if (name.includes('asset')) return 'fixed_assets';
    if (name.includes('sales')) return 'sales_register';
    if (name.includes('purchase')) return 'purchase_register';
    return 'supporting_docs';
  };

  const getFileTypeLabel = (type: string) => {
    const labels: { [key: string]: string } = {
      'trial_balance': 'Trial Balance',
      'general_ledger': 'General Ledger',
      'chart_of_accounts': 'Chart of Accounts',
      'fixed_assets': 'Fixed Assets',
      'sales_register': 'Sales Register',
      'purchase_register': 'Purchase Register',
      'supporting_docs': 'Supporting Documents'
    };
    return labels[type] || 'Unknown';
  };

  const handleSpecializedUpload = (uploadType: string) => {
    if (!selectedClient || uploadedFiles.length === 0) {
      toast({ title: "Error", description: "Please select a client and upload files", variant: "destructive" });
      return;
    }
    
    if ((uploadType === 'trial_balance' || uploadType === 'general_ledger') && !selectedPeriod) {
      toast({ 
        title: "Period Required", 
        description: "Please select a financial period for trial balance and general ledger uploads", 
        variant: "destructive" 
      });
      return;
    }

    uploadedFiles.forEach(({ file }) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('clientId', selectedClient);
      if (uploadType === 'trial_balance' || uploadType === 'general_ledger') {
        formData.append('periodId', selectedPeriod);
      }
      formData.append('uploadedBy', '1'); // Static user ID for now

      // Use the appropriate mutation based on upload type
      if (uploadType === 'chart_of_accounts') {
        chartOfAccountsUploadMutation.mutate(formData);
      } else if (uploadType === 'trial_balance') {
        trialBalanceUploadMutation.mutate(formData);
      } else if (uploadType === 'general_ledger') {
        generalLedgerUploadMutation.mutate(formData);
      }
    });
  };

  const handleGeneralUpload = () => {
    if (!selectedClient || uploadedFiles.length === 0) return;

    uploadedFiles.forEach(({ file, type }) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('clientId', selectedClient);
      formData.append('category', type);
      formData.append('uploadedBy', '1'); // Static user ID for now

      uploadMutation.mutate(formData);
    });
  };

  const removeFile = (index: number) => {
    setUploadedFiles(uploadedFiles.filter((_, i) => i !== index));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="flex-1">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 lg:px-6 py-4 pt-16 lg:pt-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl lg:text-2xl font-bold text-gray-900">Data Upload</h2>
            <p className="text-sm text-gray-500">Upload financial data and supporting documents</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-4 lg:p-6">
        <div className="max-w-4xl mx-auto space-y-4 lg:space-y-6">
          {/* Client and Period Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select Client & Period</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="client">Client</Label>
                <Select value={selectedClient} onValueChange={(value) => {
                  setSelectedClient(value);
                  setSelectedPeriod(""); // Reset period when client changes
                }}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients?.map((client: any) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {selectedClient && (
                <div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="period">Financial Period (Required for Trial Balance & General Ledger)</Label>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => refetchPeriods()}
                      className="text-xs"
                    >
                      Refresh Periods
                    </Button>
                  </div>
                  <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                    <SelectTrigger>
                      <SelectValue placeholder={periods?.length === 0 ? "No periods available - try refreshing" : "Choose a financial period"} />
                    </SelectTrigger>
                    <SelectContent>
                      {periods?.map((period: any) => (
                        <SelectItem key={period.id} value={period.id.toString()}>
                          {period.description || `${format(new Date(period.startDate), 'MMM yyyy')} - ${format(new Date(period.endDate), 'MMM yyyy')}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {periods?.length === 0 && (
                    <p className="text-sm text-amber-600 mt-1">
                      No financial periods found. Periods are automatically created when you update client information.
                    </p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Upload Type Selection */}
          {selectedClient && (
            <Card>
              <CardHeader>
                <CardTitle>Select Upload Type</CardTitle>
                <p className="text-sm text-gray-500">Choose the type of financial data you're uploading</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Button
                    variant={activeUploadType === 'chart_of_accounts' ? 'default' : 'outline'}
                    onClick={() => {
                      setActiveUploadType('chart_of_accounts');
                      setUploadedFiles([]); // Clear files when changing upload type
                    }}
                    className="h-auto p-4 flex flex-col items-center space-y-2"
                  >
                    <FileText className="w-6 h-6" />
                    <span className="text-sm font-medium">Chart of Accounts</span>
                    <span className="text-xs text-gray-500">Account structure</span>
                  </Button>
                  
                  <Button
                    variant={activeUploadType === 'trial_balance' ? 'default' : 'outline'}
                    onClick={() => {
                      setActiveUploadType('trial_balance');
                      setUploadedFiles([]); // Clear files when changing upload type
                    }}
                    className="h-auto p-4 flex flex-col items-center space-y-2"
                    disabled={!selectedPeriod}
                  >
                    <FileText className="w-6 h-6" />
                    <span className="text-sm font-medium">Trial Balance</span>
                    <span className="text-xs text-gray-500">Period required</span>
                  </Button>
                  
                  <Button
                    variant={activeUploadType === 'general_ledger' ? 'default' : 'outline'}
                    onClick={() => {
                      setActiveUploadType('general_ledger');
                      setUploadedFiles([]); // Clear files when changing upload type
                    }}
                    className="h-auto p-4 flex flex-col items-center space-y-2"
                    disabled={!selectedPeriod}
                  >
                    <FileText className="w-6 h-6" />
                    <span className="text-sm font-medium">General Ledger</span>
                    <span className="text-xs text-gray-500">Period required</span>
                  </Button>
                  
                  <Button
                    variant={activeUploadType === 'supporting_docs' ? 'default' : 'outline'}
                    onClick={() => {
                      setActiveUploadType('supporting_docs');
                      setUploadedFiles([]); // Clear files when changing upload type
                    }}
                    className="h-auto p-4 flex flex-col items-center space-y-2"
                  >
                    <FileText className="w-6 h-6" />
                    <span className="text-sm font-medium">Supporting Documents</span>
                    <span className="text-xs text-gray-500">General files</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Upload Area */}
          {activeUploadType && (
            <Card>
              <CardHeader>
                <CardTitle>
                  Upload {activeUploadType === 'chart_of_accounts' ? 'Chart of Accounts' : 
                          activeUploadType === 'trial_balance' ? 'Trial Balance' :
                          activeUploadType === 'general_ledger' ? 'General Ledger' : 'Supporting Documents'}
                </CardTitle>
                <div className="text-sm text-gray-600">
                  {activeUploadType === 'chart_of_accounts' && (
                    <p>Expected columns: Account Code, Account Name, Account Type, Category, Sub Category, Parent Account Code</p>
                  )}
                  {activeUploadType === 'trial_balance' && (
                    <p>Expected columns: Account Code, Account Name, Debit Amount, Credit Amount</p>
                  )}
                  {activeUploadType === 'general_ledger' && (
                    <p>Expected columns: Account Code, Transaction Date, Description, Reference, Debit Amount, Credit Amount</p>
                  )}
                  {activeUploadType === 'supporting_docs' && (
                    <p>Upload any supporting documents (PDF, Excel, Word, Images)</p>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div
                  className={`border-2 border-dashed rounded-lg p-4 lg:p-8 text-center transition-colors ${
                    dragActive 
                      ? 'border-primary bg-primary/5' 
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <Upload className="w-8 h-8 lg:w-12 lg:h-12 text-gray-400 mx-auto mb-3 lg:mb-4" />
                  <h3 className="text-base lg:text-lg font-medium text-gray-900 mb-2">
                    Drop files here or click to browse
                  </h3>
                  <p className="text-xs lg:text-sm text-gray-500 mb-3 lg:mb-4">
                    {activeUploadType === 'supporting_docs' ? 
                      'Supports Excel, CSV, PDF, Word, Images (Max 10MB per file)' : 
                      'Supports Excel, CSV files (Max 10MB per file)'
                    }
                  </p>
                  <Input
                    type="file"
                    multiple
                    accept={activeUploadType === 'supporting_docs' ? 
                      ".xlsx,.xls,.csv,.pdf,.jpg,.jpeg,.png,.doc,.docx" : 
                      ".xlsx,.xls,.csv"
                    }
                    onChange={(e) => e.target.files && handleFiles(e.target.files)}
                    className="hidden"
                    id="file-upload"
                  />
                  <Label htmlFor="file-upload" className="cursor-pointer">
                    <Button type="button" variant="outline" className="cursor-pointer pointer-events-none">
                      Select Files
                    </Button>
                  </Label>
                </div>

                {/* File List */}
                {uploadedFiles.length > 0 && (
                  <div className="mt-6 space-y-3">
                    <h4 className="text-sm font-medium text-gray-900">Files to Upload</h4>
                    {uploadedFiles.map((file, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <FileText className="w-5 h-5 text-gray-400" />
                          <div>
                            <p className="text-sm font-medium text-gray-900">{file.name}</p>
                            <p className="text-xs text-gray-500">
                              {formatFileSize(file.size)} • {getFileTypeLabel(file.type)}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{getFileTypeLabel(file.type)}</Badge>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFile(index)}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button 
                        variant="outline" 
                        onClick={() => setUploadedFiles([])}
                      >
                        Clear All
                      </Button>
                      <Button 
                        onClick={() => {
                          if (activeUploadType === 'supporting_docs') {
                            handleGeneralUpload();
                          } else {
                            handleSpecializedUpload(activeUploadType);
                          }
                        }}
                        disabled={!selectedClient || uploadedFiles.length === 0 || 
                                 ((activeUploadType === 'trial_balance' || activeUploadType === 'general_ledger') && !selectedPeriod) ||
                                 (activeUploadType === 'chart_of_accounts' && chartOfAccountsUploadMutation.isPending) ||
                                 (activeUploadType === 'trial_balance' && trialBalanceUploadMutation.isPending) ||
                                 (activeUploadType === 'general_ledger' && generalLedgerUploadMutation.isPending) ||
                                 (activeUploadType === 'supporting_docs' && uploadMutation.isPending)}
                      >
                        {(activeUploadType === 'chart_of_accounts' && chartOfAccountsUploadMutation.isPending) ||
                         (activeUploadType === 'trial_balance' && trialBalanceUploadMutation.isPending) ||
                         (activeUploadType === 'general_ledger' && generalLedgerUploadMutation.isPending) ||
                         (activeUploadType === 'supporting_docs' && uploadMutation.isPending) ? 
                         "Processing..." : "Upload & Process Files"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Upload Progress */}
          {uploadMutation.isPending && (
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Uploading files...</span>
                    <span className="text-sm text-gray-500">45%</span>
                  </div>
                  <Progress value={45} className="w-full" />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Upload Guidelines */}
          <Card>
            <CardHeader>
              <CardTitle>Upload Guidelines</CardTitle>
            </CardHeader>
            <CardContent>
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>File Requirements:</strong>
                  <ul className="mt-2 list-disc list-inside text-sm space-y-1">
                    <li>Trial Balance: Should contain Account Code, Account Name, Debit, and Credit columns</li>
                    <li>General Ledger: Should include Date, Description, Debit, Credit, and Balance columns</li>
                    <li>Chart of Accounts: Should have Account Code, Account Name, and Account Type columns</li>
                    <li>All files should be in CSV or Excel format (max 10MB per file)</li>
                    <li>Ensure data is clean and properly formatted before upload</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* Recent Documents */}
          {selectedClient && documents && (
            <Card>
              <CardHeader>
                <CardTitle>Recent Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {documents.length === 0 ? (
                    <p className="text-sm text-gray-500 text-center py-4">
                      No documents uploaded yet for this client
                    </p>
                  ) : (
                    documents.map((doc: any) => (
                      <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <FileText className="w-5 h-5 text-gray-400" />
                          <div>
                            <p className="text-sm font-medium text-gray-900">{doc.fileName}</p>
                            <p className="text-xs text-gray-500">
                              {formatFileSize(doc.fileSize)} • {getFileTypeLabel(doc.category)} • 
                              {new Date(doc.uploadedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{getFileTypeLabel(doc.category)}</Badge>
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
