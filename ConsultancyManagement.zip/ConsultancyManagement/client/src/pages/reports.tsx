import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  FileText, Download, Eye, Settings, Plus, Search, 
  Building, Globe, BookOpen, Users, ClipboardList, 
  FileCheck, FileSpreadsheet, File, Printer
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function Reports() {
  const [selectedClient, setSelectedClient] = useState("");
  const [selectedReportType, setSelectedReportType] = useState("");
  const [selectedStandard, setSelectedStandard] = useState("");
  const [selectedFormat, setSelectedFormat] = useState("");
  const [showGenerateDialog, setShowGenerateDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [newReport, setNewReport] = useState({
    clientId: "",
    reportType: "",
    standard: "",
    format: "",
    exportFormat: "pdf",
    title: "",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const firmId = 1; // Static for now

  const { data: clients } = useQuery({
    queryKey: ['/api/clients', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/clients/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch clients');
      return response.json();
    },
  });

  const { data: reportTemplates } = useQuery({
    queryKey: ['/api/report-templates'],
    queryFn: async () => {
      const response = await fetch('/api/report-templates');
      if (!response.ok) throw new Error('Failed to fetch report templates');
      return response.json();
    },
  });

  const { data: generatedReports, isLoading } = useQuery({
    queryKey: ['/api/generated-reports', selectedClient],
    queryFn: async () => {
      if (!selectedClient) return [];
      const response = await fetch(`/api/generated-reports/${selectedClient}`);
      if (!response.ok) throw new Error('Failed to fetch generated reports');
      return response.json();
    },
    enabled: !!selectedClient,
  });

  const generateReportMutation = useMutation({
    mutationFn: async (report: any) => {
      // First, try to generate the actual report based on type
      if (report.reportType === 'financial_statement') {
        // Generate financial statement from trial balance
        const periods = await fetch(`/api/financial-periods/${report.clientId}`);
        const periodsData = await periods.json();
        
        if (periodsData.length > 0) {
          const latestPeriod = periodsData[periodsData.length - 1];
          
          // Generate Balance Sheet
          const balanceSheetResponse = await fetch('/api/generate-statement', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              clientId: report.clientId,
              periodId: latestPeriod.id,
              statementType: 'balance_sheet',
              format: report.format || 'vertical'
            })
          });
          
          if (!balanceSheetResponse.ok) {
            const errorData = await balanceSheetResponse.json();
            throw new Error(errorData.message || 'Failed to generate balance sheet');
          }
          
          const balanceSheet = await balanceSheetResponse.json();
          
          // Generate Income Statement
          const incomeStatementResponse = await fetch('/api/generate-statement', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              clientId: report.clientId,
              periodId: latestPeriod.id,
              statementType: 'income_statement',
              format: report.format || 'vertical'
            })
          });
          
          if (!incomeStatementResponse.ok) {
            const errorData = await incomeStatementResponse.json();
            throw new Error(errorData.message || 'Failed to generate income statement');
          }
          
          const incomeStatement = await incomeStatementResponse.json();
          
          // Create the report with the generated statements
          report.content = {
            balanceSheet: balanceSheet,
            incomeStatement: incomeStatement,
            metadata: {
              period: latestPeriod.endDate,
              standard: report.standard,
              format: report.format
            }
          };
        }
      }
      
      // Now create the report record
      await apiRequest('POST', '/api/generated-reports', report);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/generated-reports', selectedClient] });
      toast({ title: "Success", description: "Report generated successfully" });
      setShowGenerateDialog(false);
      setNewReport({
        clientId: "",
        reportType: "",
        standard: "",
        format: "",
        exportFormat: "pdf",
        title: "",
      });
    },
    onError: (error: any) => {
      const errorMessage = error.message || "Failed to generate report";
      toast({ 
        title: "Error", 
        description: errorMessage, 
        variant: "destructive" 
      });
    },
  });

  const handleGenerateReport = () => {
    if (!newReport.clientId || !newReport.reportType || !newReport.standard) {
      toast({ title: "Error", description: "Please fill in all required fields", variant: "destructive" });
      return;
    }

    generateReportMutation.mutate({
      ...newReport,
      clientId: parseInt(newReport.clientId),
      templateId: 1, // Would be selected from templates
      generatedBy: 1,
    });
  };

  const getReportTypeIcon = (type: string) => {
    switch (type) {
      case 'financial_statement':
        return <FileText className="w-5 h-5 text-blue-500" />;
      case 'auditor_report':
        return <FileCheck className="w-5 h-5 text-green-500" />;
      case 'management_report':
        return <Users className="w-5 h-5 text-purple-500" />;
      case 'notes_to_accounts':
        return <BookOpen className="w-5 h-5 text-orange-500" />;
      default:
        return <FileText className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStandardBadge = (standard: string) => {
    const badgeStyles = {
      'UAE_IFRS': 'bg-blue-100 text-blue-800',
      'INDIAN_GAAP': 'bg-orange-100 text-orange-800',
      'IFRS_INTERNATIONAL': 'bg-green-100 text-green-800',
      'UAE_AUDITING': 'bg-purple-100 text-purple-800',
    };
    return (
      <Badge className={badgeStyles[standard as keyof typeof badgeStyles] || 'bg-gray-100 text-gray-800'}>
        {standard.replace('_', ' ')}
      </Badge>
    );
  };

  const getFormatIcon = (format: string) => {
    switch (format) {
      case 'word':
        return <FileText className="w-4 h-4 text-blue-600" />;
      case 'excel':
        return <FileSpreadsheet className="w-4 h-4 text-green-600" />;
      case 'pdf':
        return <File className="w-4 h-4 text-red-600" />;
      default:
        return <FileText className="w-4 h-4 text-gray-600" />;
    }
  };

  const reportTypeOptions = [
    { value: 'financial_statement', label: 'Financial Statements' },
    { value: 'auditor_report', label: 'Auditor Report' },
    { value: 'management_report', label: 'Management Report' },
    { value: 'notes_to_accounts', label: 'Notes to Accounts' },
  ];

  const standardOptions = [
    { value: 'UAE_IFRS', label: 'UAE IFRS Standards' },
    { value: 'INDIAN_GAAP', label: 'Indian GAAP' },
    { value: 'IFRS_INTERNATIONAL', label: 'IFRS International' },
    { value: 'UAE_AUDITING', label: 'UAE Auditing Standards' },
  ];

  const formatOptions = [
    { value: 'vertical', label: 'Vertical Format' },
    { value: 'horizontal', label: 'Horizontal Format' },
    { value: 'schedule_iii', label: 'Schedule III (Indian)' },
    { value: 'custom', label: 'Custom Format' },
  ];

  const exportFormatOptions = [
    { value: 'pdf', label: 'PDF Document' },
    { value: 'word', label: 'MS Word Document' },
    { value: 'excel', label: 'MS Excel Spreadsheet' },
    { value: 'html', label: 'HTML Format' },
  ];

  const filteredReports = generatedReports?.filter((report: any) => {
    return report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
           report.reportType.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="flex-1">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 lg:px-6 py-4 pt-16 lg:pt-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl lg:text-2xl font-bold text-gray-900">Professional Reports</h2>
            <p className="text-sm text-gray-500">Generate comprehensive reports with editable formats</p>
          </div>
          <Dialog open={showGenerateDialog} onOpenChange={setShowGenerateDialog}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-white hover:bg-primary-dark text-xs lg:text-sm px-2 lg:px-4">
                <Plus className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
                <span className="hidden sm:inline">Generate Report</span>
                <span className="sm:hidden">Generate</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Generate Professional Report</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="client">Client *</Label>
                    <Select value={selectedClient} onValueChange={setSelectedClient}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select client" />
                      </SelectTrigger>
                      <SelectContent>
                        {clients?.map((client: any) => (
                          <SelectItem key={client.id} value={client.id.toString()}>
                            {client.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="reportType">Report Type *</Label>
                    <Select 
                      value={newReport.reportType} 
                      onValueChange={(value) => setNewReport({ ...newReport, reportType: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select report type" />
                      </SelectTrigger>
                      <SelectContent>
                        {reportTypeOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="standard">Reporting Standard *</Label>
                    <Select 
                      value={newReport.standard} 
                      onValueChange={(value) => setNewReport({ ...newReport, standard: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select standard" />
                      </SelectTrigger>
                      <SelectContent>
                        {standardOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="format">Format</Label>
                    <Select 
                      value={newReport.format} 
                      onValueChange={(value) => setNewReport({ ...newReport, format: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select format" />
                      </SelectTrigger>
                      <SelectContent>
                        {formatOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="exportFormat">Export Format *</Label>
                    <Select 
                      value={newReport.exportFormat} 
                      onValueChange={(value) => setNewReport({ ...newReport, exportFormat: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select export format" />
                      </SelectTrigger>
                      <SelectContent>
                        {exportFormatOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="title">Report Title</Label>
                    <Input
                      placeholder="Enter report title"
                      value={newReport.title}
                      onChange={(e) => setNewReport({ ...newReport, title: e.target.value })}
                    />
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button variant="outline" onClick={() => setShowGenerateDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleGenerateReport} disabled={generateReportMutation.isPending}>
                  {generateReportMutation.isPending ? "Generating..." : "Generate Report"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-4 lg:p-6">
        <div className="space-y-4 lg:space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-6">
            <Card className="p-3 lg:p-4">
              <CardContent className="p-0">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs lg:text-sm font-medium text-gray-600">Total Reports</p>
                    <p className="text-lg lg:text-2xl font-bold text-gray-900">{generatedReports?.length || 0}</p>
                  </div>
                  <FileText className="w-5 h-5 lg:w-8 lg:h-8 text-primary" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">UAE Standards</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {generatedReports?.filter((r: any) => r.standard?.includes('UAE')).length || 0}
                    </p>
                  </div>
                  <Building className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">International</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {generatedReports?.filter((r: any) => r.standard?.includes('INTERNATIONAL')).length || 0}
                    </p>
                  </div>
                  <Globe className="w-8 h-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">This Month</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {generatedReports?.filter((r: any) => {
                        const reportDate = new Date(r.generatedAt);
                        const now = new Date();
                        return reportDate.getMonth() === now.getMonth() && reportDate.getFullYear() === now.getFullYear();
                      }).length || 0}
                    </p>
                  </div>
                  <ClipboardList className="w-8 h-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Client Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select Client</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 lg:gap-4">
                <Select value={selectedClient} onValueChange={setSelectedClient}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select client to view reports" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients?.map((client: any) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search reports..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {selectedClient && (
            <Card>
              <CardHeader>
                <CardTitle>Generated Reports</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg animate-pulse">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                          <div className="space-y-2">
                            <div className="h-4 bg-gray-200 rounded w-32"></div>
                            <div className="h-3 bg-gray-200 rounded w-24"></div>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="h-5 bg-gray-200 rounded w-16"></div>
                          <div className="h-3 bg-gray-200 rounded w-20"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : filteredReports?.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No Reports Generated</h3>
                    <p className="text-gray-500 mb-4">
                      {searchTerm 
                        ? "No reports match your search criteria"
                        : "No reports have been generated for this client yet"
                      }
                    </p>
                    <Button onClick={() => setShowGenerateDialog(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Generate First Report
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredReports?.map((report: any) => (
                      <div key={report.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
                            {getReportTypeIcon(report.reportType)}
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">
                              {report.title || report.reportType.replace('_', ' ')}
                            </p>
                            <div className="flex items-center space-x-2 mt-1">
                              {getStandardBadge(report.standard)}
                              <span className="text-sm text-gray-500">
                                Generated {format(new Date(report.generatedAt), 'MMM d, yyyy')}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center space-x-1">
                            {getFormatIcon(report.exportFormat)}
                            <span className="text-sm text-gray-500 uppercase">
                              {report.exportFormat}
                            </span>
                          </div>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Eye className="w-4 h-4 mr-1" />
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              <Download className="w-4 h-4 mr-1" />
                              Download
                            </Button>
                            <Button variant="outline" size="sm">
                              <Settings className="w-4 h-4 mr-1" />
                              Edit
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Features Alert */}
          <Alert>
            <FileCheck className="h-4 w-4" />
            <AlertDescription>
              <strong>Professional Report Generation:</strong> Generate comprehensive reports in multiple formats 
              including Financial Statements, Auditor Reports, Management Reports, and Notes to Accounts. 
              All reports are compliant with UAE, Indian, and International standards with editable Word, Excel, and PDF formats.
            </AlertDescription>
          </Alert>
        </div>
      </main>
    </div>
  );
}