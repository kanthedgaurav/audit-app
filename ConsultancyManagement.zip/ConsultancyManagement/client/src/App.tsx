import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/sidebar";
import Dashboard from "@/pages/dashboard";
import Clients from "@/pages/clients";
import DataUpload from "@/pages/data-upload";
import FinancialStatements from "@/pages/financial-statements";
import TrialBalance from "@/pages/trial-balance";
import Reports from "@/pages/reports";
import Audit from "@/pages/audit";
import EnhancedAudit from "@/pages/enhanced-audit";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />
      <div className="lg:ml-64 min-h-screen">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/clients" component={Clients} />
          <Route path="/data-upload" component={DataUpload} />
          <Route path="/trial-balance" component={TrialBalance} />
          <Route path="/financial-statements" component={FinancialStatements} />
          <Route path="/audit" component={Audit} />
          <Route path="/enhanced-audit" component={EnhancedAudit} />
          {/* Placeholder routes for other pages */}
          <Route path="/icofr" component={() => <ComingSoon title="ICOFR" />} />
          <Route path="/documents" component={() => <ComingSoon title="Documents" />} />
          <Route path="/compliance" component={() => <ComingSoon title="Compliance" />} />
          <Route path="/reports" component={Reports} />
          <Route path="/settings" component={() => <ComingSoon title="Settings" />} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function ComingSoon({ title }: { title: string }) {
  return (
    <div className="flex-1">
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 lg:px-6 py-4 pt-16 lg:pt-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-bold text-gray-900">{title}</h2>
          <p className="text-sm text-gray-500">This feature is coming soon</p>
        </div>
      </header>
      <main className="p-4 lg:p-6">
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-900 mb-2">{title} Module</h3>
          <p className="text-gray-500">This feature is under development and will be available soon.</p>
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
