import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, AlertTriangle, XCircle, Clock, Eye, History, ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface ValidationResult {
  id: number;
  clientId: number;
  validationType: string;
  totalAccounts: number;
  passedChecks: number;
  warningChecks: number;
  errorChecks: number;
  overallStatus: string;
  ifrsCompliance: string;
  detailedResults: any;
  recommendations: string[];
  validatedAt: string;
  resolved: boolean;
  resolvedAt?: string;
}

interface ValidationResultsModalProps {
  clientId: number;
  clientName: string;
  trigger: React.ReactNode;
}

export function ValidationResultsModal({ clientId, clientName, trigger }: ValidationResultsModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedResult, setSelectedResult] = useState<ValidationResult | null>(null);

  const { data: validationHistory, isLoading, error } = useQuery({
    queryKey: [`/api/validation-results/${clientId}`],
    enabled: isOpen && clientId > 0,
  });

  // Auto-select first result when data loads
  if (Array.isArray(validationHistory) && validationHistory.length > 0 && !selectedResult) {
    setSelectedResult(validationHistory[0]);
  }

  // Debug logging
  if (isOpen && clientId > 0) {
    console.log("ValidationResultsModal Debug:", {
      clientId,
      clientName,
      isOpen,
      isLoading,
      error,
      validationHistory,
      selectedResult,
      historyLength: Array.isArray(validationHistory) ? validationHistory.length : 0
    });
  }

  const { data: detailedResult, isLoading: isLoadingDetail } = useQuery({
    queryKey: [`/api/validation-result/${selectedResult?.id}`],
    enabled: !!selectedResult,
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "passed":
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "warning":
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case "error":
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      passed: "default",
      warning: "secondary",
      failed: "destructive",
    };
    return <Badge variant={variants[status] || "outline"}>{status.toUpperCase()}</Badge>;
  };

  const getComplianceBadge = (compliance: string) => {
    return (
      <Badge variant={compliance === "Compliant" ? "default" : "destructive"}>
        {compliance}
      </Badge>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {trigger}
      </DialogTrigger>
      <DialogContent className="w-[95vw] max-w-6xl h-[90vh] p-0 overflow-hidden">
        <div className="p-4 lg:p-6 h-full flex flex-col">
          <DialogHeader className="pb-4">
            <DialogTitle className="text-lg lg:text-xl">
              IFRS Validation Results - {clientName}
            </DialogTitle>
            <DialogDescription className="text-sm text-gray-600">
              View detailed Chart of Accounts validation history and compliance status
            </DialogDescription>
          </DialogHeader>
          
          {/* Mobile-first responsive layout using Tabs for mobile */}
          <div className="flex-1 min-h-0">
            <Tabs defaultValue="history" className="h-full lg:hidden">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="history">History</TabsTrigger>
                <TabsTrigger value="details" disabled={!selectedResult}>
                  Details {selectedResult && <ChevronRight className="w-3 h-3 ml-1" />}
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="history" className="h-full mt-4">
                <ScrollArea className="h-[60vh]">
                  {isLoading ? (
                    <div className="text-center py-8">Loading validation history...</div>
                  ) : error ? (
                    <div className="text-center py-8 text-red-500">
                      <p>Error loading validation history</p>
                      <p className="text-xs mt-2">{error.message}</p>
                    </div>
                  ) : !Array.isArray(validationHistory) || validationHistory.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <History className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                      <p>No validation history found</p>
                      <p className="text-xs mt-2">Run a validation to see results here</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {validationHistory.map((result: ValidationResult) => (
                        <Card
                          key={result.id}
                          className={`cursor-pointer transition-all ${
                            selectedResult?.id === result.id 
                              ? "border-blue-500 bg-blue-50 shadow-md" 
                              : "hover:bg-gray-50 hover:shadow-sm"
                          }`}
                          onClick={() => setSelectedResult(result)}
                        >
                          <CardHeader className="pb-3">
                            <div className="flex items-center justify-between">
                              {getStatusBadge(result.overallStatus)}
                              <span className="text-xs text-gray-500">
                                {formatDate(result.validatedAt)}
                              </span>
                            </div>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span>Total Accounts:</span>
                                <span className="font-medium">{result.totalAccounts}</span>
                              </div>
                              <div className="flex items-center justify-between text-sm">
                                <span>IFRS Compliance:</span>
                                {getComplianceBadge(result.ifrsCompliance)}
                              </div>
                              <div className="flex items-center justify-between text-sm">
                                <span>Status Summary:</span>
                                <div className="flex space-x-2 text-xs">
                                  <span className="text-green-600 font-medium">✓{result.passedChecks}</span>
                                  <span className="text-yellow-600 font-medium">⚠{result.warningChecks}</span>
                                  <span className="text-red-600 font-medium">✗{result.errorChecks}</span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>
              
              <TabsContent value="details" className="h-full mt-4">
                {selectedResult ? (
                  <ScrollArea className="h-[60vh]">
                    <div className="space-y-4">
                      {/* Mobile-optimized detailed view */}
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Validation Summary</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-1 gap-3">
                            <div className="flex justify-between">
                              <span className="text-sm text-gray-600">Total Accounts:</span>
                              <span className="font-semibold">{selectedResult.totalAccounts}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-gray-600">Validation Type:</span>
                              <span className="font-semibold">{selectedResult.validationType.toUpperCase()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-gray-600">Validation Period:</span>
                              <span className="font-semibold">{formatDate(selectedResult.validatedAt)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-gray-600">Passed Checks:</span>
                              <span className="font-semibold text-green-600">{selectedResult.passedChecks}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-gray-600">Warning Checks:</span>
                              <span className="font-semibold text-yellow-600">{selectedResult.warningChecks}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-gray-600">Error Checks:</span>
                              <span className="font-semibold text-red-600">{selectedResult.errorChecks}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Detailed Validation Checks for Mobile */}
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Detailed Validation Results</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {selectedResult.detailedResults && selectedResult.detailedResults.map((check: any, index: number) => (
                              <div key={index} className="border rounded-lg p-3 bg-gray-50">
                                <div className="flex items-center justify-between mb-2">
                                  <span className="font-medium text-sm">{check.check}</span>
                                  {getStatusIcon(check.status)}
                                </div>
                                <p className="text-xs text-gray-600">{check.message}</p>
                                {check.status === 'warning' && (
                                  <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded text-xs">
                                    <strong>Action needed:</strong> {check.message}
                                  </div>
                                )}
                                {check.status === 'error' && (
                                  <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-xs">
                                    <strong>Fix required:</strong> {check.message}
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>

                      {/* Recommendations for mobile */}
                      {selectedResult.recommendations && selectedResult.recommendations.length > 0 && (
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-base">Recommendations</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              {selectedResult.recommendations.map((rec: string, index: number) => (
                                <div key={index} className="flex items-start space-x-2 p-3 bg-blue-50 border border-blue-200 rounded">
                                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                                  <div className="text-sm leading-relaxed">{rec}</div>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      )}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="flex items-center justify-center h-60 text-gray-500">
                    <div className="text-center">
                      <Eye className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                      <p className="text-sm">Select a validation from History to view details</p>
                    </div>
                  </div>
                )}
              </TabsContent>
            </Tabs>

            {/* Desktop layout - side by side */}
            <div className="hidden lg:flex h-full gap-6">
              {/* Left Panel - Validation History */}
              <div className="w-1/3 flex flex-col">
                <h3 className="font-semibold mb-4 text-lg">Validation History</h3>
                <ScrollArea className="flex-1">
                  {isLoading ? (
                    <div className="text-center py-8">Loading validation history...</div>
                  ) : error ? (
                    <div className="text-center py-8 text-red-500">
                      <p>Error loading validation history</p>
                      <p className="text-xs mt-2">{error.message}</p>
                    </div>
                  ) : !Array.isArray(validationHistory) || validationHistory.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <History className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                      <p className="font-medium">No validation history found</p>
                      <p className="text-sm mt-2">Run a validation to see results here</p>
                    </div>
                  ) : (
                    <div className="space-y-3 pr-2">
                      {validationHistory.map((result: ValidationResult) => (
                        <Card
                          key={result.id}
                          className={`cursor-pointer transition-all ${
                            selectedResult?.id === result.id 
                              ? "border-blue-500 bg-blue-50 shadow-md" 
                              : "hover:bg-gray-50 hover:shadow-sm"
                          }`}
                          onClick={() => setSelectedResult(result)}
                        >
                          <CardHeader className="pb-3">
                            <div className="flex items-center justify-between">
                              {getStatusBadge(result.overallStatus)}
                              <span className="text-xs text-gray-500">
                                {formatDate(result.validatedAt)}
                              </span>
                            </div>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span>Total Accounts:</span>
                                <span className="font-medium">{result.totalAccounts}</span>
                              </div>
                              <div className="flex items-center justify-between text-sm">
                                <span>IFRS Compliance:</span>
                                {getComplianceBadge(result.ifrsCompliance)}
                              </div>
                              <div className="flex items-center justify-between text-sm">
                                <span>Status Summary:</span>
                                <div className="flex space-x-2 text-xs">
                                  <span className="text-green-600 font-medium">✓{result.passedChecks}</span>
                                  <span className="text-yellow-600 font-medium">⚠{result.warningChecks}</span>
                                  <span className="text-red-600 font-medium">✗{result.errorChecks}</span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </div>

              {/* Right Panel - Detailed Results */}
              <div className="w-2/3 flex flex-col">
                {selectedResult ? (
                  <div className="h-full flex flex-col">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-lg">Detailed Validation Results</h3>
                      <div className="flex items-center space-x-2">
                        {getStatusBadge(selectedResult.overallStatus)}
                        {getComplianceBadge(selectedResult.ifrsCompliance)}
                      </div>
                    </div>

                    <ScrollArea className="flex-1">
                      <div className="space-y-6 pr-2">
                        {/* Summary Card */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Validation Summary</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <div className="text-sm text-gray-500 mb-1">Total Accounts</div>
                                <div className="font-semibold text-lg">{selectedResult.totalAccounts}</div>
                              </div>
                              <div>
                                <div className="text-sm text-gray-500 mb-1">Validation Type</div>
                                <div className="font-semibold">{selectedResult.validationType.toUpperCase()}</div>
                              </div>
                              <div>
                                <div className="text-sm text-gray-500 mb-1">Passed Checks</div>
                                <div className="font-semibold text-green-600 text-lg">{selectedResult.passedChecks}</div>
                              </div>
                              <div>
                                <div className="text-sm text-gray-500 mb-1">Warning Checks</div>
                                <div className="font-semibold text-yellow-600 text-lg">{selectedResult.warningChecks}</div>
                              </div>
                              <div>
                                <div className="text-sm text-gray-500 mb-1">Error Checks</div>
                                <div className="font-semibold text-red-600 text-lg">{selectedResult.errorChecks}</div>
                              </div>
                              <div>
                                <div className="text-sm text-gray-500 mb-1">Validation Period</div>
                                <div className="font-semibold">{formatDate(selectedResult.validatedAt)}</div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Detailed Checks */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Detailed Validation Checks</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              {selectedResult.detailedResults && selectedResult.detailedResults.map((check: any, index: number) => (
                                <div key={index} className="border rounded-lg p-4">
                                  <div className="flex items-center justify-between mb-3">
                                    <h4 className="font-medium text-base">{check.check}</h4>
                                    {getStatusIcon(check.status)}
                                  </div>
                                  <p className="text-sm text-gray-600 mb-2">{check.message}</p>
                                  {check.status === 'warning' && (
                                    <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded">
                                      <div className="flex items-start space-x-2">
                                        <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                                        <div>
                                          <strong className="text-yellow-800">Action Recommended:</strong>
                                          <p className="text-yellow-700 text-sm mt-1">{check.message}</p>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                  {check.status === 'error' && (
                                    <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded">
                                      <div className="flex items-start space-x-2">
                                        <XCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                                        <div>
                                          <strong className="text-red-800">Fix Required:</strong>
                                          <p className="text-red-700 text-sm mt-1">{check.message}</p>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                  {check.status === 'passed' && (
                                    <div className="mt-2 text-xs text-green-600 font-medium">
                                      ✓ Verification completed successfully
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>

                        {/* Recommendations */}
                        {selectedResult.recommendations && selectedResult.recommendations.length > 0 && (
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-lg">Recommendations</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-3">
                                {selectedResult.recommendations.map((rec: string, index: number) => (
                                  <div key={index} className="flex items-start space-x-3">
                                    <div className="w-3 h-3 bg-blue-500 rounded-full mt-1.5 flex-shrink-0"></div>
                                    <div className="text-sm leading-relaxed">{rec}</div>
                                  </div>
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                        )}
                      </div>
                    </ScrollArea>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-500">
                    <div className="text-center">
                      <Eye className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                      <p className="text-lg font-medium mb-2">Select a validation result to view details</p>
                      <p className="text-sm">Choose a validation from the history panel to see detailed breakdown</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}