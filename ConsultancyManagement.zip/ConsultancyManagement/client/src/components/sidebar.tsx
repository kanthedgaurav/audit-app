import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { 
  Users, Upload, FileText, Search, Shield, Folder, 
  ClipboardCheck, BarChart3, Settings, ChartLine, 
  Home, Bell, Calculator, Menu, X, Target
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Client Management", href: "/clients", icon: Users },
  { name: "Data Upload", href: "/data-upload", icon: Upload },
  { name: "Trial Balance", href: "/trial-balance", icon: Calculator },
  { name: "Financial Statements", href: "/financial-statements", icon: FileText },
  { name: "Internal Audit", href: "/audit", icon: Search },
  { name: "Enhanced Audit", href: "/enhanced-audit", icon: Target },
  { name: "ICOFR", href: "/icofr", icon: Shield },
  { name: "Documents", href: "/documents", icon: Folder },
  { name: "Compliance", href: "/compliance", icon: ClipboardCheck },
  { name: "Reports", href: "/reports", icon: BarChart3 },
  { name: "Settings", href: "/settings", icon: Settings },
];

export function Sidebar() {
  const [location] = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  // Handle mobile menu close when route changes
  useEffect(() => {
    setIsMobileOpen(false);
  }, [location]);

  // Handle responsive behavior
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setIsMobileOpen(!isMobileOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 rounded-md bg-white shadow-md border border-gray-200"
        aria-label="Toggle menu"
      >
        {isMobileOpen ? (
          <X className="w-6 h-6 text-gray-600" />
        ) : (
          <Menu className="w-6 h-6 text-gray-600" />
        )}
      </button>

      {/* Mobile overlay */}
      {isMobileOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "bg-white shadow-lg fixed h-full overflow-y-auto z-40 transition-all duration-300 ease-in-out",
        // Mobile styles - slide in from left
        "lg:translate-x-0",
        isMobileOpen ? "translate-x-0" : "-translate-x-full",
        // Desktop styles - collapsible
        "lg:relative lg:translate-x-0",
        isCollapsed ? "lg:w-16" : "lg:w-64",
        // Mobile always full sidebar when open
        "w-64"
      )}>
        {/* Header */}
        <div className="p-4 lg:p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 lg:w-10 lg:h-10 bg-primary rounded-lg flex items-center justify-center">
                <ChartLine className="w-5 h-5 lg:w-6 lg:h-6 text-white" />
              </div>
              {!isCollapsed && (
                <div className="hidden lg:block">
                  <h1 className="text-lg lg:text-xl font-bold text-gray-900">FinAudit Pro</h1>
                  <p className="text-xs text-gray-500">Financial Management Suite</p>
                </div>
              )}
              {/* Always show title on mobile */}
              <div className="lg:hidden">
                <h1 className="text-lg font-bold text-gray-900">FinAudit Pro</h1>
                <p className="text-xs text-gray-500">Financial Management Suite</p>
              </div>
            </div>
            
            {/* Desktop collapse button */}
            <button
              onClick={() => setIsCollapsed(!isCollapsed)}
              className="hidden lg:block p-1.5 rounded-md hover:bg-gray-100 transition-colors"
              aria-label="Toggle sidebar"
            >
              <Menu className="w-4 h-4 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-2 lg:p-4 space-y-1 lg:space-y-2 flex-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            
            return (
              <Link key={item.name} href={item.href}>
                <div
                  className={cn(
                    "flex items-center rounded-lg px-2 lg:px-3 py-2 text-sm font-medium transition-colors cursor-pointer group",
                    isActive
                      ? "bg-blue-50 text-primary"
                      : "text-gray-700 hover:text-primary hover:bg-gray-50",
                    isCollapsed ? "lg:justify-center" : "lg:space-x-3",
                    "space-x-3" // Always show space on mobile
                  )}
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  {!isCollapsed && (
                    <span className="hidden lg:block">{item.name}</span>
                  )}
                  {/* Always show text on mobile */}
                  <span className="lg:hidden">{item.name}</span>
                  
                  {/* Tooltip for collapsed state */}
                  {isCollapsed && (
                    <div className="hidden lg:block absolute left-full ml-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50">
                      {item.name}
                    </div>
                  )}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* User Profile */}
        <div className="p-2 lg:p-4 border-t border-gray-200 bg-white">
          <div className={cn(
            "flex items-center",
            isCollapsed ? "lg:justify-center" : "lg:space-x-3",
            "space-x-3" // Always show space on mobile
          )}>
            <img 
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100" 
              alt="User Profile" 
              className="w-8 h-8 lg:w-10 lg:h-10 rounded-full object-cover flex-shrink-0"
            />
            {!isCollapsed && (
              <div className="hidden lg:block flex-1">
                <p className="text-sm font-medium text-gray-900">Ahmed Al-Rashid</p>
                <p className="text-xs text-gray-500">Senior Manager</p>
              </div>
            )}
            {/* Always show user info on mobile */}
            <div className="lg:hidden flex-1">
              <p className="text-sm font-medium text-gray-900">Ahmed Al-Rashid</p>
              <p className="text-xs text-gray-500">Senior Manager</p>
            </div>
            
            {!isCollapsed && (
              <Bell className="hidden lg:block w-4 h-4 text-gray-400" />
            )}
            {/* Always show bell on mobile */}
            <Bell className="lg:hidden w-4 h-4 text-gray-400" />
          </div>
        </div>
      </div>
    </>
  );
}
