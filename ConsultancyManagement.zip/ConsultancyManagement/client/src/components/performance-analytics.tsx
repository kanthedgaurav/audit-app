import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart3, TrendingUp, TrendingDown } from "lucide-react";

export function PerformanceAnalytics() {
  const kpis = [
    {
      title: "Average Audit Duration",
      description: "Time to complete audits",
      value: "14.2 days",
      change: "↓ 2.1 days",
      changeColor: "text-green-600"
    },
    {
      title: "Client Satisfaction",
      description: "Based on feedback surveys",
      value: "4.7/5.0",
      change: "↑ 0.2 points",
      changeColor: "text-green-600"
    },
    {
      title: "Revenue Growth",
      description: "Monthly recurring revenue",
      value: "+18.5%",
      change: "↑ 3.2%",
      changeColor: "text-green-600"
    }
  ];

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Performance Analytics</h3>
          <div className="flex items-center space-x-2">
            <Select defaultValue="30">
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Select period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
                <SelectItem value="365">Last 12 months</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary-dark">
              Export Report
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Chart placeholder */}
          <div className="space-y-4">
            <h4 className="text-sm font-medium text-gray-900">Audit Completion Rate</h4>
            <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Interactive chart showing audit completion trends</p>
                <p className="text-xs text-gray-400 mt-2">Chart.js integration ready</p>
              </div>
            </div>
          </div>
          
          {/* KPI Summary */}
          <div className="space-y-4">
            <h4 className="text-sm font-medium text-gray-900">Key Performance Indicators</h4>
            <div className="space-y-4">
              {kpis.map((kpi, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{kpi.title}</p>
                    <p className="text-xs text-gray-500">{kpi.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-gray-900">{kpi.value}</p>
                    <p className={`text-xs ${kpi.changeColor}`}>{kpi.change}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
