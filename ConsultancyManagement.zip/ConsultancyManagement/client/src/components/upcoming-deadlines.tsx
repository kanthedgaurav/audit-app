import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { format, isAfter, differenceInDays } from "date-fns";

interface UpcomingDeadlinesProps {
  firmId: number;
}

export function UpcomingDeadlines({ firmId }: UpcomingDeadlinesProps) {
  const { data: deadlines, isLoading } = useQuery({
    queryKey: ['/api/dashboard/deadlines', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/dashboard/deadlines/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch deadlines');
      return response.json();
    },
  });

  const getStatusBadge = (dueDate: string) => {
    const due = new Date(dueDate);
    const today = new Date();
    const daysDiff = differenceInDays(due, today);

    if (isAfter(today, due)) {
      return <Badge className="bg-red-100 text-red-800">Overdue</Badge>;
    } else if (daysDiff <= 3) {
      return <Badge className="bg-yellow-100 text-yellow-800">Due in {daysDiff} day{daysDiff !== 1 ? 's' : ''}</Badge>;
    } else {
      return <Badge className="bg-green-100 text-green-800">On Track</Badge>;
    }
  };

  if (isLoading) {
    return (
      <Card className="lg:col-span-2 shadow-sm border border-gray-200">
        <CardHeader className="border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="h-6 bg-gray-200 rounded w-40 animate-pulse"></div>
            <div className="h-6 bg-gray-200 rounded w-20 animate-pulse"></div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg animate-pulse">
                <div className="flex items-center space-x-4">
                  <div className="text-center space-y-1">
                    <div className="h-4 bg-gray-200 rounded w-6"></div>
                    <div className="h-3 bg-gray-200 rounded w-8"></div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-40"></div>
                    <div className="h-3 bg-gray-200 rounded w-32"></div>
                  </div>
                </div>
                <div className="text-right space-y-2">
                  <div className="h-5 bg-gray-200 rounded w-16"></div>
                  <div className="h-3 bg-gray-200 rounded w-24"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="lg:col-span-2 shadow-sm border border-gray-200">
      <CardHeader className="border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Upcoming Deadlines</h3>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary-dark">
            View Calendar
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {deadlines?.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No upcoming deadlines found
            </div>
          ) : (
            deadlines?.map((deadline: any) => (
              <div key={deadline.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="text-center">
                    <p className="text-sm font-bold text-gray-900">
                      {format(new Date(deadline.dueDate), 'd')}
                    </p>
                    <p className="text-xs text-gray-500">
                      {format(new Date(deadline.dueDate), 'MMM')}
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{deadline.title}</p>
                    <p className="text-sm text-gray-500">{deadline.clientName}</p>
                  </div>
                </div>
                <div className="text-right">
                  {getStatusBadge(deadline.dueDate)}
                  <p className="text-xs text-gray-500 mt-1">
                    {deadline.assignedTo ? `Assigned to: ${deadline.assignedTo}` : 'Unassigned'}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
