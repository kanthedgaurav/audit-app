import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserPlus, Upload, Bot, CalendarCheck } from "lucide-react";
import { Link } from "wouter";

export function QuickActions() {
  const actions = [
    {
      title: "Onboard New Client",
      icon: UserPlus,
      href: "/clients",
      description: "Add a new client to your portfolio"
    },
    {
      title: "Upload Financial Data",
      icon: Upload,
      href: "/data-upload",
      description: "Upload trial balance and supporting documents"
    },
    {
      title: "Generate AI Report",
      icon: Bot,
      href: "/financial-statements",
      description: "Create automated financial statements"
    },
    {
      title: "Schedule Audit",
      icon: CalendarCheck,
      href: "/audit",
      description: "Plan and schedule audit engagements"
    }
  ];

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Quick Actions</h3>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-3">
          {actions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Link key={index} href={action.href}>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto p-3 hover:bg-gray-50"
                >
                  <div className="flex items-center space-x-3">
                    <Icon className="w-5 h-5 text-primary" />
                    <div className="text-left">
                      <div className="text-sm font-medium text-gray-900">{action.title}</div>
                      <div className="text-xs text-gray-500">{action.description}</div>
                    </div>
                  </div>
                </Button>
              </Link>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
