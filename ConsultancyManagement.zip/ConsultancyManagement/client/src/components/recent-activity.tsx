import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, CheckCircle, FileText, AlertTriangle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";

interface RecentActivityProps {
  firmId: number;
}

export function RecentActivity({ firmId }: RecentActivityProps) {
  const { data: activities, isLoading } = useQuery({
    queryKey: ['/api/dashboard/activity', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/dashboard/activity/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch activity');
      return response.json();
    },
  });

  const getActivityIcon = (action: string) => {
    switch (action) {
      case 'document_uploaded':
        return Upload;
      case 'audit_engagement_created':
      case 'financial_statement_generated':
        return CheckCircle;
      case 'client_created':
        return FileText;
      default:
        return AlertTriangle;
    }
  };

  const getActivityColor = (action: string) => {
    switch (action) {
      case 'document_uploaded':
        return 'bg-primary bg-opacity-10 text-primary';
      case 'audit_engagement_created':
      case 'financial_statement_generated':
        return 'bg-green-100 text-green-600';
      case 'client_created':
        return 'bg-orange-100 text-orange-600';
      default:
        return 'bg-yellow-100 text-yellow-600';
    }
  };

  if (isLoading) {
    return (
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="h-6 bg-gray-200 rounded w-32 animate-pulse"></div>
            <div className="h-6 bg-gray-200 rounded w-16 animate-pulse"></div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-start space-x-3 animate-pulse">
                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary-dark">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {activities?.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No recent activity found
            </div>
          ) : (
            activities?.map((activity: any) => {
              const Icon = getActivityIcon(activity.action);
              const colorClass = getActivityColor(activity.action);
              
              return (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className={`w-8 h-8 ${colorClass} rounded-full flex items-center justify-center flex-shrink-0`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">
                      <span className="font-medium">{activity.userName}</span> {activity.description}
                      {activity.clientName && (
                        <span className="font-medium"> for {activity.clientName}</span>
                      )}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
