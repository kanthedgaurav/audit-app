import { Card, CardContent } from "@/components/ui/card";
import { Users, Search, FileText, Shield } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface DashboardMetricsProps {
  firmId: number;
}

export function DashboardMetrics({ firmId }: DashboardMetricsProps) {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ['/api/dashboard/metrics', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/dashboard/metrics/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch metrics');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-24"></div>
                  <div className="h-8 bg-gray-200 rounded w-16"></div>
                </div>
                <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const metricsData = [
    {
      title: "Active Clients",
      value: metrics?.activeClients || 0,
      icon: Users,
      color: "bg-primary bg-opacity-10",
      iconColor: "text-primary",
      change: "+12%",
      changeText: "from last month",
      changeColor: "text-green-600"
    },
    {
      title: "Active Audits",
      value: metrics?.activeAudits || 0,
      icon: Search,
      color: "bg-orange-100",
      iconColor: "text-orange-600",
      change: "5 due this week",
      changeText: "",
      changeColor: "text-orange-600"
    },
    {
      title: "Completed Reports",
      value: metrics?.completedReports || 0,
      icon: FileText,
      color: "bg-green-100",
      iconColor: "text-green-600",
      change: "+8%",
      changeText: "from last month",
      changeColor: "text-green-600"
    },
    {
      title: "Compliance Status",
      value: metrics?.pendingCompliance ? `${100 - metrics.pendingCompliance}%` : "94%",
      icon: Shield,
      color: "bg-yellow-100",
      iconColor: "text-yellow-600",
      change: `${metrics?.pendingCompliance || 3} pending reviews`,
      changeText: "",
      changeColor: "text-yellow-600"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metricsData.map((metric, index) => {
        const Icon = metric.icon;
        return (
          <Card key={index} className="shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                  <p className="text-3xl font-bold text-gray-900">{metric.value}</p>
                </div>
                <div className={`w-12 h-12 ${metric.color} rounded-lg flex items-center justify-center`}>
                  <Icon className={`${metric.iconColor} w-6 h-6`} />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <span className={`text-sm font-medium ${metric.changeColor}`}>
                  {metric.change}
                </span>
                {metric.changeText && (
                  <span className="text-gray-500 text-sm ml-2">{metric.changeText}</span>
                )}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
