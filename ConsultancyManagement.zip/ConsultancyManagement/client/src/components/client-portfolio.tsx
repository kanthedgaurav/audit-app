import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building, Factory, Laptop } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

interface ClientPortfolioProps {
  firmId: number;
}

export function ClientPortfolio({ firmId }: ClientPortfolioProps) {
  const { data: clients, isLoading } = useQuery({
    queryKey: ['/api/clients', firmId],
    queryFn: async () => {
      const response = await fetch(`/api/clients/${firmId}`);
      if (!response.ok) throw new Error('Failed to fetch clients');
      return response.json();
    },
  });

  const getIndustryIcon = (industry: string) => {
    switch (industry?.toLowerCase()) {
      case 'trading':
      case 'trading & distribution':
        return Building;
      case 'manufacturing':
        return Factory;
      case 'technology':
      case 'technology services':
        return Laptop;
      default:
        return Building;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'inactive':
        return <Badge className="bg-gray-100 text-gray-800">Inactive</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>;
    }
  };

  if (isLoading) {
    return (
      <Card className="shadow-sm border border-gray-200">
        <CardHeader className="border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="h-6 bg-gray-200 rounded w-32 animate-pulse"></div>
            <div className="h-6 bg-gray-200 rounded w-24 animate-pulse"></div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg animate-pulse">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-32"></div>
                    <div className="h-3 bg-gray-200 rounded w-24"></div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="h-5 bg-gray-200 rounded w-16"></div>
                  <div className="h-3 bg-gray-200 rounded w-20"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Client Portfolio</h3>
          <Link href="/clients">
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary-dark">
              Manage Clients
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {clients?.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No clients found. <Link href="/clients" className="text-primary hover:underline">Add your first client</Link>
            </div>
          ) : (
            clients?.slice(0, 5).map((client: any) => {
              const Icon = getIndustryIcon(client.industry);
              
              return (
                <div key={client.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{client.name}</p>
                      <p className="text-sm text-gray-500">{client.industry || 'General Business'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    {getStatusBadge(client.status)}
                    <p className="text-xs text-gray-500 mt-1">
                      {client.reportingRegime || 'IFRS'}
                    </p>
                  </div>
                </div>
              );
            })
          )}
          {clients?.length > 5 && (
            <div className="text-center pt-4">
              <Link href="/clients">
                <Button variant="outline" size="sm">
                  View All {clients.length} Clients
                </Button>
              </Link>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
